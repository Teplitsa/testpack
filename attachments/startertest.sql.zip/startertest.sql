-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost:3306
-- Время создания: Дек 10 2015 г., 22:10
-- Версия сервера: 5.5.38
-- Версия PHP: 5.5.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `startertest`
--

-- --------------------------------------------------------

--
-- Структура таблицы `str_commentmeta`
--

DROP TABLE IF EXISTS `str_commentmeta`;
CREATE TABLE `str_commentmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `str_comments`
--

DROP TABLE IF EXISTS `str_comments`;
CREATE TABLE `str_comments` (
`comment_ID` bigint(20) unsigned NOT NULL,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `str_comments`
--

INSERT INTO `str_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Мистер WordPress', '', 'https://wordpress.org/', '', '2015-09-18 11:25:35', '2015-09-18 08:25:35', 'Привет! Это комментарий.\nЧтобы удалить его, авторизуйтесь и просмотрите комментарии к записи. Там будут ссылки для их изменения или удаления.', 0, '1', '', '', 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `str_links`
--

DROP TABLE IF EXISTS `str_links`;
CREATE TABLE `str_links` (
`link_id` bigint(20) unsigned NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `str_nf_objectmeta`
--

DROP TABLE IF EXISTS `str_nf_objectmeta`;
CREATE TABLE `str_nf_objectmeta` (
`id` bigint(20) NOT NULL,
  `object_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) NOT NULL,
  `meta_value` longtext NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=113 ;

--
-- Дамп данных таблицы `str_nf_objectmeta`
--

INSERT INTO `str_nf_objectmeta` (`id`, `object_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'date_updated', '2015-12-10 18:56:23'),
(2, 1, 'form_title', 'Напишите нам'),
(3, 1, 'show_title', '1'),
(4, 1, 'save_subs', '1'),
(5, 1, 'logged_in', '0'),
(6, 1, 'append_page', ''),
(7, 1, 'ajax', '1'),
(8, 1, 'clear_complete', '0'),
(9, 1, 'hide_complete', '1'),
(10, 1, 'success_msg', 'Your form has been successfully submitted.'),
(11, 1, 'email_from', ''),
(12, 1, 'email_type', 'html'),
(13, 1, 'user_email_msg', 'Thank you so much for contacting us. We will get back to you shortly.'),
(14, 1, 'user_email_fields', '0'),
(15, 1, 'admin_email_msg', ''),
(16, 1, 'admin_email_fields', '1'),
(17, 1, 'admin_attach_csv', '0'),
(18, 1, 'email_from_name', ''),
(19, 8, 'date_updated', '2014-09-09'),
(20, 8, 'active', '0'),
(21, 8, 'name', 'Email User'),
(22, 8, 'type', 'email'),
(23, 8, 'email_format', 'html'),
(24, 8, 'attach_csv', '1'),
(25, 8, 'from_name', ''),
(26, 8, 'from_address', ''),
(27, 8, 'reply_to', ''),
(28, 8, 'to', 'field_2'),
(29, 8, 'cc', ''),
(30, 8, 'bcc', ''),
(31, 8, 'email_subject', 'Thank you for contacting us!'),
(32, 8, 'email_message', 'Thank you so much for contacting us. We will get back to you shortly.'),
(33, 8, 'redirect_url', ''),
(34, 8, 'success_message_loc', 'ninja_forms_display_before_fields'),
(35, 8, 'success_msg', ''),
(36, 6, 'date_updated', '2014-09-09'),
(37, 6, 'active', '1'),
(38, 6, 'name', 'Success Message'),
(39, 6, 'type', 'success_message'),
(40, 6, 'email_format', 'html'),
(41, 6, 'attach_csv', '0'),
(42, 6, 'from_name', ''),
(43, 6, 'from_address', ''),
(44, 6, 'reply_to', ''),
(45, 6, 'to', ''),
(46, 6, 'cc', ''),
(47, 6, 'bcc', ''),
(48, 6, 'email_subject', ''),
(49, 6, 'email_message', ''),
(50, 6, 'redirect_url', ''),
(51, 6, 'success_message_loc', 'ninja_forms_display_after_fields'),
(52, 6, 'success_msg', 'Ваши данные успешно отправлены'),
(53, 6, 'text_message_number', ''),
(54, 6, 'text_message_carrier', '0'),
(55, 6, 'text_message_message', ''),
(56, 4, 'date_updated', '2014-09-09'),
(57, 4, 'active', '0'),
(58, 4, 'name', 'Email Admin'),
(59, 4, 'type', 'email'),
(60, 4, 'email_format', 'html'),
(61, 4, 'attach_csv', '1'),
(62, 4, 'from_name', ''),
(63, 4, 'from_address', ''),
(64, 4, 'reply_to', 'field_2'),
(65, 4, 'to', ''),
(66, 4, 'cc', ''),
(67, 4, 'bcc', ''),
(68, 4, 'email_subject', 'Ninja Form Submission'),
(69, 4, 'email_message', '[ninja_forms_all_fields]'),
(70, 4, 'redirect_url', ''),
(71, 4, 'success_message_loc', 'ninja_forms_display_before_fields'),
(72, 4, 'success_msg', ''),
(73, 4, 'text_message_number', ''),
(74, 4, 'text_message_carrier', '0'),
(75, 4, 'text_message_message', ''),
(76, 1, 'not_logged_in_msg', ''),
(77, 1, 'sub_limit_number', ''),
(78, 1, 'sub_limit_msg', ''),
(79, 1, 'status', ''),
(80, 1, 'last_sub', '4'),
(81, 5, 'date_updated', '2015-12-10 19:36:27'),
(82, 5, 'clear_complete', '0'),
(83, 5, 'hide_complete', '1'),
(84, 5, 'show_title', '1'),
(85, 5, 'status', ''),
(86, 5, 'form_title', 'Подписка на новости'),
(87, 5, 'append_page', ''),
(88, 5, 'ajax', '1'),
(89, 5, 'logged_in', '0'),
(90, 5, 'not_logged_in_msg', ''),
(91, 5, 'sub_limit_number', ''),
(92, 5, 'sub_limit_msg', ''),
(95, 5, 'last_sub', '14'),
(96, 10, 'date_updated', '2015-12-10'),
(97, 10, 'active', '1'),
(98, 10, 'name', 'Вывод сообщения'),
(99, 10, 'type', 'success_message'),
(100, 10, 'from_name', ''),
(101, 10, 'from_address', ''),
(102, 10, 'to', ''),
(103, 10, 'email_subject', ''),
(104, 10, 'email_message', ''),
(105, 10, 'attach_csv', '0'),
(106, 10, 'email_format', 'html'),
(107, 10, 'reply_to', ''),
(108, 10, 'cc', ''),
(109, 10, 'bcc', ''),
(110, 10, 'redirect_url', ''),
(111, 10, 'success_msg', 'Спасибо, ваша подписка активирована');

-- --------------------------------------------------------

--
-- Структура таблицы `str_nf_objects`
--

DROP TABLE IF EXISTS `str_nf_objects`;
CREATE TABLE `str_nf_objects` (
`id` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `str_nf_objects`
--

INSERT INTO `str_nf_objects` (`id`, `type`) VALUES
(1, 'form'),
(4, 'notification'),
(5, 'form'),
(6, 'notification'),
(8, 'notification'),
(10, 'notification');

-- --------------------------------------------------------

--
-- Структура таблицы `str_nf_relationships`
--

DROP TABLE IF EXISTS `str_nf_relationships`;
CREATE TABLE `str_nf_relationships` (
`id` bigint(20) NOT NULL,
  `child_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `child_type` varchar(255) NOT NULL,
  `parent_type` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `str_nf_relationships`
--

INSERT INTO `str_nf_relationships` (`id`, `child_id`, `parent_id`, `child_type`, `parent_type`) VALUES
(1, 8, 1, 'notification', 'form'),
(2, 6, 1, 'notification', 'form'),
(3, 4, 1, 'notification', 'form'),
(4, 10, 5, 'notification', 'form');

-- --------------------------------------------------------

--
-- Структура таблицы `str_ninja_forms_fav_fields`
--

DROP TABLE IF EXISTS `str_ninja_forms_fav_fields`;
CREATE TABLE `str_ninja_forms_fav_fields` (
`id` int(11) NOT NULL,
  `row_type` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `data` longtext NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=93 ;

--
-- Дамп данных таблицы `str_ninja_forms_fav_fields`
--

INSERT INTO `str_ninja_forms_fav_fields` (`id`, `row_type`, `type`, `order`, `data`, `name`) VALUES
(2, 0, '_list', 0, 'a:10:{s:5:"label";s:14:"State Dropdown";s:9:"label_pos";s:4:"left";s:9:"list_type";s:8:"dropdown";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"1";s:4:"list";a:1:{s:7:"options";a:51:{i:0;a:3:{s:5:"label";s:7:"Alabama";s:5:"value";s:2:"AL";s:8:"selected";s:1:"0";}i:1;a:3:{s:5:"label";s:6:"Alaska";s:5:"value";s:2:"AK";s:8:"selected";s:1:"0";}i:2;a:3:{s:5:"label";s:7:"Arizona";s:5:"value";s:2:"AZ";s:8:"selected";s:1:"0";}i:3;a:3:{s:5:"label";s:8:"Arkansas";s:5:"value";s:2:"AR";s:8:"selected";s:1:"0";}i:4;a:3:{s:5:"label";s:10:"California";s:5:"value";s:2:"CA";s:8:"selected";s:1:"0";}i:5;a:3:{s:5:"label";s:8:"Colorado";s:5:"value";s:2:"CO";s:8:"selected";s:1:"0";}i:6;a:3:{s:5:"label";s:11:"Connecticut";s:5:"value";s:2:"CT";s:8:"selected";s:1:"0";}i:7;a:3:{s:5:"label";s:8:"Delaware";s:5:"value";s:2:"DE";s:8:"selected";s:1:"0";}i:8;a:3:{s:5:"label";s:20:"District of Columbia";s:5:"value";s:2:"DC";s:8:"selected";s:1:"0";}i:9;a:3:{s:5:"label";s:7:"Florida";s:5:"value";s:2:"FL";s:8:"selected";s:1:"0";}i:10;a:3:{s:5:"label";s:7:"Georgia";s:5:"value";s:2:"GA";s:8:"selected";s:1:"0";}i:11;a:3:{s:5:"label";s:6:"Hawaii";s:5:"value";s:2:"HI";s:8:"selected";s:1:"0";}i:12;a:3:{s:5:"label";s:5:"Idaho";s:5:"value";s:2:"ID";s:8:"selected";s:1:"0";}i:13;a:3:{s:5:"label";s:8:"Illinois";s:5:"value";s:2:"IL";s:8:"selected";s:1:"0";}i:14;a:3:{s:5:"label";s:7:"Indiana";s:5:"value";s:2:"IN";s:8:"selected";s:1:"0";}i:15;a:3:{s:5:"label";s:4:"Iowa";s:5:"value";s:2:"IA";s:8:"selected";s:1:"0";}i:16;a:3:{s:5:"label";s:6:"Kansas";s:5:"value";s:2:"KS";s:8:"selected";s:1:"0";}i:17;a:3:{s:5:"label";s:8:"Kentucky";s:5:"value";s:2:"KY";s:8:"selected";s:1:"0";}i:18;a:3:{s:5:"label";s:9:"Louisiana";s:5:"value";s:2:"LA";s:8:"selected";s:1:"0";}i:19;a:3:{s:5:"label";s:5:"Maine";s:5:"value";s:2:"ME";s:8:"selected";s:1:"0";}i:20;a:3:{s:5:"label";s:8:"Maryland";s:5:"value";s:2:"MD";s:8:"selected";s:1:"0";}i:21;a:3:{s:5:"label";s:13:"Massachusetts";s:5:"value";s:2:"MA";s:8:"selected";s:1:"0";}i:22;a:3:{s:5:"label";s:8:"Michigan";s:5:"value";s:2:"MI";s:8:"selected";s:1:"0";}i:23;a:3:{s:5:"label";s:9:"Minnesota";s:5:"value";s:2:"MN";s:8:"selected";s:1:"0";}i:24;a:3:{s:5:"label";s:11:"Mississippi";s:5:"value";s:2:"MS";s:8:"selected";s:1:"0";}i:25;a:3:{s:5:"label";s:8:"Missouri";s:5:"value";s:2:"MO";s:8:"selected";s:1:"0";}i:26;a:3:{s:5:"label";s:7:"Montana";s:5:"value";s:2:"MT";s:8:"selected";s:1:"0";}i:27;a:3:{s:5:"label";s:8:"Nebraska";s:5:"value";s:2:"NE";s:8:"selected";s:1:"0";}i:28;a:3:{s:5:"label";s:6:"Nevada";s:5:"value";s:2:"NV";s:8:"selected";s:1:"0";}i:29;a:3:{s:5:"label"3s:13:"New Hampshire";s:5:"value";s:2:"NH";s:8:"selected";s:1:"0";}i:30;a:3:{s:5:"label";s:10:"New Jersey";s:5:"value";s:2:"NJ";s:8:"selected";s:1:"0";}i:31;a:3:{s:5:"label";s:10:"New Mexico";s:5:"value";s:2:"NM";s:8:"selected";s:1:"0";}i:32;a:3:{s:5:"label";s:8:"New York";s:5:"value";s:2:"NY";s:8:"selected";s:1:"0";}i:33;a:3:{s:5:"label";s:14:"North Carolina";s:5:"value";s:2:"NC";s:8:"selected";s:1:"0";}i:34;a:3:{s:5:"label";s:12:"North Dakota";s:5:"value";s:2:"ND";s:8:"selected";s:1:"0";}i:35;a:3:{s:5:"label";s:4:"Ohio";s:5:"value";s:2:"OH";s:8:"selected";s:1:"0";}i:36;a:3:{s:5:"label";s:8:"Oklahoma";s:5:"value";s:2:"OK";s:8:"selected";s:1:"0";}i:37;a:3:{s:5:"label";s:6:"Oregon";s:5:"value";s:2:"OR";s:8:"selected";s:1:"0";}i:38;a:3:{s:5:"label";s:12:"Pennsylvania";s:5:"value";s:2:"PA";s:8:"selected";s:1:"0";}i:39;a:3:{s:5:"label";s:12:"Rhode Island";s:5:"value";s:2:"RI";s:8:"selected";s:1:"0";}i:40;a:3:{s:5:"label";s:14:"South Carolina";s:5:"value";s:2:"SC";s:8:"selected";s:1:"0";}i:41;a:3:{s:5:"label";s:12:"South Dakota";s:5:"value";s:2:"SD";s:8:"selected";s:1:"0";}i:42;a:3:{s:5:"label";s:9:"Tennessee";s:5:"value";s:2:"TN";s:8:"selected";s:1:"0";}i:43;a:3:{s:5:"label";s:5:"Texas";s:5:"value";s:2:"TX";s:8:"selected";s:1:"0";}i:44;a:3:{s:5:"label";s:4:"Utah";s:5:"value";s:2:"UT";s:8:"selected";s:1:"0";}i:45;a:3:{s:5:"label";s:7:"Vermont";s:5:"value";s:2:"VT";s:8:"selected";s:1:"0";}i:46;a:3:{s:5:"label";s:8:"Virginia";s:5:"value";s:2:"VA";s:8:"selected";s:1:"0";}i:47;a:3:{s:5:"label";s:10:"Washington";s:5:"value";s:2:"WA";s:8:"selected";s:1:"0";}i:48;a:3:{s:5:"label";s:13:"West Virginia";s:5:"value";s:2:"WV";s:8:"selected";s:1:"0";}i:49;a:3:{s:5:"label";s:9:"Wisconsin";s:5:"value";s:2:"WI";s:8:"selected";s:1:"0";}i:50;a:3:{s:5:"label";s:7:"Wyoming";s:5:"value";s:2:"WY";s:8:"selected";s:1:"0";}}}s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";}', 'State Dropdown'),
(3, 0, '_spam', 0, 'a:6:{s:9:"label_pos";s:4:"left";s:5:"label";s:18:"Anti-Spam Question";s:6:"answer";s:16:"Anti-Spam Answer";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";}', 'Anti-Spam'),
(4, 0, '_submit', 0, 'a:4:{s:5:"label";s:6:"Submit";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";}', 'Submit'),
(5, 0, '_tax', 0, 'a:11:{s:5:"label";s:3:"Tax";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:19:"payment_field_group";s:1:"1";s:11:"payment_tax";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"conditional";s:0:"";s:11:"calc_option";s:1:"0";s:4:"calc";s:0:"";}', 'Tax'),
(6, 0, '_text', 0, 'a:19:{s:5:"label";s:10:"First Name";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"1";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'First Name'),
(7, 0, '_text', 0, 'a:19:{s:5:"label";s:9:"Last Name";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"1";s:9:"from_name";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Last Name'),
(8, 0, '_text', 0, 'a:23:{s:5:"label";s:9:"Address 1";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"1";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Address 1'),
(9, 0, '_text', 0, 'a:23:{s:5:"label";s:9:"Address 2";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"1";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Address 2'),
(10, 0, '_text', 0, 'a:23:{s:5:"label";s:4:"City";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"1";s:8:"user_zip";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'City'),
(11, 0, '_list', 0, 'a:16:{s:5:"label";s:5:"State";s:9:"label_pos";s:5:"above";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"1";s:4:"list";a:1:{s:7:"options";a:51:{i:0;a:4:{s:5:"label";s:7:"Alabama";s:5:"value";s:2:"AL";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:6:"Alaska";s:5:"value";s:2:"AK";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:7:"Arizona";s:5:"value";s:2:"AZ";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:3;a:4:{s:5:"label";s:8:"Arkansas";s:5:"value";s:2:"AR";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:4;a:4:{s:5:"label";s:10:"California";s:5:"value";s:2:"CA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:5;a:4:{s:5:"label";s:8:"Colorado";s:5:"value";s:2:"CO";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:6;a:4:{s:5:"label";s:11:"Connecticut";s:5:"value";s:2:"CT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:7;a:4:{s:5:"label";s:8:"Delaware";s:5:"value";s:2:"DE";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:8;a:4:{s:5:"label";s:20:"District of Columbia";s:5:"value";s:2:"DC";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:9;a:4:{s:5:"label";s:7:"Florida";s:5:"value";s:2:"FL";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:10;a:4:{s:5:"label";s:7:"Georgia";s:5:"value";s:2:"GA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:11;a:4:{s:5:"label";s:6:"Hawaii";s:5:"value";s:2:"HI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:12;a:4:{s:5:"label";s:5:"Idaho";s:5:"value";s:2:"ID";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:13;a:4:{s:5:"label";s:8:"Illinois";s:5:"value";s:2:"IL";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:14;a:4:{s:5:"label";s:7:"Indiana";s:5:"value";s:2:"IN";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:15;a:4:{s:5:"label";s:4:"Iowa";s:5:"value";s:2:"IA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:16;a:4:{s:5:"label";s:6:"Kansas";s:5:"value";s:2:"KS";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:17;a:4:{s:5:"label";s:8:"Kentucky";s:5:"value";s:2:"KY";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:18;a:4:{s:5:"label";s:9:"Louisiana";s:5:"value";s:2:"LA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:19;a:4:{s:5:"label";s:5:"Maine";s:5:"value";s:2:"ME";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:20;a:4:{s:5:"label";s:8:"Maryland";s:5:"value";s:2:"MD";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:21;a:4:{s:5:"label";s:13:"Massachusetts";s:5:"value";s:2:"MA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:22;a:4:{s:5:"label";s:8:"Michigan";s:5:"value";s:2:"MI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:23;a:4:{s:5:"label";s:9:"Minnesota";s:5:"value";s:2:"MN";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:24;a:4:{s:5:"label";s:11:"Mississippi";s:5:"value";s:2:"MS";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:25;a:4:{s:5:"label";s:8:"Missouri";s:5:"value";s:2:"MO";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:26;a:4:{s:5:"label";s:7:"Montana";s:5:"value";s:2:"MT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:27;a:4:{s:5:"label";s:8:"Nebraska";s:5:"value";s:2:"NE";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:28;a:4:{s:5:"label";s:6:"Nevada";s:5:"value";s:2:"NV";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:29;a:4:{s:5:"label";s:13:"New Hampshire";s:5:"value";s:2:"NH";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:30;a:4:{s:5:"label";s:10:"New Jersey";s:5:"value";s:2:"NJ";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:31;a:4:{s:5:"label";s:10:"New Mexico";s:5:"value";s:2:"NM";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:32;a:4:{s:5:"label";s:8:"New York";s:5:"value";s:2:"NY";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:33;a:4:{s:5:"label";s:14:"North Carolina";s:5:"value";s:2:"NC";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:34;a:4:{s:5:"label";s:12:"North Dakota";s:5:"value";s:2:"ND";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:35;a:4:{s:5:"label";s:4:"Ohio";s:5:"value";s:2:"OH";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:36;a:4:{s:5:"label";s:8:"Oklahoma";s:5:"value";s:2:"OK";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:37;a:4:{s:5:"label";s:6:"Oregon";s:5:"value";s:2:"OR";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:38;a:4:{s:5:"label";s:12:"Pennsylvania";s:5:"value";s:2:"PA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:39;a:4:{s:5:"label";s:12:"Rhode Island";s:5:"value";s:2:"RI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:40;a:4:{s:5:"label";s:14:"South Carolina";s:5:"value";s:2:"SC";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:41;a:4:{s:5:"label";s:12:"South Dakota";s:5:"value";s:2:"SD";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:42;a:4:{s:5:"label";s:9:"Tennessee";s:5:"value";s:2:"TN";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:43;a:4:{s:5:"label";s:5:"Texas";s:5:"value";s:2:"TX";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:44;a:4:{s:5:"label";s:4:"Utah";s:5:"value";s:2:"UT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:45;a:4:{s:5:"label";s:7:"Vermont";s:5:"value";s:2:"VT";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:46;a:4:{s:5:"label";s:8:"Virginia";s:5:"value";s:2:"VA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:47;a:4:{s:5:"label";s:10:"Washington";s:5:"value";s:2:"WA";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:48;a:4:{s:5:"label";s:13:"West Virginia";s:5:"value";s:2:"WV";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:49;a:4:{s:5:"label";s:9:"Wisconsin";s:5:"value";s:2:"WI";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:50;a:4:{s:5:"label";s:7:"Wyoming";s:5:"value";s:2:"WY";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:9:"list_type";s:8:"dropdown";s:10:"user_state";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:13:"populate_term";s:0:"";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'State'),
(12, 0, '_text', 0, 'a:23:{s:5:"label";s:15:"Zip / Post Code";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Zip / Post Code'),
(13, 0, '_country', 0, 'a:10:{s:5:"label";s:7:"Country";s:9:"label_pos";s:5:"above";s:13:"default_value";s:2:"US";s:21:"user_info_field_group";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Country'),
(14, 0, '_text', 0, 'a:25:{s:5:"label";s:5:"Email";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"1";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"0";s:10:"user_email";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Email'),
(15, 0, '_text', 0, 'a:25:{s:5:"label";s:5:"Phone";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:14:"(999) 999-9999";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"1";s:10:"user_email";s:1:"0";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"0";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Phone'),
(16, 0, '_calc', 0, 'a:20:{s:9:"calc_name";s:9:"sub_total";s:13:"default_value";s:0:"";s:17:"calc_display_type";s:4:"text";s:5:"label";s:9:"Sub Total";s:9:"label_pos";s:5:"above";s:26:"calc_display_text_disabled";s:1:"1";s:17:"calc_display_html";s:26:"<p>[ninja_forms_calc]</p>\n";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"calc_method";s:4:"auto";s:4:"calc";s:0:"";s:7:"calc_eq";s:0:"";s:19:"payment_field_group";s:1:"1";s:13:"payment_total";s:1:"0";s:17:"payment_sub_total";s:1:"1";s:11:"calc_places";s:1:"2";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Sub Total'),
(17, 0, '_calc', 0, 'a:20:{s:9:"calc_name";s:5:"total";s:13:"default_value";s:0:"";s:17:"calc_display_type";s:4:"text";s:5:"label";s:5:"Total";s:9:"label_pos";s:5:"above";s:26:"calc_display_text_disabled";s:1:"1";s:17:"calc_display_html";s:26:"<p>[ninja_forms_calc]</p>\n";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"calc_method";s:4:"auto";s:4:"calc";a:5:{i:0;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"70";}i:1;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"69";}i:2;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"15";}i:3;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"61";}i:4;a:2:{s:2:"op";s:3:"add";s:5:"field";s:2:"70";}}s:7:"calc_eq";s:5:"5 + 5";s:19:"payment_field_group";s:1:"1";s:13:"payment_total";s:1:"1";s:17:"payment_sub_total";s:1:"0";s:11:"calc_places";s:1:"2";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";}', 'Total'),
(92, 0, '_credit_card', 0, 'a:6:{s:5:"label";s:11:"Credit Card";s:19:"payment_field_group";s:1:"1";s:3:"req";s:1:"0";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:11:"conditional";s:0:"";}', 'Credit Card');

-- --------------------------------------------------------

--
-- Структура таблицы `str_ninja_forms_fields`
--

DROP TABLE IF EXISTS `str_ninja_forms_fields`;
CREATE TABLE `str_ninja_forms_fields` (
`id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `order` int(11) NOT NULL,
  `data` longtext NOT NULL,
  `fav_id` int(11) DEFAULT NULL,
  `def_id` int(11) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Дамп данных таблицы `str_ninja_forms_fields`
--

INSERT INTO `str_ninja_forms_fields` (`id`, `form_id`, `type`, `order`, `data`, `fav_id`, `def_id`) VALUES
(1, 1, '_text', 0, 'a:36:{s:5:"label";s:15:"Ваше имя";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:0:"";s:14:"user_address_2";s:0:"";s:9:"user_city";s:0:"";s:8:"user_zip";s:0:"";s:10:"user_phone";s:0:"";s:10:"user_email";s:0:"";s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"placeholder";s:0:"";s:13:"disable_input";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:10:"user_state";s:1:"0";s:16:"autocomplete_off";s:1:"0";s:8:"num_sort";s:1:"0";s:18:"default_value_type";s:0:"";s:11:"admin_label";s:0:"";s:26:"user_info_field_group_name";s:0:"";s:28:"user_info_field_group_custom";s:0:"";}', 0, 0),
(3, 1, '_textarea', 3, 'a:19:{s:5:"label";s:18:"Сообщение";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:12:"textarea_rte";s:1:"0";s:14:"textarea_media";s:1:"0";s:18:"disable_rte_mobile";s:1:"0";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";}', 0, 0),
(5, 1, '_submit', 9, 'a:7:{s:5:"label";s:18:"Отправить";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', 0, 0),
(6, 1, '_checkbox', 4, 'a:15:{s:5:"label";s:22:"Выбор да/нет";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:5:"above";s:13:"default_value";s:9:"unchecked";s:3:"req";s:1:"0";s:10:"calc_value";a:2:{s:7:"checked";s:1:"1";s:9:"unchecked";s:1:"0";}s:17:"calc_auto_include";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL),
(9, 1, '_list', 6, 'a:19:{s:5:"label";s:10:"Опции";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:4:"left";s:9:"list_type";s:5:"radio";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"0";s:4:"list";a:1:{s:7:"options";a:3:{i:0;a:4:{s:5:"label";s:8:"Option 1";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:8:"Option 2";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:8:"Option 3";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"1";s:17:"calc_auto_include";s:1:"0";s:10:"user_state";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL),
(10, 1, '_list', 7, 'a:19:{s:5:"label";s:12:"Выборы";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:4:"left";s:9:"list_type";s:8:"checkbox";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"0";s:4:"list";a:1:{s:7:"options";a:3:{i:0;a:4:{s:5:"label";s:8:"Option 1";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:8:"Option 2";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:8:"Option 3";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"0";s:17:"calc_auto_include";s:1:"0";s:10:"user_state";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL),
(11, 1, '_list', 8, 'a:19:{s:5:"label";s:18:"Выпадайка";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:5:"above";s:9:"list_type";s:8:"dropdown";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"0";s:4:"list";a:1:{s:7:"options";a:3:{i:0;a:4:{s:5:"label";s:8:"Option 1";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:8:"Option 2";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:8:"Option 3";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"1";s:17:"calc_auto_include";s:1:"0";s:10:"user_state";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL),
(12, 1, '_desc', 5, 'a:8:{s:5:"label";s:4:"Text";s:15:"input_limit_msg";s:17:"character(s) left";s:13:"default_value";s:116:"проверка текстового сообщения\r\n\r\nпроверка текстового сообщения";s:7:"desc_el";s:3:"div";s:5:"class";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL),
(14, 1, '_text', 1, 'a:40:{s:5:"label";s:5:"Email";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"1";s:10:"send_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"0";s:10:"user_email";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";s:11:"placeholder";s:0:"";s:13:"disable_input";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:10:"user_state";s:1:"0";s:16:"autocomplete_off";s:1:"0";s:8:"num_sort";s:1:"0";s:18:"default_value_type";s:0:"";s:11:"admin_label";s:0:"";s:26:"user_info_field_group_name";s:0:"";s:28:"user_info_field_group_custom";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:13:"replyto_email";i:0;}', NULL, 14),
(15, 1, '_hidden', 2, 'a:13:{s:5:"label";s:16:"Проверка";s:15:"input_limit_msg";s:17:"character(s) left";s:18:"default_value_type";s:7:"_custom";s:13:"default_value";s:1:"2";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:17:"calc_auto_include";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL),
(16, 5, '_text', 1, 'a:40:{s:5:"label";s:12:"Ваш email";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"1";s:10:"send_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"0";s:10:"user_email";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";s:11:"placeholder";s:0:"";s:13:"disable_input";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:10:"user_state";s:1:"0";s:16:"autocomplete_off";s:1:"0";s:8:"num_sort";s:1:"0";s:18:"default_value_type";s:0:"";s:11:"admin_label";s:0:"";s:26:"user_info_field_group_name";s:0:"";s:28:"user_info_field_group_custom";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:13:"replyto_email";i:0;}', NULL, 14),
(17, 5, '_submit', 2, 'a:8:{s:5:"label";s:22:"Подписаться";s:15:"input_limit_msg";s:17:"character(s) left";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL),
(18, 5, '_desc', 0, 'a:8:{s:5:"label";s:4:"Text";s:15:"input_limit_msg";s:17:"character(s) left";s:13:"default_value";s:230:"Время от времени мы будем присылать вам анонсы наших мероприятий или новости из жизни наших подопечных. Оставайтесь на связи!";s:7:"desc_el";s:3:"div";s:5:"class";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `str_options`
--

DROP TABLE IF EXISTS `str_options`;
CREATE TABLE `str_options` (
`option_id` bigint(20) unsigned NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1123 ;

--
-- Дамп данных таблицы `str_options`
--

INSERT INTO `str_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://giger.local/core', 'yes'),
(2, 'home', 'http://giger.local', 'yes'),
(3, 'blogname', 'GIGER', 'yes'),
(4, 'blogdescription', 'Благотворительный фонд помощи нуждающимся в IT-просвещении', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'support@te-st.ru', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:16:{i:0;s:49:"cmb2-attached-posts/cmb2-attached-posts-field.php";i:1;s:13:"cmb2/init.php";i:2;s:35:"crop-thumbnails/crop-thumbnails.php";i:3;s:22:"cyr3lat/cyr-to-lat.php";i:4;s:37:"disable-comments/disable-comments.php";i:5;s:21:"imsanity/imsanity.php";i:6;s:15:"leyka/leyka.php";i:7;s:47:"media-search-enhanced/media-search-enhanced.php";i:8;s:27:"ninja-forms/ninja-forms.php";i:9;s:38:"post-duplicator/m4c-postduplicator.php";i:10;s:43:"responsive-lightbox/responsive-lightbox.php";i:11;s:43:"simple-css-for-widgets/simplecsswidgets.php";i:12;s:62:"simple-google-maps-short-code/simple-google-map-short-code.php";i:13;s:29:"widget-logic/widget_logic.php";i:14;s:49:"wp-sync-db-media-files/wp-sync-db-media-files.php";i:15;s:25:"wp-sync-db/wp-sync-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '3', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', '', 'no'),
(41, 'template', 'tstnext', 'yes'),
(42, 'stylesheet', 'tstnext', 'yes'),
(43, 'comment_whitelist', '1', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '35700', 'yes'),
(50, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'page', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '150', 'yes'),
(60, 'thumbnail_size_h', '150', 'yes'),
(61, 'thumbnail_crop', '1', 'yes'),
(62, 'medium_size_w', '300', 'yes'),
(63, 'medium_size_h', '300', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '1024', 'yes'),
(66, 'large_size_h', '1024', 'yes'),
(67, 'image_default_link_type', 'file', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:5:{i:2;a:3:{s:5:"title";s:0:"";s:4:"text";s:212:"[fab url="http://giger.local/campaign/help-us/"]\r\n\r\n<h4>Вы можете помочь нам уже сейчас - нажмите на сердечко, чтобы сделать пожертвование!</h4>";s:6:"filter";b:1;}i:3;a:3:{s:5:"title";s:13:"О фонде";s:4:"text";s:443:"Фонд был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью.\r\n\r\n<a href="//giger.local/about/" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">Подробнее</a>";s:6:"filter";b:1;}i:4;a:3:{s:5:"title";s:31:"Важная программа";s:4:"text";s:376:"Измените тексты этого нижнего блока в настройках виджетов. Здесь можно указать контакты или другую полезную информацию или сообщение.\r\n\r\n<a href="//giger.local/about/" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">Подробнее</a>";s:6:"filter";b:1;}i:5;a:3:{s:5:"title";s:33:"Важная информация";s:4:"text";s:376:"Измените тексты этого нижнего блока в настройках виджетов. Здесь можно указать контакты или другую полезную информацию или сообщение.\r\n\r\n<a href="//giger.local/about/" class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored">Подробнее</a>";s:6:"filter";b:1;}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:0:{}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '74', 'yes'),
(85, 'page_on_front', '72', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '31536', 'yes'),
(89, 'str_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:99:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:13:"edit_donation";b:1;s:13:"edit_campaign";b:1;s:13:"read_donation";b:1;s:13:"read_campaign";b:1;s:15:"delete_donation";b:1;s:15:"delete_campaign";b:1;s:14:"edit_donations";b:1;s:14:"edit_campaigns";b:1;s:21:"edit_others_donations";b:1;s:21:"edit_others_campaigns";b:1;s:17:"publish_donations";b:1;s:17:"publish_campaigns";b:1;s:22:"read_private_donations";b:1;s:22:"read_private_campaigns";b:1;s:16:"delete_donations";b:1;s:16:"delete_campaigns";b:1;s:24:"delete_private_donations";b:1;s:24:"delete_private_campaigns";b:1;s:26:"delete_published_donations";b:1;s:26:"delete_published_campaigns";b:1;s:23:"delete_others_donations";b:1;s:23:"delete_others_campaigns";b:1;s:22:"edit_private_donations";b:1;s:22:"edit_private_campaigns";b:1;s:24:"edit_published_donations";b:1;s:24:"edit_published_campaigns";b:1;s:22:"leyka_manage_donations";b:1;s:20:"leyka_manage_options";b:1;s:14:"frm_view_forms";b:1;s:14:"frm_edit_forms";b:1;s:16:"frm_delete_forms";b:1;s:19:"frm_change_settings";b:1;s:16:"frm_view_entries";b:1;s:18:"frm_delete_entries";b:1;s:18:"frm_create_entries";b:1;s:16:"frm_edit_entries";b:1;s:16:"frm_view_reports";b:1;s:17:"frm_edit_displays";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:17:"donations_manager";a:2:{s:4:"name";s:43:"Менеджер пожертвований";s:12:"capabilities";a:30:{s:4:"read";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:22:"leyka_manage_donations";b:1;s:13:"edit_donation";b:1;s:13:"edit_campaign";b:1;s:13:"read_donation";b:1;s:13:"read_campaign";b:1;s:15:"delete_donation";b:1;s:15:"delete_campaign";b:1;s:14:"edit_donations";b:1;s:14:"edit_campaigns";b:1;s:21:"edit_others_donations";b:1;s:21:"edit_others_campaigns";b:1;s:17:"publish_donations";b:1;s:17:"publish_campaigns";b:1;s:22:"read_private_donations";b:1;s:22:"read_private_campaigns";b:1;s:16:"delete_donations";b:1;s:16:"delete_campaigns";b:1;s:24:"delete_private_donations";b:1;s:24:"delete_private_campaigns";b:1;s:26:"delete_published_donations";b:1;s:26:"delete_published_campaigns";b:1;s:23:"delete_others_donations";b:1;s:23:"delete_others_campaigns";b:1;s:22:"edit_private_donations";b:1;s:22:"edit_private_campaigns";b:1;s:24:"edit_published_donations";b:1;s:24:"edit_published_campaigns";b:1;}}s:23:"donations_administrator";a:2:{s:4:"name";s:53:"Администратор пожертвований";s:12:"capabilities";a:31:{s:4:"read";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:22:"leyka_manage_donations";b:1;s:13:"edit_donation";b:1;s:13:"edit_campaign";b:1;s:13:"read_donation";b:1;s:13:"read_campaign";b:1;s:15:"delete_donation";b:1;s:15:"delete_campaign";b:1;s:14:"edit_donations";b:1;s:14:"edit_campaigns";b:1;s:21:"edit_others_donations";b:1;s:21:"edit_others_campaigns";b:1;s:17:"publish_donations";b:1;s:17:"publish_campaigns";b:1;s:22:"read_private_donations";b:1;s:22:"read_private_campaigns";b:1;s:16:"delete_donations";b:1;s:16:"delete_campaigns";b:1;s:24:"delete_private_donations";b:1;s:24:"delete_private_campaigns";b:1;s:26:"delete_published_donations";b:1;s:26:"delete_published_campaigns";b:1;s:23:"delete_others_donations";b:1;s:23:"delete_others_campaigns";b:1;s:22:"edit_private_donations";b:1;s:22:"edit_private_campaigns";b:1;s:24:"edit_published_donations";b:1;s:24:"edit_published_campaigns";b:1;s:20:"leyka_manage_options";b:1;}}}', 'yes'),
(90, 'WPLANG', 'ru_RU', 'yes'),
(91, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'sidebars_widgets', 'a:6:{s:19:"wp_inactive_widgets";a:0:{}s:13:"right-sidebar";a:3:{i:0;s:6:"text-2";i:1;s:10:"nav_menu-4";i:2;s:10:"nav_menu-3";}s:16:"footer_1-sidebar";a:1:{i:0;s:6:"text-3";}s:16:"footer_2-sidebar";a:1:{i:0;s:6:"text-4";}s:16:"footer_3-sidebar";a:1:{i:0;s:6:"text-5";}s:13:"array_version";i:3;}', 'yes'),
(99, 'cron', 'a:8:{i:1449792369;a:1:{s:29:"wp_session_garbage_collection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1449808260;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1449822340;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1449822352;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1449838750;a:1:{s:24:"refresh_currencies_rates";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1449842333;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1449867420;a:1:{s:24:"ninja_forms_daily_action";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(109, '_transient_random_seed', '90aef9de6e937319d6469ebe2a4ef568', 'yes'),
(142, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1442564866;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(143, 'current_theme', 'TST Next', 'yes'),
(144, 'theme_mods_tstnext', 'a:5:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:7:"primary";i:5;s:7:"sitemap";i:6;s:6:"social";i:10;}s:17:"default_thumbnail";s:51:"//giger.local/wp-content/uploads/2015/09/spring.jpg";s:11:"footer_text";s:74:"GIGER. Смените этот текст в настройках темы";s:18:"newsletter_form_id";s:1:"5";}', 'yes'),
(145, 'theme_switched', '', 'yes'),
(146, 'finished_splitting_shared_terms', '1', 'yes'),
(147, 'db_upgraded', '', 'yes'),
(154, 'recently_activated', 'a:0:{}', 'yes'),
(162, 'responsive_lightbox_version', '1.6.5', 'yes'),
(163, 'responsive_lightbox_settings', 'a:17:{s:6:"script";s:8:"swipebox";s:8:"selector";s:8:"lightbox";s:9:"galleries";b:1;s:18:"gallery_image_size";s:4:"full";s:19:"gallery_image_title";s:7:"default";s:20:"force_custom_gallery";b:1;s:6:"videos";b:0;s:11:"image_links";b:1;s:11:"image_title";s:7:"default";s:17:"images_as_gallery";b:1;s:19:"deactivation_delete";b:0;s:13:"loading_place";s:6:"footer";s:19:"conditional_loading";b:1;s:20:"enable_custom_events";b:0;s:13:"custom_events";s:12:"ajaxComplete";s:14:"update_version";i:1;s:13:"update_notice";b:0;}', 'no'),
(164, 'responsive_lightbox_configuration', 'a:6:{s:11:"prettyphoto";a:21:{s:15:"animation_speed";s:6:"normal";s:9:"slideshow";b:0;s:15:"slideshow_delay";i:5000;s:18:"slideshow_autoplay";b:0;s:7:"opacity";i:75;s:10:"show_title";b:1;s:12:"allow_resize";b:1;s:12:"allow_expand";b:1;s:5:"width";i:1080;s:6:"height";i:720;s:9:"separator";s:1:"/";s:5:"theme";s:10:"pp_default";s:18:"horizontal_padding";i:20;s:10:"hide_flash";b:0;s:5:"wmode";s:6:"opaque";s:14:"video_autoplay";b:0;s:5:"modal";b:0;s:11:"deeplinking";b:0;s:15:"overlay_gallery";b:1;s:18:"keyboard_shortcuts";b:1;s:6:"social";b:0;}s:8:"swipebox";a:8:{s:9:"animation";s:3:"css";s:15:"hide_bars_delay";d:5000;s:15:"video_max_width";d:1080;s:15:"force_png_icons";b:0;s:17:"hide_close_mobile";b:0;s:18:"remove_bars_mobile";b:0;s:9:"hide_bars";b:0;s:11:"loop_at_end";b:0;}s:8:"fancybox";a:25:{s:5:"modal";b:0;s:12:"show_overlay";b:1;s:17:"show_close_button";b:1;s:20:"enable_escape_button";b:1;s:21:"hide_on_overlay_click";b:1;s:21:"hide_on_content_click";b:0;s:6:"cyclic";b:0;s:15:"show_nav_arrows";b:1;s:10:"auto_scale";b:1;s:9:"scrolling";s:3:"yes";s:16:"center_on_scroll";b:1;s:7:"opacity";b:1;s:15:"overlay_opacity";i:70;s:13:"overlay_color";s:4:"#666";s:10:"title_show";b:1;s:14:"title_position";s:7:"outside";s:11:"transitions";s:4:"fade";s:7:"easings";s:5:"swing";s:6:"speeds";i:300;s:12:"change_speed";i:300;s:11:"change_fade";i:100;s:7:"padding";i:5;s:6:"margin";i:5;s:11:"video_width";i:1080;s:12:"video_height";i:720;}s:4:"nivo";a:4:{s:6:"effect";s:4:"fade";s:22:"click_overlay_to_close";b:1;s:12:"keyboard_nav";b:1;s:13:"error_message";s:63:"The requested content cannot be loaded. Please try again later.";}s:13:"imagelightbox";a:6:{s:15:"animation_speed";i:250;s:12:"preload_next";b:1;s:15:"enable_keyboard";b:1;s:11:"quit_on_end";b:0;s:19:"quit_on_image_click";b:0;s:22:"quit_on_document_click";b:1;}s:6:"tosrus";a:8:{s:6:"effect";s:5:"slide";s:8:"infinite";b:1;s:4:"keys";b:0;s:8:"autoplay";b:1;s:14:"pause_on_hover";b:0;s:7:"timeout";i:4000;s:10:"pagination";b:1;s:15:"pagination_type";s:10:"thumbnails";}}', 'no'),
(165, 'leyka_currency_rur2usd', '65.3623', 'yes'),
(166, 'leyka_currency_rur2eur', '73.9378', 'yes'),
(167, 'leyka_pm_order', 'pm_order[]=quittance-bank_order&amp;pm_order[]=text-text_box', 'yes'),
(168, 'leyka_permalinks_flushed', '1', 'yes'),
(169, 'leyka_last_ver', '2.2.8', 'yes'),
(170, 'disable_comments_options', 'a:5:{s:19:"disabled_post_types";a:3:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:10:"attachment";}s:17:"remove_everywhere";b:1;s:9:"permanent";b:0;s:16:"extra_post_types";b:0;s:10:"db_version";i:6;}', 'yes'),
(171, 'wpsdb_settings', 'a:7:{s:11:"max_request";i:1048576;s:3:"key";s:32:"2dvSLUsPobSI48aSTvlTa480xfiADOzu";s:10:"allow_pull";b:0;s:10:"allow_push";b:0;s:8:"profiles";a:0:{}s:10:"verify_ssl";b:0;s:17:"blacklist_plugins";a:0:{}}', 'yes'),
(173, 'leyka_chronopay-chronopay_card_description', 'Платёжная система Chronopay предоставляет простую и безопасную возможность оплаты товаров и услуг через Интернет. Вам будет нужно заполнить форму пожертвования, затем вы будете перенаправлены на защищённую &lt;a href=&quot;http://www.chronopay.com/ru/&quot;&gt;страницу Chronopay&lt;/a&gt;, где вы сможете указать ваши банковские данные и подтвердить совершение вашего пожертвования.', 'yes'),
(174, 'leyka_chronopay_card_product_id_rur', '', 'yes'),
(175, 'leyka_chronopay_card_product_id_usd', '', 'yes'),
(176, 'leyka_chronopay_card_product_id_eur', '', 'yes'),
(177, 'leyka_chronopay-chronopay_card_label', 'Банковская карта', 'yes'),
(178, 'leyka_chronopay-chronopay_card_rebill_description', 'Платёжная система Chronopay предоставляет простую и безопасную возможность оплаты товаров и услуг через Интернет. Вам будет нужно заполнить форму пожертвования, затем вы будете перенаправлены на защищённую &lt;a href=&quot;http://www.chronopay.com/ru/&quot;&gt;страницу Chronopay&lt;/a&gt;, где вы сможете указать ваши банковские данные и подтвердить совершение вашего пожертвования.', 'yes'),
(179, 'leyka_chronopay_card_rebill_product_id_rur', '', 'yes'),
(180, 'leyka_chronopay-chronopay_card_rebill_label', 'Банковская карта - автоматические ежемесячные списания', 'yes'),
(181, 'leyka_chronopay_shared_sec', '', 'yes'),
(182, 'leyka_chronopay_ip', '159.255.220.140', 'yes'),
(183, 'leyka_cp-card_description', '&lt;a href=&quot;//cloudpayments.ru/&quot;&gt;CloudPayments&lt;/a&gt; - это конструктор IT-решений для участников рынка электронной коммерции. Партнеры получают самый полный набор ключевых технических опций, позволяющих создать клиентоориентированную систему оплаты на сайте или в мобильном приложении. Партнеры имеют возможность принимать платежи не только в рублях, но и других валютах мира.', 'yes'),
(184, 'leyka_cp-card_label', 'Банковская карта', 'yes'),
(185, 'leyka_cp_public_id', '', 'yes'),
(186, 'leyka_cp_ip', '130.193.70.192', 'yes'),
(187, 'leyka_cp_test_mode', '1', 'yes'),
(188, 'leyka_quittance-bank_order_description', 'Платёж с помощью банковской квитанции позволяет вам сделать пожертвование через любой банк. Вы можете распечатать заполненную квитанцию и принести её в банк, чтобы выполнить платёж.', 'yes'),
(189, 'leyka_quittance-bank_order_label', 'Банковская платёжная квитанция', 'yes'),
(190, 'leyka_quittance_redirect_page', '293', 'yes'),
(191, 'leyka_rbk-bankcard_description', 'Платежный сервис &lt;a href=&quot;https://rbkmoney.ru/&quot;&gt;RBK Money&lt;/a&gt; представляет собой современную, простую и удобную платформу для осуществления переводов различными популярными способами, включая банковские карты VISA и Mastercard, мобильные и онлайн платежи, широкую сеть оффлайн отделений и терминалов и множество других способов платежа.', 'yes'),
(192, 'leyka_rbk-bankcard_label', 'Банковская карта', 'yes'),
(193, 'leyka_rbk-rbkmoney_description', 'Платежный сервис &lt;a href=&quot;https://rbkmoney.ru/&quot;&gt;RBK Money&lt;/a&gt; представляет собой современную, простую и удобную платформу для осуществления переводов различными популярными способами, включая банковские карты VISA и Mastercard, мобильные и онлайн платежи, широкую сеть оффлайн отделений и терминалов и множество других способов платежа.', 'yes'),
(194, 'leyka_rbk-rbkmoney_label', 'RBK Money', 'yes'),
(195, 'leyka_rbk-rbk_all_description', 'Платежный сервис &lt;a href=&quot;https://rbkmoney.ru/&quot;&gt;RBK Money&lt;/a&gt; представляет собой современную, простую и удобную платформу для осуществления переводов различными популярными способами, включая банковские карты VISA и Mastercard, мобильные и онлайн платежи, широкую сеть оффлайн отделений и терминалов и множество других способов платежа.', 'yes'),
(196, 'leyka_rbk-rbk_all_label', 'RBK Money (любой способ платежа)', 'yes'),
(197, 'leyka_rbk_eshop_id', '', 'yes'),
(198, 'leyka_rbk_eshop_account', '', 'yes'),
(199, 'leyka_rbk_use_hash', '0', 'yes'),
(200, 'leyka_rbk_hash_type', 'md5', 'yes'),
(201, 'leyka_rbk_secret_key', '', 'yes'),
(202, 'leyka_robokassa-BANKOCEAN2_description', '&lt;a href=&quot;http://www.robokassa.ru/&quot;&gt;ROBOKASSA&lt;/a&gt; - это сервис, позволяющий интернет-магазинам или поставщикам услуг принимать платежи от клиентов с помощью банковских карт, в любой электронной валюте, с помощью мобильных платежей (МТС, Мегафон, Билайн), а также через интернет-банк и ведущих Банков РФ, через банкоматы и терминалы мгновенной оплаты.', 'yes'),
(203, 'leyka_robokassa-BANKOCEAN2_label', 'Банковская карта', 'yes'),
(204, 'leyka_robokassa-YandexMerchantOcean_description', '&lt;a href=&quot;http://www.robokassa.ru/&quot;&gt;ROBOKASSA&lt;/a&gt; - это сервис, позволяющий интернет-магазинам или поставщикам услуг принимать платежи от клиентов с помощью банковских карт, в любой электронной валюте, с помощью мобильных платежей (МТС, Мегафон, Билайн), а также через интернет-банк и ведущих Банков РФ, через банкоматы и терминалы мгновенной оплаты.', 'yes'),
(205, 'leyka_robokassa-YandexMerchantOcean_label', 'Яндекс.Деньги', 'yes'),
(206, 'leyka_robokassa-WMR_description', '&lt;a href=&quot;http://www.robokassa.ru/&quot;&gt;ROBOKASSA&lt;/a&gt; - это сервис, позволяющий интернет-магазинам или поставщикам услуг принимать платежи от клиентов с помощью банковских карт, в любой электронной валюте, с помощью мобильных платежей (МТС, Мегафон, Билайн), а также через интернет-банк и ведущих Банков РФ, через банкоматы и терминалы мгновенной оплаты.', 'yes'),
(207, 'leyka_robokassa-WMR_label', 'WebMoney', 'yes'),
(208, 'leyka_robokassa-Qiwi30Ocean_description', '&lt;a href=&quot;http://www.robokassa.ru/&quot;&gt;ROBOKASSA&lt;/a&gt; - это сервис, позволяющий интернет-магазинам или поставщикам услуг принимать платежи от клиентов с помощью банковских карт, в любой электронной валюте, с помощью мобильных платежей (МТС, Мегафон, Билайн), а также через интернет-банк и ведущих Банков РФ, через банкоматы и терминалы мгновенной оплаты.', 'yes'),
(209, 'leyka_robokassa-Qiwi30Ocean_label', 'Qiwi-кошелёк', 'yes'),
(210, 'leyka_robokassa-Other_description', '&lt;a href=&quot;http://www.robokassa.ru/&quot;&gt;ROBOKASSA&lt;/a&gt; - это сервис, позволяющий интернет-магазинам или поставщикам услуг принимать платежи от клиентов с помощью банковских карт, в любой электронной валюте, с помощью мобильных платежей (МТС, Мегафон, Билайн), а также через интернет-банк и ведущих Банков РФ, через банкоматы и терминалы мгновенной оплаты.', 'yes'),
(211, 'leyka_robokassa-Other_label', 'Робокасса (любой способ платежа)', 'yes'),
(212, 'leyka_robokassa_shop_id', '', 'yes'),
(213, 'leyka_robokassa_shop_password1', '', 'yes'),
(214, 'leyka_robokassa_shop_password2', '', 'yes'),
(215, 'leyka_robokassa_test_mode', '1', 'yes'),
(216, 'leyka_text-text_box_description', 'Вы можете сделать пожертвование с помощью указанных здесь способов.', 'yes'),
(217, 'leyka_text_box_details', 'Может еще какой способ вспомним.', 'yes'),
(218, 'leyka_text-text_box_label', 'Дополнительные способы', 'yes'),
(219, 'leyka_yandex-yandex_card_description', 'Яндекс.Деньги — доступный и безопасный способ платить за товары и услуги через интернет. Заполнив форму оплаты на нашем сайте, вы будете перенаправлены на &lt;a href=&quot;https://money.yandex.ru/&quot;&gt;сайт Яндекс.Денег&lt;/a&gt;, где сможете указать параметры вашей банковской карты и завершить платеж.', 'yes'),
(220, 'leyka_yandex-yandex_card_label', 'Банковская карта', 'yes'),
(221, 'leyka_yandex-yandex_money_description', 'Яндекс.Деньги — доступный и безопасный способ платить за товары и услуги через интернет. Заполнив форму оплаты на нашем сайте, вы будете перенаправлены на &lt;a href=&quot;https://money.yandex.ru/&quot;&gt;сайт Яндекс.Денег&lt;/a&gt;, где сможете завершить платеж. Если у вас нет счета в Яндекс.Деньгах, его нужно открыть на сайте платежной системы.', 'yes'),
(222, 'leyka_yandex-yandex_money_label', 'Яндекс.деньги', 'yes'),
(223, 'leyka_yandex-yandex_wm_description', '&lt;a href=&quot;http://www.webmoney.ru/&quot;&gt;WebMoney Transfer&lt;/a&gt; - международная система расчетов и среда для ведения бизнеса в сети, основана в 1998 году. За это время к системе присоединилось более 25 миллионов человек по всему миру. В системе WebMoney предусмотрены сервисы, позволяющие вести учет, обменивать расчетные средства, привлекать финансирование, решать споры и заключать безопасные сделки.', 'yes'),
(224, 'leyka_yandex-yandex_wm_label', 'WebMoney', 'yes'),
(225, 'leyka_yandex_shop_id', '', 'yes'),
(226, 'leyka_yandex_scid', '', 'yes'),
(227, 'leyka_yandex_shop_article_id', '', 'yes'),
(228, 'leyka_yandex_test_mode', '1', 'yes'),
(229, 'leyka_yandex_phyz-yandex_phyz_card_description', 'Яндекс.Деньги — доступный и безопасный способ платить за товары и услуги через интернет. Заполнив форму оплаты на нашем сайте, вы будете перенаправлены на &lt;a href=&quot;https://money.yandex.ru/&quot;&gt;сайт Яндекс.Денег&lt;/a&gt;, где сможете указать параметры вашей банковской карты и завершить платеж.', 'yes'),
(230, 'leyka_yandex_phyz-yandex_phyz_card_label', 'Платёж с помощью банковской карты', 'yes'),
(231, 'leyka_yandex_phyz-yandex_phyz_money_description', 'Яндекс.Деньги — доступный и безопасный способ платить за товары и услуги через интернет. Заполнив форму оплаты на нашем сайте, вы будете перенаправлены на &lt;a href=&quot;https://money.yandex.ru/&quot;&gt;сайт Яндекс.Денег&lt;/a&gt;, где сможете завершить платеж. Если у вас нет счета в Яндекс.Деньгах, его нужно открыть на сайте платежной системы.', 'yes'),
(232, 'leyka_yandex_phyz-yandex_phyz_money_label', 'Виртуальная валюта Яндекс.Деньги', 'yes'),
(233, 'leyka_yandex_money_account', '', 'yes'),
(234, 'leyka_yandex_money_secret', '', 'yes'),
(237, 'mtphr_post_duplicator_settings', '', 'yes'),
(263, 'category_children', 'a:0:{}', 'yes'),
(276, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(280, 'widget_css', 'a:8:{s:8:"search-2";s:0:"";s:6:"text-2";s:13:"donate-widget";s:10:"nav_menu-2";s:24:"mdl-card mdl-shadow--2dp";s:6:"text-3";s:0:"";s:10:"nav_menu-3";s:24:"mdl-card mdl-shadow--2dp";s:10:"nav_menu-4";s:24:"mdl-card mdl-shadow--2dp";s:6:"text-4";s:0:"";s:6:"text-5";s:0:"";}', 'yes'),
(281, 'widget_logic', 'a:6:{s:6:"text-2";s:0:"";s:10:"nav_menu-3";s:10:"is_about()";s:10:"nav_menu-4";s:77:"is_page(\\''activity\\'') || is_projects() || is_page(\\''calendar\\'') || is_posts()";s:6:"text-3";s:0:"";s:6:"text-4";s:0:"";s:6:"text-5";s:0:"";}', 'yes'),
(282, '_transient_timeout_ab79495a08ee2089e1995a0d13f36d15', '1450367812', 'no'),
(283, '_transient_ab79495a08ee2089e1995a0d13f36d15', 'a:3:{s:3:"lat";d:55.75582299999999946749085211195051670074462890625;s:3:"lng";d:37.6338539999999994734025676734745502471923828125;s:7:"address";s:46:"Lubyanskiy pr-d, 19с1, Moskva, Russia, 101000";}', 'no'),
(316, 'widget_nav_menu', 'a:3:{i:3;a:2:{s:5:"title";s:17:"В разделе";s:8:"nav_menu";i:8;}i:4;a:2:{s:5:"title";s:17:"В разделе";s:8:"nav_menu";i:9;}s:12:"_multiwidget";i:1;}', 'yes'),
(317, 'leyka_pm_available', 'a:2:{i:0;s:20:"quittance-bank_order";i:1;s:13:"text-text_box";}', 'yes'),
(318, 'leyka_donation_form_mode', '0', 'yes'),
(319, 'leyka_donations_history_under_forms', '0', 'yes'),
(320, 'leyka_show_campaign_sharing', '0', 'yes'),
(321, 'leyka_scale_widget_place', '-', 'yes'),
(323, 'widget_leyka_campaigns_list', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(324, 'widget_leyka_donations_list', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(325, 'widget_leyka_campaign_card', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(326, 'widget_widget_featured_product', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(327, 'widget_widget_socila_links', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes');
INSERT INTO `str_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(389, 'wpsdb_error_log', '********************************************\n******  Log date: 2015/09/19 09:57:25 ******\n********************************************\n\nWPSDB Error: The remote site is protected with Basic Authentication. Please enter the username and password above to continue. (401 Unauthorized)\n\nAttempted to connect to: http://giger.local/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Sat, 19 Sep 2015 09:57:25 GMT\n            [content-type] => text/html; charset=iso-8859-1\n            [content-length] => 290\n            [connection] => close\n            [www-authenticate] => Basic realm="ngo2.ru"\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>401 Authorization Required</title>\n</head><body>\n<h1>Authorization Required</h1>\n<p>This server could not verify that you\nare authorized to access the document\nrequested.  Either you supplied the wrong\ncredentials (e.g., bad password), or your\nbrowser doesn''t understand how to supply\nthe credentials required.</p>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 401\n            [message] => Authorization Required\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/09/19 09:57:34 ******\n********************************************\n\nWPSDB Error: There was a problem with the AJAX request, we were expecting a serialized response, instead we received:<br />&lt;br /&gt;\n&lt;b&gt;Notice&lt;/b&gt;:  Вызванный метод конструктора класса WP_Widget считается &lt;strong&gt;устаревшим&lt;/strong&gt; с версии 4.3.0! Используйте &lt;pre&gt;__construct()&lt;/pre&gt;. in &lt;b&gt;/home/dev/web/ngo2.ru/public_html/start/wp-includes/functions.php&lt;/b&gt; on line &lt;b&gt;3457&lt;/b&gt;&lt;br /&gt;\na:22:{s:6:&quot;tables&quot;;a:20:{i:0;s:17:&quot;str_aiowps_events&quot;;i:1;s:24:&quot;str_aiowps_failed_logins&quot;;i:2;s:22:&quot;str_aiowps_global_meta&quot;;i:3;s:25:&quot;str_aiowps_login_activity&quot;;i:4;s:25:&quot;str_aiowps_login_lockdown&quot;;i:5;s:15:&quot;str_commentmeta&quot;;i:6;s:12:&quot;str_comments&quot;;i:7;s:14:&quot;str_frm_fields&quot;;i:8;s:13:&quot;str_frm_forms&quot;;i:9;s:18:&quot;str_frm_item_metas&quot;;i:10;s:13:&quot;str_frm_items&quot;;i:11;s:9:&quot;str_links&quot;;i:12;s:11:&quot;str_options&quot;;i:13;s:12:&quot;str_postmeta&quot;;i:14;s:9:&quot;str_posts&quot;;i:15;s:22:&quot;str_term_relationships&quot;;i:16;s:17:&quot;str_term_taxonomy&quot;;i:17;s:9:&quot;str_terms&quot;;i:18;s:12:&quot;str_usermeta&quot;;i:19;s:9:&quot;str_users&quot;;}s:15:&quot;prefixed_tables&quot;;a:20:{i:0;s:17:&quot;str_aiowps_events&quot;;i:1;s:24:&quot;str_aiowps_failed_logins&quot;;i:2;s:22:&quot;str_aiowps_global_meta&quot;;i:3;s:25:&quot;str_aiowps_login_activity&quot;;i:4;s:25:&quot;str_aiowps_login_lockdown&quot;;i:5;s:15:&quot;str_commentmeta&quot;;i:6;s:12:&quot;str_comments&quot;;i:7;s:14:&quot;str_frm_fields&quot;;i:8;s:13:&quot;str_frm_forms&quot;;i:9;s:18:&quot;str_frm_item_metas&quot;;i:10;s:13:&quot;str_frm_items&quot;;i:11;s:9:&quot;str_links&quot;;i:12;s:11:&quot;str_options&quot;;i:13;s:12:&quot;str_postmeta&quot;;i:14;s:9:&quot;str_posts&quot;;i:15;s:22:&quot;str_term_relationships&quot;;i:16;s:17:&quot;str_term_taxonomy&quot;;i:17;s:9:&quot;str_terms&quot;;i:18;s:12:&quot;str_usermeta&quot;;i:19;s:9:&quot;str_users&quot;;}s:11:&quot;table_sizes&quot;;a:20:{s:17:&quot;str_aiowps_events&quot;;s:1:&quot;1&quot;;s:24:&quot;str_aiowps_failed_logins&quot;;s:1:&quot;2&quot;;s:22:&quot;str_aiowps_global_meta&quot;;s:3:&quot;696&quot;;s:25:&quot;str_aiowps_login_activity&quot;;s:1:&quot;2&quot;;s:25:&quot;str_aiowps_login_lockdown&quot;;s:1:&quot;1&quot;;s:15:&quot;str_commentmeta&quot;;s:1:&quot;4&quot;;s:12:&quot;str_comments&quot;;s:1:&quot;7&quot;;s:14:&quot;str_frm_fields&quot;;s:2:&quot;81&quot;;s:13:&quot;str_frm_forms&quot;;s:2:&quot;18&quot;;s:18:&quot;str_frm_item_metas&quot;;s:1:&quot;4&quot;;s:13:&quot;str_frm_items&quot;;s:1:&quot;9&quot;;s:9:&quot;str_links&quot;;s:1:&quot;4&quot;;s:11:&quot;str_options&quot;;s:3:&quot;595&quot;;s:12:&quot;str_postmeta&quot;;s:2:&quot;71&quot;;s:9:&quot;str_posts&quot;;s:3:&quot;175&quot;;s:22:&quot;str_term_relationships&quot;;s:1:&quot;6&quot;;s:17:&quot;str_term_taxonomy&quot;;s:1:&quot;5&quot;;s:9:&quot;str_terms&quot;;s:2:&quot;14&quot;;s:12:&quot;str_usermeta&quot;;s:2:&quot;22&quot;;s:9:&quot;str_users&quot;;s:1:&quot;6&quot;;}s:10:&quot;table_rows&quot;;a:20:{s:17:&quot;str_aiowps_events&quot;;i:1;s:24:&quot;str_aiowps_failed_logins&quot;;s:1:&quot;1&quot;;s:22:&quot;str_aiowps_global_meta&quot;;s:1:&quot;1&quot;;s:25:&quot;str_aiowps_login_activity&quot;;s:1:&quot;2&quot;;s:25:&quot;str_aiowps_login_lockdown&quot;;i:1;s:15:&quot;str_commentmeta&quot;;i:1;s:12:&quot;str_comments&quot;;s:1:&quot;1&quot;;s:14:&quot;str_frm_fields&quot;;s:2:&quot;87&quot;;s:13:&quot;str_frm_forms&quot;;s:1:&quot;6&quot;;s:18:&quot;str_frm_item_metas&quot;;s:1:&quot;1&quot;;s:13:&quot;str_frm_items&quot;;s:1:&quot;1&quot;;s:9:&quot;str_links&quot;;s:1:&quot;7&quot;;s:11:&quot;str_options&quot;;s:3:&quot;201&quot;;s:12:&quot;str_postmeta&quot;;s:3:&quot;483&quot;;s:9:&quot;str_posts&quot;;s:3:&quot;116&quot;;s:22:&quot;str_term_relationships&quot;;s:2:&quot;54&quot;;s:17:&quot;str_term_taxonomy&quot;;s:2:&quot;17&quot;;s:9:&quot;str_terms&quot;;s:2:&quot;17&quot;;s:12:&quot;str_usermeta&quot;;s:3:&quot;120&quot;;s:9:&quot;str_users&quot;;s:1:&quot;5&quot;;}s:14:&quot;table_sizes_hr&quot;;a:20:{s:17:&quot;str_aiowps_events&quot;;s:4:&quot;1 kB&quot;;s:24:&quot;str_aiowps_failed_logins&quot;;s:4:&quot;2 kB&quot;;s:22:&quot;str_aiowps_global_meta&quot;;s:6:&quot;696 kB&quot;;s:25:&quot;str_aiowps_login_activity&quot;;s:4:&quot;2 kB&quot;;s:25:&quot;str_aiowps_login_lockdown&quot;;s:4:&quot;1 kB&quot;;s:15:&quot;str_commentmeta&quot;;s:4:&quot;4 kB&quot;;s:12:&quot;str_comments&quot;;s:4:&quot;7 kB&quot;;s:14:&quot;str_frm_fields&quot;;s:5:&quot;81 kB&quot;;s:13:&quot;str_frm_forms&quot;;s:5:&quot;18 kB&quot;;s:18:&quot;str_frm_item_metas&quot;;s:4:&quot;4 kB&quot;;s:13:&quot;str_frm_items&quot;;s:4:&quot;9 kB&quot;;s:9:&quot;str_links&quot;;s:4:&quot;4 kB&quot;;s:11:&quot;str_options&quot;;s:6:&quot;595 kB&quot;;s:12:&quot;str_postmeta&quot;;s:5:&quot;71 kB&quot;;s:9:&quot;str_posts&quot;;s:6:&quot;175 kB&quot;;s:22:&quot;str_term_relationships&quot;;s:4:&quot;6 kB&quot;;s:17:&quot;str_term_taxonomy&quot;;s:4:&quot;5 kB&quot;;s:9:&quot;str_terms&quot;;s:5:&quot;14 kB&quot;;s:12:&quot;str_usermeta&quot;;s:5:&quot;22 kB&quot;;s:9:&quot;str_users&quot;;s:4:&quot;6 kB&quot;;}s:4:&quot;path&quot;;s:39:&quot;/home/dev/web/ngo2.ru/public_html/start&quot;;s:3:&quot;url&quot;;s:20:&quot;http://ngo2.ru/start&quot;;s:6:&quot;prefix&quot;;s:4:&quot;str_&quot;;s:10:&quot;bottleneck&quot;;i:1048576;s:5:&quot;error&quot;;i:0;s:14:&quot;plugin_version&quot;;s:3:&quot;1.5&quot;;s:6:&quot;domain&quot;;s:0:&quot;&quot;;s:17:&quot;path_current_site&quot;;s:0:&quot;&quot;;s:11:&quot;uploads_dir&quot;;s:30:&quot;wp-content/uploads/wp-sync-db/&quot;;s:4:&quot;gzip&quot;;s:1:&quot;1&quot;;s:10:&quot;post_types&quot;;a:12:{i:0;s:8:&quot;revision&quot;;i:1;s:3:&quot;acf&quot;;i:2;s:9:&quot;acf-field&quot;;i:3;s:15:&quot;acf-field-group&quot;;i:4;s:10:&quot;attachment&quot;;i:5;s:6:&quot;banner&quot;;i:6;s:13:&quot;cycloneslider&quot;;i:7;s:16:&quot;frm_form_actions&quot;;i:8;s:10:&quot;frm_styles&quot;;i:9;s:13:&quot;nav_menu_item&quot;;i:10;s:4:&quot;page&quot;;i:11;s:4:&quot;post&quot;;}s:17:&quot;write_permissions&quot;;s:1:&quot;1&quot;;s:15:&quot;upload_dir_long&quot;;s:69:&quot;/home/dev/web/ngo2.ru/public_html/start/wp-content/uploads/wp-sync-db&quot;;s:11:&quot;temp_prefix&quot;;s:5:&quot;_mig_&quot;;s:21:&quot;media_files_available&quot;;s:1:&quot;1&quot;;s:19:&quot;media_files_version&quot;;s:7:&quot;1.1.4b1&quot;;s:28:&quot;media_files_max_file_uploads&quot;;s:2:&quot;20&quot;;}\n\nAttempted to connect to: http://test:testhouse@giger.local/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Sat, 19 Sep 2015 09:57:34 GMT\n            [content-type] => text/html; charset=UTF-8\n            [content-length] => 1291\n            [connection] => close\n            [x-powered-by] => PHP/5.4.45-0+deb7u1\n            [x-robots-tag] => noindex\n            [x-content-type-options] => nosniff\n            [expires] => Wed, 11 Jan 1984 05:00:00 GMT\n            [cache-control] => no-cache, must-revalidate, max-age=0\n            [pragma] => no-cache\n            [x-frame-options] => SAMEORIGIN\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <br />\n<b>Notice</b>:  Вызванный метод конструктора класса WP_Widget считается <strong>устаревшим</strong> с версии 4.3.0! Используйте <pre>__construct()</pre>. in <b>/home/dev/web/ngo2.ru/public_html/start/wp-includes/functions.php</b> on line <b>3457</b><br />\na:22:{s:6:"tables";a:20:{i:0;s:17:"str_aiowps_events";i:1;s:24:"str_aiowps_failed_logins";i:2;s:22:"str_aiowps_global_meta";i:3;s:25:"str_aiowps_login_activity";i:4;s:25:"str_aiowps_login_lockdown";i:5;s:15:"str_commentmeta";i:6;s:12:"str_comments";i:7;s:14:"str_frm_fields";i:8;s:13:"str_frm_forms";i:9;s:18:"str_frm_item_metas";i:10;s:13:"str_frm_items";i:11;s:9:"str_links";i:12;s:11:"str_options";i:13;s:12:"str_postmeta";i:14;s:9:"str_posts";i:15;s:22:"str_term_relationships";i:16;s:17:"str_term_taxonomy";i:17;s:9:"str_terms";i:18;s:12:"str_usermeta";i:19;s:9:"str_users";}s:15:"prefixed_tables";a:20:{i:0;s:17:"str_aiowps_events";i:1;s:24:"str_aiowps_failed_logins";i:2;s:22:"str_aiowps_global_meta";i:3;s:25:"str_aiowps_login_activity";i:4;s:25:"str_aiowps_login_lockdown";i:5;s:15:"str_commentmeta";i:6;s:12:"str_comments";i:7;s:14:"str_frm_fields";i:8;s:13:"str_frm_forms";i:9;s:18:"str_frm_item_metas";i:10;s:13:"str_frm_items";i:11;s:9:"str_links";i:12;s:11:"str_options";i:13;s:12:"str_postmeta";i:14;s:9:"str_posts";i:15;s:22:"str_term_relationships";i:16;s:17:"str_term_taxonomy";i:17;s:9:"str_terms";i:18;s:12:"str_usermeta";i:19;s:9:"str_users";}s:11:"table_sizes";a:20:{s:17:"str_aiowps_events";s:1:"1";s:24:"str_aiowps_failed_logins";s:1:"2";s:22:"str_aiowps_global_meta";s:3:"696";s:25:"str_aiowps_login_activity";s:1:"2";s:25:"str_aiowps_login_lockdown";s:1:"1";s:15:"str_commentmeta";s:1:"4";s:12:"str_comments";s:1:"7";s:14:"str_frm_fields";s:2:"81";s:13:"str_frm_forms";s:2:"18";s:18:"str_frm_item_metas";s:1:"4";s:13:"str_frm_items";s:1:"9";s:9:"str_links";s:1:"4";s:11:"str_options";s:3:"595";s:12:"str_postmeta";s:2:"71";s:9:"str_posts";s:3:"175";s:22:"str_term_relationships";s:1:"6";s:17:"str_term_taxonomy";s:1:"5";s:9:"str_terms";s:2:"14";s:12:"str_usermeta";s:2:"22";s:9:"str_users";s:1:"6";}s:10:"table_rows";a:20:{s:17:"str_aiowps_events";i:1;s:24:"str_aiowps_failed_logins";s:1:"1";s:22:"str_aiowps_global_meta";s:1:"1";s:25:"str_aiowps_login_activity";s:1:"2";s:25:"str_aiowps_login_lockdown";i:1;s:15:"str_commentmeta";i:1;s:12:"str_comments";s:1:"1";s:14:"str_frm_fields";s:2:"87";s:13:"str_frm_forms";s:1:"6";s:18:"str_frm_item_metas";s:1:"1";s:13:"str_frm_items";s:1:"1";s:9:"str_links";s:1:"7";s:11:"str_options";s:3:"201";s:12:"str_postmeta";s:3:"483";s:9:"str_posts";s:3:"116";s:22:"str_term_relationships";s:2:"54";s:17:"str_term_taxonomy";s:2:"17";s:9:"str_terms";s:2:"17";s:12:"str_usermeta";s:3:"120";s:9:"str_users";s:1:"5";}s:14:"table_sizes_hr";a:20:{s:17:"str_aiowps_events";s:4:"1 kB";s:24:"str_aiowps_failed_logins";s:4:"2 kB";s:22:"str_aiowps_global_meta";s:6:"696 kB";s:25:"str_aiowps_login_activity";s:4:"2 kB";s:25:"str_aiowps_login_lockdown";s:4:"1 kB";s:15:"str_commentmeta";s:4:"4 kB";s:12:"str_comments";s:4:"7 kB";s:14:"str_frm_fields";s:5:"81 kB";s:13:"str_frm_forms";s:5:"18 kB";s:18:"str_frm_item_metas";s:4:"4 kB";s:13:"str_frm_items";s:4:"9 kB";s:9:"str_links";s:4:"4 kB";s:11:"str_options";s:6:"595 kB";s:12:"str_postmeta";s:5:"71 kB";s:9:"str_posts";s:6:"175 kB";s:22:"str_term_relationships";s:4:"6 kB";s:17:"str_term_taxonomy";s:4:"5 kB";s:9:"str_terms";s:5:"14 kB";s:12:"str_usermeta";s:5:"22 kB";s:9:"str_users";s:4:"6 kB";}s:4:"path";s:39:"/home/dev/web/ngo2.ru/public_html/start";s:3:"url";s:20:"http://ngo2.ru/start";s:6:"prefix";s:4:"str_";s:10:"bottleneck";i:1048576;s:5:"error";i:0;s:14:"plugin_version";s:3:"1.5";s:6:"domain";s:0:"";s:17:"path_current_site";s:0:"";s:11:"uploads_dir";s:30:"wp-content/uploads/wp-sync-db/";s:4:"gzip";s:1:"1";s:10:"post_types";a:12:{i:0;s:8:"revision";i:1;s:3:"acf";i:2;s:9:"acf-field";i:3;s:15:"acf-field-group";i:4;s:10:"attachment";i:5;s:6:"banner";i:6;s:13:"cycloneslider";i:7;s:16:"frm_form_actions";i:8;s:10:"frm_styles";i:9;s:13:"nav_menu_item";i:10;s:4:"page";i:11;s:4:"post";}s:17:"write_permissions";s:1:"1";s:15:"upload_dir_long";s:69:"/home/dev/web/ngo2.ru/public_html/start/wp-content/uploads/wp-sync-db";s:11:"temp_prefix";s:5:"_mig_";s:21:"media_files_available";s:1:"1";s:19:"media_files_version";s:7:"1.1.4b1";s:28:"media_files_max_file_uploads";s:2:"20";}\n    [response] => Array\n        (\n            [code] => 200\n            [message] => OK\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/09/19 10:00:30 ******\n********************************************\n\nWPSDB Error: The remote site is protected with Basic Authentication. Please enter the username and password above to continue. (401 Unauthorized)\n\nAttempted to connect to: http://giger.local/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Sat, 19 Sep 2015 10:00:29 GMT\n            [content-type] => text/html; charset=iso-8859-1\n            [content-length] => 290\n            [connection] => close\n            [www-authenticate] => Basic realm="ngo2.ru"\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>401 Authorization Required</title>\n</head><body>\n<h1>Authorization Required</h1>\n<p>This server could not verify that you\nare authorized to access the document\nrequested.  Either you supplied the wrong\ncredentials (e.g., bad password), or your\nbrowser doesn''t understand how to supply\nthe credentials required.</p>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 401\n            [message] => Authorization Required\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/09/22 08:38:36 ******\n********************************************\n\nWPSDB Error: The remote site is protected with Basic Authentication. Please enter the username and password above to continue. (401 Unauthorized)\n\nAttempted to connect to: http://ngo2.ru/bp/core/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Tue, 22 Sep 2015 08:38:35 GMT\n            [content-type] => text/html; charset=iso-8859-1\n            [content-length] => 337\n            [connection] => close\n            [www-authenticate] => Basic realm="ngo2.ru"\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>401 Authorization Required</title>\n</head><body>\n<h1>Authorization Required</h1>\n<p>This server could not verify that you\nare authorized to access the document\nrequested.  Either you supplied the wrong\ncredentials (e.g., bad password), or your\nbrowser doesn''t understand how to supply\nthe credentials required.</p>\n<hr>\n<address>Apache/2.2.22 (Debian) Server at ngo2.ru Port 80</address>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 401\n            [message] => Authorization Required\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/10/04 18:38:56 ******\n********************************************\n\nWPSDB Error: The remote site is protected with Basic Authentication. Please enter the username and password above to continue. (401 Unauthorized)\n\nAttempted to connect to: http://giger.local/core/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Sun, 04 Oct 2015 18:38:56 GMT\n            [content-type] => text/html; charset=iso-8859-1\n            [content-length] => 337\n            [connection] => close\n            [www-authenticate] => Basic realm="ngo2.ru"\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>401 Authorization Required</title>\n</head><body>\n<h1>Authorization Required</h1>\n<p>This server could not verify that you\nare authorized to access the document\nrequested.  Either you supplied the wrong\ncredentials (e.g., bad password), or your\nbrowser doesn''t understand how to supply\nthe credentials required.</p>\n<hr>\n<address>Apache/2.2.22 (Debian) Server at ngo2.ru Port 80</address>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 401\n            [message] => Authorization Required\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/10/13 14:42:39 ******\n********************************************\n\nWPSDB Error: The remote site is protected with Basic Authentication. Please enter the username and password above to continue. (401 Unauthorized)\n\nAttempted to connect to: http://giger.local/core/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Tue, 13 Oct 2015 14:42:39 GMT\n            [content-type] => text/html; charset=iso-8859-1\n            [content-length] => 337\n            [connection] => close\n            [www-authenticate] => Basic realm="ngo2.ru"\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>401 Authorization Required</title>\n</head><body>\n<h1>Authorization Required</h1>\n<p>This server could not verify that you\nare authorized to access the document\nrequested.  Either you supplied the wrong\ncredentials (e.g., bad password), or your\nbrowser doesn''t understand how to supply\nthe credentials required.</p>\n<hr>\n<address>Apache/2.2.22 (Debian) Server at ngo2.ru Port 80</address>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 401\n            [message] => Authorization Required\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/10/13 14:44:23 ******\n********************************************\n\nWPSDB Error: Unable to connect to the remote server, please check the connection details - 404 Not Found (#129 - scope: ajax_verify_connection_to_remote_site)\n\nAttempted to connect to: http://test:testhouse@giger.local/core/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [date] => Tue, 13 Oct 2015 14:44:23 GMT\n            [server] => Apache/2.2.26 (Unix) mod_fastcgi/2.4.6 mod_wsgi/3.4 Python/2.7.6 PHP/5.5.14 mod_ssl/2.2.26 OpenSSL/0.9.8zg DAV/2 mod_perl/2.0.8 Perl/v5.18.2\n            [content-length] => 232\n            [connection] => close\n            [content-type] => text/html; charset=iso-8859-1\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>404 Not Found</title>\n</head><body>\n<h1>Not Found</h1>\n<p>The requested URL /start/core/wp-admin/admin-ajax.php was not found on this server.</p>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 404\n            [message] => Not Found\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/10/13 18:22:23 ******\n********************************************\n\nWPSDB Error: The remote site is protected with Basic Authentication. Please enter the username and password above to continue. (401 Unauthorized)\n\nAttempted to connect to: http://ngo2.ru/start/core/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Tue, 13 Oct 2015 18:22:23 GMT\n            [content-type] => text/html; charset=iso-8859-1\n            [content-length] => 337\n            [connection] => close\n            [www-authenticate] => Basic realm="ngo2.ru"\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>401 Authorization Required</title>\n</head><body>\n<h1>Authorization Required</h1>\n<p>This server could not verify that you\nare authorized to access the document\nrequested.  Either you supplied the wrong\ncredentials (e.g., bad password), or your\nbrowser doesn''t understand how to supply\nthe credentials required.</p>\n<hr>\n<address>Apache/2.2.22 (Debian) Server at ngo2.ru Port 80</address>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 401\n            [message] => Authorization Required\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n********************************************\n******  Log date: 2015/10/13 20:32:55 ******\n********************************************\n\nWPSDB Error: The remote site is protected with Basic Authentication. Please enter the username and password above to continue. (401 Unauthorized)\n\nAttempted to connect to: http://ngo2.ru/giger/core/wp-admin/admin-ajax.php\n\nArray\n(\n    [headers] => Array\n        (\n            [server] => nginx\n            [date] => Tue, 13 Oct 2015 20:32:54 GMT\n            [content-type] => text/html; charset=iso-8859-1\n            [content-length] => 337\n            [connection] => close\n            [www-authenticate] => Basic realm="ngo2.ru"\n            [vary] => Accept-Encoding\n            [content-encoding] => gzip\n        )\n\n    [body] => <!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">\n<html><head>\n<title>401 Authorization Required</title>\n</head><body>\n<h1>Authorization Required</h1>\n<p>This server could not verify that you\nare authorized to access the document\nrequested.  Either you supplied the wrong\ncredentials (e.g., bad password), or your\nbrowser doesn''t understand how to supply\nthe credentials required.</p>\n<hr>\n<address>Apache/2.2.22 (Debian) Server at ngo2.ru Port 80</address>\n</body></html>\n\n    [response] => Array\n        (\n            [code] => 401\n            [message] => Authorization Required\n        )\n\n    [cookies] => Array\n        (\n        )\n\n    [filename] => \n)\n\n\n', 'yes'),
(467, 'su_installed', '1443683559', 'yes'),
(468, 'su_option_version', '4.9.8.1', 'yes'),
(469, 'su_option_custom-formatting', 'on', 'yes'),
(470, 'su_option_skip', 'on', 'yes'),
(471, 'su_option_prefix', 'su_', 'yes'),
(472, 'su_option_hotkey', 'alt+i', 'yes'),
(473, 'su_option_skin', 'default', 'yes'),
(474, 'su_option_custom-css', '', 'yes'),
(475, 'sunrise_defaults_su', '1', 'yes'),
(480, 'su_presets_gmap', 'a:1:{s:9:"last_used";a:3:{s:2:"id";s:9:"last_used";s:4:"name";s:37:"Последние настройки";s:8:"settings";a:6:{s:5:"width";s:3:"760";s:6:"height";s:3:"400";s:10:"responsive";s:3:"yes";s:7:"address";s:69:"Россия, Москва, Лубянский пр-д, 19, стр. 1";s:5:"class";s:0:"";s:7:"content";s:5:"false";}}}', 'yes'),
(494, 'widget_shortcodes-ultimate', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(568, 'su_vote', 'no', 'yes'),
(863, '_transient_timeout_plugin_slugs', '1449867824', 'no'),
(864, '_transient_plugin_slugs', 'a:23:{i:0;s:13:"cmb2/init.php";i:1;s:49:"cmb2-attached-posts/cmb2-attached-posts-field.php";i:2;s:35:"crop-thumbnails/crop-thumbnails.php";i:3;s:22:"cyr3lat/cyr-to-lat.php";i:4;s:23:"debug-bar/debug-bar.php";i:5;s:31:"debug-objects/debug-objects.php";i:6;s:37:"disable-comments/disable-comments.php";i:7;s:59:"force-regenerate-thumbnails/force-regenerate-thumbnails.php";i:8;s:21:"imsanity/imsanity.php";i:9;s:15:"leyka/leyka.php";i:10;s:47:"media-search-enhanced/media-search-enhanced.php";i:11;s:27:"ninja-forms/ninja-forms.php";i:12;s:38:"post-duplicator/m4c-postduplicator.php";i:13;s:33:"posts-to-posts/posts-to-posts.php";i:14;s:31:"query-monitor/query-monitor.php";i:15;s:43:"responsive-lightbox/responsive-lightbox.php";i:16;s:43:"simple-css-for-widgets/simplecsswidgets.php";i:17;s:62:"simple-google-maps-short-code/simple-google-map-short-code.php";i:18;s:33:"w3-total-cache/w3-total-cache.php";i:19;s:29:"widget-logic/widget_logic.php";i:20;s:25:"wp-sync-db/wp-sync-db.php";i:21;s:49:"wp-sync-db-media-files/wp-sync-db-media-files.php";i:22;s:24:"wordpress-seo/wp-seo.php";}', 'no'),
(882, '_transient_timeout_402510eddf8d34a37e5916b1f302d381', '1455001228', 'no'),
(883, '_transient_402510eddf8d34a37e5916b1f302d381', 'a:3:{s:3:"lat";d:55.75582299999999946749085211195051670074462890625;s:3:"lng";d:37.6338539999999994734025676734745502471923828125;s:7:"address";s:46:"Lubyanskiy pr-d, 19с1, Moskva, Russia, 101000";}', 'no'),
(1004, 'org_cat_children', 'a:0:{}', 'yes'),
(1009, 'person_cat_children', 'a:0:{}', 'yes'),
(1070, '_site_transient_timeout_browser_91092c02938d4c94430d9f006bbafd18', '1450345898', 'yes'),
(1071, '_site_transient_browser_91092c02938d4c94430d9f006bbafd18', 'a:9:{s:8:"platform";s:9:"Macintosh";s:4:"name";s:7:"Firefox";s:7:"version";s:4:"42.0";s:10:"update_url";s:23:"http://www.firefox.com/";s:7:"img_src";s:50:"http://s.wordpress.org/images/browsers/firefox.png";s:11:"img_src_ssl";s:49:"https://wordpress.org/images/browsers/firefox.png";s:15:"current_version";s:2:"16";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes'),
(1072, 'leyka_chronopay_test_mode', '0', 'yes'),
(1073, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1074, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1075, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1076, 'site_icon', '0', 'yes'),
(1077, 'medium_large_size_w', '768', 'yes'),
(1078, 'medium_large_size_h', '0', 'yes');
INSERT INTO `str_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1080, 'rewrite_rules', 'a:237:{s:11:"campaign/?$";s:34:"index.php?post_type=leyka_campaign";s:41:"campaign/feed/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?post_type=leyka_campaign&feed=$matches[1]";s:36:"campaign/(feed|rdf|rss|rss2|atom)/?$";s:51:"index.php?post_type=leyka_campaign&feed=$matches[1]";s:28:"campaign/page/([0-9]{1,})/?$";s:52:"index.php?post_type=leyka_campaign&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:12:"humans\\.txt$";s:18:"index.php?humans=1";s:11:"projects/?$";s:27:"index.php?post_type=project";s:41:"projects/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:36:"projects/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:28:"projects/page/([0-9]{1,})/?$";s:45:"index.php?post_type=project&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:38:"frm_styles/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:48:"frm_styles/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:68:"frm_styles/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"frm_styles/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:63:"frm_styles/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"frm_styles/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:27:"frm_styles/([^/]+)/embed/?$";s:43:"index.php?frm_styles=$matches[1]&embed=true";s:31:"frm_styles/([^/]+)/trackback/?$";s:37:"index.php?frm_styles=$matches[1]&tb=1";s:39:"frm_styles/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?frm_styles=$matches[1]&paged=$matches[2]";s:46:"frm_styles/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?frm_styles=$matches[1]&cpage=$matches[2]";s:35:"frm_styles/([^/]+)(?:/([0-9]+))?/?$";s:49:"index.php?frm_styles=$matches[1]&page=$matches[2]";s:27:"frm_styles/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"frm_styles/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"frm_styles/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"frm_styles/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"frm_styles/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"frm_styles/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:44:"frm_form_actions/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:54:"frm_form_actions/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:74:"frm_form_actions/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"frm_form_actions/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:69:"frm_form_actions/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:50:"frm_form_actions/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"frm_form_actions/([^/]+)/embed/?$";s:49:"index.php?frm_form_actions=$matches[1]&embed=true";s:37:"frm_form_actions/([^/]+)/trackback/?$";s:43:"index.php?frm_form_actions=$matches[1]&tb=1";s:45:"frm_form_actions/([^/]+)/page/?([0-9]{1,})/?$";s:56:"index.php?frm_form_actions=$matches[1]&paged=$matches[2]";s:52:"frm_form_actions/([^/]+)/comment-page-([0-9]{1,})/?$";s:56:"index.php?frm_form_actions=$matches[1]&cpage=$matches[2]";s:41:"frm_form_actions/([^/]+)(?:/([0-9]+))?/?$";s:55:"index.php?frm_form_actions=$matches[1]&page=$matches[2]";s:33:"frm_form_actions/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"frm_form_actions/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"frm_form_actions/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"frm_form_actions/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"frm_form_actions/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"frm_form_actions/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"donation/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"donation/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"donation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"donation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"donation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"donation/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"donation/([^/]+)/embed/?$";s:47:"index.php?leyka_donation=$matches[1]&embed=true";s:29:"donation/([^/]+)/trackback/?$";s:41:"index.php?leyka_donation=$matches[1]&tb=1";s:37:"donation/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?leyka_donation=$matches[1]&paged=$matches[2]";s:44:"donation/([^/]+)/comment-page-([0-9]{1,})/?$";s:54:"index.php?leyka_donation=$matches[1]&cpage=$matches[2]";s:33:"donation/([^/]+)(?:/([0-9]+))?/?$";s:53:"index.php?leyka_donation=$matches[1]&page=$matches[2]";s:25:"donation/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"donation/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"donation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"donation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"donation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"donation/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:36:"campaign/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"campaign/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"campaign/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campaign/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"campaign/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:42:"campaign/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:25:"campaign/([^/]+)/embed/?$";s:47:"index.php?leyka_campaign=$matches[1]&embed=true";s:29:"campaign/([^/]+)/trackback/?$";s:41:"index.php?leyka_campaign=$matches[1]&tb=1";s:49:"campaign/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?leyka_campaign=$matches[1]&feed=$matches[2]";s:44:"campaign/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:53:"index.php?leyka_campaign=$matches[1]&feed=$matches[2]";s:37:"campaign/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?leyka_campaign=$matches[1]&paged=$matches[2]";s:44:"campaign/([^/]+)/comment-page-([0-9]{1,})/?$";s:54:"index.php?leyka_campaign=$matches[1]&cpage=$matches[2]";s:33:"campaign/([^/]+)(?:/([0-9]+))?/?$";s:53:"index.php?leyka_campaign=$matches[1]&page=$matches[2]";s:25:"campaign/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:35:"campaign/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:55:"campaign/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campaign/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:50:"campaign/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:31:"campaign/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:47:"auctor/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?auctor=$matches[1]&feed=$matches[2]";s:42:"auctor/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?auctor=$matches[1]&feed=$matches[2]";s:35:"auctor/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?auctor=$matches[1]&paged=$matches[2]";s:17:"auctor/([^/]+)/?$";s:28:"index.php?auctor=$matches[1]";s:45:"orgs/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?org_cat=$matches[1]&feed=$matches[2]";s:40:"orgs/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?org_cat=$matches[1]&feed=$matches[2]";s:33:"orgs/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?org_cat=$matches[1]&paged=$matches[2]";s:15:"orgs/([^/]+)/?$";s:29:"index.php?org_cat=$matches[1]";s:47:"people/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?person_cat=$matches[1]&feed=$matches[2]";s:42:"people/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?person_cat=$matches[1]&feed=$matches[2]";s:35:"people/([^/]+)/page/?([0-9]{1,})/?$";s:50:"index.php?person_cat=$matches[1]&paged=$matches[2]";s:17:"people/([^/]+)/?$";s:32:"index.php?person_cat=$matches[1]";s:33:"event/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"event/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"event/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"event/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"event/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"event/([^/]+)/embed/?$";s:38:"index.php?event=$matches[1]&embed=true";s:26:"event/([^/]+)/trackback/?$";s:32:"index.php?event=$matches[1]&tb=1";s:34:"event/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&paged=$matches[2]";s:41:"event/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?event=$matches[1]&cpage=$matches[2]";s:30:"event/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?event=$matches[1]&page=$matches[2]";s:22:"event/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"event/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"event/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"event/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"event/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"project/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"project/([^/]+)/embed/?$";s:40:"index.php?project=$matches[1]&embed=true";s:28:"project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:48:"project/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:43:"project/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:36:"project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:43:"project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:32:"project/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:24:"project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"project/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:31:"org/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"org/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"org/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"org/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"org/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:37:"org/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:20:"org/([^/]+)/embed/?$";s:36:"index.php?org=$matches[1]&embed=true";s:24:"org/([^/]+)/trackback/?$";s:30:"index.php?org=$matches[1]&tb=1";s:32:"org/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?org=$matches[1]&paged=$matches[2]";s:39:"org/([^/]+)/comment-page-([0-9]{1,})/?$";s:43:"index.php?org=$matches[1]&cpage=$matches[2]";s:28:"org/([^/]+)(?:/([0-9]+))?/?$";s:42:"index.php?org=$matches[1]&page=$matches[2]";s:20:"org/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:30:"org/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:50:"org/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"org/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:45:"org/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:26:"org/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:35:"profile/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"profile/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"profile/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"profile/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"profile/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"profile/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"profile/([^/]+)/embed/?$";s:39:"index.php?person=$matches[1]&embed=true";s:28:"profile/([^/]+)/trackback/?$";s:33:"index.php?person=$matches[1]&tb=1";s:36:"profile/([^/]+)/page/?([0-9]{1,})/?$";s:46:"index.php?person=$matches[1]&paged=$matches[2]";s:43:"profile/([^/]+)/comment-page-([0-9]{1,})/?$";s:46:"index.php?person=$matches[1]&cpage=$matches[2]";s:32:"profile/([^/]+)(?:/([0-9]+))?/?$";s:45:"index.php?person=$matches[1]&page=$matches[2]";s:24:"profile/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"profile/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"profile/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"profile/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"profile/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"profile/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=72&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(1082, 'can_compress_scripts', '1', 'yes'),
(1091, 'nf_convert_notifications_complete', '1', 'yes'),
(1092, 'nf_convert_subs_step', 'complete', 'yes'),
(1093, 'nf_upgrade_notice', 'closed', 'yes'),
(1094, 'nf_update_email_settings_complete', '1', 'yes'),
(1095, 'nf_email_fav_updated', '1', 'yes'),
(1096, 'nf_convert_forms_complete', '1', 'yes'),
(1097, 'nf_database_migrations', '1', 'yes'),
(1098, 'ninja_forms_settings', 'a:18:{s:11:"date_format";s:5:"d/m/Y";s:15:"currency_symbol";s:1:"$";s:14:"recaptcha_lang";s:2:"en";s:13:"req_div_label";s:80:"Fields marked with an <span class="ninja-forms-req-symbol">*</span> are required";s:16:"req_field_symbol";s:18:"<strong>*</strong>";s:15:"req_error_label";s:48:"Please ensure all required fields are completed.";s:15:"req_field_error";s:24:"This is a required field";s:10:"spam_error";s:47:"Please answer the anti-spam question correctly.";s:14:"honeypot_error";s:34:"Please leave the spam field blank.";s:18:"timed_submit_error";s:31:"Please wait to submit the form.";s:16:"javascript_error";s:54:"You cannot submit the form without Javascript enabled.";s:13:"invalid_email";s:35:"Please enter a valid email address.";s:13:"process_label";s:10:"Processing";s:17:"password_mismatch";s:36:"The passwords provided do not match.";s:10:"preview_id";i:299;s:7:"version";s:6:"2.9.29";s:19:"fix_form_email_from";i:1;s:18:"fix_field_reply_to";i:1;}', 'yes'),
(1101, '_transient_timeout_nf_form_5', '1449867420', 'no'),
(1102, '_transient_nf_form_5', 'O:7:"NF_Form":5:{s:7:"form_id";s:1:"5";s:8:"settings";a:13:{s:12:"date_updated";s:19:"2015-12-10 19:36:27";s:14:"clear_complete";s:1:"0";s:13:"hide_complete";s:1:"1";s:10:"show_title";s:1:"1";s:6:"status";s:0:"";s:10:"form_title";s:36:"Подписка на новости";s:11:"append_page";s:0:"";s:4:"ajax";s:1:"1";s:9:"logged_in";s:1:"0";s:17:"not_logged_in_msg";s:0:"";s:16:"sub_limit_number";s:0:"";s:13:"sub_limit_msg";s:0:"";s:8:"last_sub";s:2:"14";}s:6:"fields";a:3:{i:18;a:7:{s:2:"id";s:2:"18";s:7:"form_id";s:1:"5";s:4:"type";s:5:"_desc";s:5:"order";s:1:"0";s:4:"data";a:8:{s:5:"label";s:4:"Text";s:15:"input_limit_msg";s:17:"character(s) left";s:13:"default_value";s:230:"Время от времени мы будем присылать вам анонсы наших мероприятий или новости из жизни наших подопечных. Оставайтесь на связи!";s:7:"desc_el";s:3:"div";s:5:"class";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}i:16;a:7:{s:2:"id";s:2:"16";s:7:"form_id";s:1:"5";s:4:"type";s:5:"_text";s:5:"order";s:1:"1";s:4:"data";a:40:{s:5:"label";s:12:"Ваш email";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"1";s:10:"send_email";s:1:"0";s:10:"from_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"0";s:10:"user_email";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";s:11:"placeholder";s:0:"";s:13:"disable_input";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:10:"user_state";s:1:"0";s:16:"autocomplete_off";s:1:"0";s:8:"num_sort";s:1:"0";s:18:"default_value_type";s:0:"";s:11:"admin_label";s:0:"";s:26:"user_info_field_group_name";s:0:"";s:28:"user_info_field_group_custom";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";s:2:"14";}i:17;a:7:{s:2:"id";s:2:"17";s:7:"form_id";s:1:"5";s:4:"type";s:7:"_submit";s:5:"order";s:1:"2";s:4:"data";a:8:{s:5:"label";s:22:"Подписаться";s:15:"input_limit_msg";s:17:"character(s) left";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}}s:10:"field_keys";a:0:{}s:6:"errors";a:0:{}}', 'no'),
(1105, 'widget_ninja_forms_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1106, 'nf_admin_notice', 'a:2:{s:16:"one_week_support";a:2:{s:5:"start";s:10:"12/17/2015";s:3:"int";i:7;}s:15:"two_week_review";a:2:{s:5:"start";s:10:"12/24/2015";s:3:"int";i:14;}}', 'yes'),
(1108, '_site_transient_timeout_theme_roots', '1449782950', 'yes'),
(1109, '_site_transient_theme_roots', 'a:1:{s:7:"tstnext";s:7:"/themes";}', 'yes'),
(1113, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:63:"https://downloads.wordpress.org/release/ru_RU/wordpress-4.4.zip";s:6:"locale";s:5:"ru_RU";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:63:"https://downloads.wordpress.org/release/ru_RU/wordpress-4.4.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:3:"4.4";s:7:"version";s:3:"4.4";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.4";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1449781420;s:15:"version_checked";s:3:"4.4";s:12:"translations";a:0:{}}', 'yes'),
(1114, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1449781423;s:7:"checked";a:23:{s:13:"cmb2/init.php";s:5:"2.1.2";s:49:"cmb2-attached-posts/cmb2-attached-posts-field.php";s:5:"1.2.2";s:35:"crop-thumbnails/crop-thumbnails.php";s:6:"0.10.3";s:22:"cyr3lat/cyr-to-lat.php";s:3:"3.5";s:23:"debug-bar/debug-bar.php";s:5:"0.8.2";s:31:"debug-objects/debug-objects.php";s:5:"2.2.0";s:37:"disable-comments/disable-comments.php";s:5:"1.3.2";s:59:"force-regenerate-thumbnails/force-regenerate-thumbnails.php";s:5:"2.0.5";s:21:"imsanity/imsanity.php";s:5:"2.3.6";s:15:"leyka/leyka.php";s:5:"2.2.8";s:47:"media-search-enhanced/media-search-enhanced.php";s:5:"0.7.2";s:27:"ninja-forms/ninja-forms.php";s:6:"2.9.29";s:38:"post-duplicator/m4c-postduplicator.php";s:4:"2.12";s:33:"posts-to-posts/posts-to-posts.php";s:5:"1.6.5";s:31:"query-monitor/query-monitor.php";s:5:"2.8.1";s:43:"responsive-lightbox/responsive-lightbox.php";s:5:"1.6.5";s:43:"simple-css-for-widgets/simplecsswidgets.php";s:3:"1.0";s:62:"simple-google-maps-short-code/simple-google-map-short-code.php";s:3:"1.2";s:33:"w3-total-cache/w3-total-cache.php";s:7:"0.9.4.1";s:29:"widget-logic/widget_logic.php";s:4:"0.57";s:25:"wp-sync-db/wp-sync-db.php";s:3:"1.5";s:49:"wp-sync-db-media-files/wp-sync-db-media-files.php";s:7:"1.1.4b1";s:24:"wordpress-seo/wp-seo.php";s:5:"3.0.6";}s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:20:{s:13:"cmb2/init.php";O:8:"stdClass":6:{s:2:"id";s:5:"53754";s:4:"slug";s:4:"cmb2";s:6:"plugin";s:13:"cmb2/init.php";s:11:"new_version";s:5:"2.1.2";s:3:"url";s:35:"https://wordpress.org/plugins/cmb2/";s:7:"package";s:47:"https://downloads.wordpress.org/plugin/cmb2.zip";}s:35:"crop-thumbnails/crop-thumbnails.php";O:8:"stdClass":6:{s:2:"id";s:5:"36150";s:4:"slug";s:15:"crop-thumbnails";s:6:"plugin";s:35:"crop-thumbnails/crop-thumbnails.php";s:11:"new_version";s:6:"0.10.3";s:3:"url";s:46:"https://wordpress.org/plugins/crop-thumbnails/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/crop-thumbnails.zip";}s:22:"cyr3lat/cyr-to-lat.php";O:8:"stdClass":6:{s:2:"id";s:5:"23472";s:4:"slug";s:7:"cyr3lat";s:6:"plugin";s:22:"cyr3lat/cyr-to-lat.php";s:11:"new_version";s:3:"3.5";s:3:"url";s:38:"https://wordpress.org/plugins/cyr3lat/";s:7:"package";s:54:"https://downloads.wordpress.org/plugin/cyr3lat.3.5.zip";}s:23:"debug-bar/debug-bar.php";O:8:"stdClass":7:{s:2:"id";s:5:"18561";s:4:"slug";s:9:"debug-bar";s:6:"plugin";s:23:"debug-bar/debug-bar.php";s:11:"new_version";s:5:"0.8.2";s:3:"url";s:40:"https://wordpress.org/plugins/debug-bar/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/debug-bar.0.8.2.zip";s:14:"upgrade_notice";s:60:"Updated to handle a new deprecated message in WordPress 4.0.";}s:31:"debug-objects/debug-objects.php";O:8:"stdClass":6:{s:2:"id";s:4:"8670";s:4:"slug";s:13:"debug-objects";s:6:"plugin";s:31:"debug-objects/debug-objects.php";s:11:"new_version";s:5:"2.2.0";s:3:"url";s:44:"https://wordpress.org/plugins/debug-objects/";s:7:"package";s:56:"https://downloads.wordpress.org/plugin/debug-objects.zip";}s:37:"disable-comments/disable-comments.php";O:8:"stdClass":6:{s:2:"id";s:5:"22847";s:4:"slug";s:16:"disable-comments";s:6:"plugin";s:37:"disable-comments/disable-comments.php";s:11:"new_version";s:5:"1.3.2";s:3:"url";s:47:"https://wordpress.org/plugins/disable-comments/";s:7:"package";s:59:"https://downloads.wordpress.org/plugin/disable-comments.zip";}s:59:"force-regenerate-thumbnails/force-regenerate-thumbnails.php";O:8:"stdClass":6:{s:2:"id";s:5:"33928";s:4:"slug";s:27:"force-regenerate-thumbnails";s:6:"plugin";s:59:"force-regenerate-thumbnails/force-regenerate-thumbnails.php";s:11:"new_version";s:5:"2.0.5";s:3:"url";s:58:"https://wordpress.org/plugins/force-regenerate-thumbnails/";s:7:"package";s:70:"https://downloads.wordpress.org/plugin/force-regenerate-thumbnails.zip";}s:21:"imsanity/imsanity.php";O:8:"stdClass":7:{s:2:"id";s:5:"24171";s:4:"slug";s:8:"imsanity";s:6:"plugin";s:21:"imsanity/imsanity.php";s:11:"new_version";s:5:"2.3.6";s:3:"url";s:39:"https://wordpress.org/plugins/imsanity/";s:7:"package";s:51:"https://downloads.wordpress.org/plugin/imsanity.zip";s:14:"upgrade_notice";s:213:"tested up to WP 4.4\nif resized image is not smaller than original, then keep original\nallow IMSANITY_AJAX_MAX_RECORDS to be overridden in wp-config.php\nif png-to-jpg is enabled, replace png transparency with white";}s:15:"leyka/leyka.php";O:8:"stdClass":6:{s:2:"id";s:5:"38621";s:4:"slug";s:5:"leyka";s:6:"plugin";s:15:"leyka/leyka.php";s:11:"new_version";s:5:"2.2.8";s:3:"url";s:36:"https://wordpress.org/plugins/leyka/";s:7:"package";s:48:"https://downloads.wordpress.org/plugin/leyka.zip";}s:47:"media-search-enhanced/media-search-enhanced.php";O:8:"stdClass":6:{s:2:"id";s:5:"48975";s:4:"slug";s:21:"media-search-enhanced";s:6:"plugin";s:47:"media-search-enhanced/media-search-enhanced.php";s:11:"new_version";s:5:"0.7.2";s:3:"url";s:52:"https://wordpress.org/plugins/media-search-enhanced/";s:7:"package";s:70:"https://downloads.wordpress.org/plugin/media-search-enhanced.0.7.2.zip";}s:27:"ninja-forms/ninja-forms.php";O:8:"stdClass":6:{s:2:"id";s:5:"27901";s:4:"slug";s:11:"ninja-forms";s:6:"plugin";s:27:"ninja-forms/ninja-forms.php";s:11:"new_version";s:6:"2.9.29";s:3:"url";s:42:"https://wordpress.org/plugins/ninja-forms/";s:7:"package";s:61:"https://downloads.wordpress.org/plugin/ninja-forms.2.9.29.zip";}s:38:"post-duplicator/m4c-postduplicator.php";O:8:"stdClass":6:{s:2:"id";s:5:"31128";s:4:"slug";s:15:"post-duplicator";s:6:"plugin";s:38:"post-duplicator/m4c-postduplicator.php";s:11:"new_version";s:4:"2.12";s:3:"url";s:46:"https://wordpress.org/plugins/post-duplicator/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/post-duplicator.zip";}s:33:"posts-to-posts/posts-to-posts.php";O:8:"stdClass":6:{s:2:"id";s:5:"14657";s:4:"slug";s:14:"posts-to-posts";s:6:"plugin";s:33:"posts-to-posts/posts-to-posts.php";s:11:"new_version";s:5:"1.6.5";s:3:"url";s:45:"https://wordpress.org/plugins/posts-to-posts/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/posts-to-posts.1.6.5.zip";}s:31:"query-monitor/query-monitor.php";O:8:"stdClass":6:{s:2:"id";s:5:"10302";s:4:"slug";s:13:"query-monitor";s:6:"plugin";s:31:"query-monitor/query-monitor.php";s:11:"new_version";s:5:"2.8.1";s:3:"url";s:44:"https://wordpress.org/plugins/query-monitor/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/query-monitor.2.8.1.zip";}s:43:"responsive-lightbox/responsive-lightbox.php";O:8:"stdClass":7:{s:2:"id";s:5:"42142";s:4:"slug";s:19:"responsive-lightbox";s:6:"plugin";s:43:"responsive-lightbox/responsive-lightbox.php";s:11:"new_version";s:5:"1.6.5";s:3:"url";s:50:"https://wordpress.org/plugins/responsive-lightbox/";s:7:"package";s:68:"https://downloads.wordpress.org/plugin/responsive-lightbox.1.6.5.zip";s:14:"upgrade_notice";s:108:"Fix: Lightbox activated on non-video youtube links\nTweak: Added a way to change settings required capability";}s:43:"simple-css-for-widgets/simplecsswidgets.php";O:8:"stdClass":6:{s:2:"id";s:5:"36924";s:4:"slug";s:22:"simple-css-for-widgets";s:6:"plugin";s:43:"simple-css-for-widgets/simplecsswidgets.php";s:11:"new_version";s:3:"1.0";s:3:"url";s:53:"https://wordpress.org/plugins/simple-css-for-widgets/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/simple-css-for-widgets.zip";}s:62:"simple-google-maps-short-code/simple-google-map-short-code.php";O:8:"stdClass":6:{s:2:"id";s:5:"35143";s:4:"slug";s:29:"simple-google-maps-short-code";s:6:"plugin";s:62:"simple-google-maps-short-code/simple-google-map-short-code.php";s:11:"new_version";s:3:"1.2";s:3:"url";s:60:"https://wordpress.org/plugins/simple-google-maps-short-code/";s:7:"package";s:76:"https://downloads.wordpress.org/plugin/simple-google-maps-short-code.1.2.zip";}s:33:"w3-total-cache/w3-total-cache.php";O:8:"stdClass":7:{s:2:"id";s:4:"9376";s:4:"slug";s:14:"w3-total-cache";s:6:"plugin";s:33:"w3-total-cache/w3-total-cache.php";s:11:"new_version";s:7:"0.9.4.1";s:3:"url";s:45:"https://wordpress.org/plugins/w3-total-cache/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/w3-total-cache.0.9.4.1.zip";s:14:"upgrade_notice";s:140:"Thanks for using W3 Total Cache! This release includes important security updates designed to contribute to a secure WordPress installation.";}s:29:"widget-logic/widget_logic.php";O:8:"stdClass":6:{s:2:"id";s:4:"2545";s:4:"slug";s:12:"widget-logic";s:6:"plugin";s:29:"widget-logic/widget_logic.php";s:11:"new_version";s:4:"0.57";s:3:"url";s:43:"https://wordpress.org/plugins/widget-logic/";s:7:"package";s:60:"https://downloads.wordpress.org/plugin/widget-logic.0.57.zip";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:5:"3.0.6";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wordpress-seo.3.0.6.zip";}}}', 'yes'),
(1115, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1449781423;s:7:"checked";a:1:{s:7:"tstnext";s:3:"2.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'),
(1116, '_transient_timeout_nf_form_1', '1449867871', 'no'),
(1117, '_transient_nf_form_1', 'O:7:"NF_Form":5:{s:7:"form_id";i:1;s:8:"settings";a:23:{s:12:"date_updated";s:19:"2015-12-10 18:56:23";s:10:"form_title";s:23:"Напишите нам";s:10:"show_title";s:1:"1";s:9:"save_subs";s:1:"1";s:9:"logged_in";s:1:"0";s:11:"append_page";s:0:"";s:4:"ajax";s:1:"1";s:14:"clear_complete";s:1:"0";s:13:"hide_complete";s:1:"1";s:11:"success_msg";s:42:"Your form has been successfully submitted.";s:10:"email_from";s:0:"";s:10:"email_type";s:4:"html";s:14:"user_email_msg";s:69:"Thank you so much for contacting us. We will get back to you shortly.";s:17:"user_email_fields";s:1:"0";s:15:"admin_email_msg";s:0:"";s:18:"admin_email_fields";s:1:"1";s:16:"admin_attach_csv";s:1:"0";s:15:"email_from_name";s:0:"";s:17:"not_logged_in_msg";s:0:"";s:16:"sub_limit_number";s:0:"";s:13:"sub_limit_msg";s:0:"";s:6:"status";s:0:"";s:8:"last_sub";s:1:"4";}s:6:"fields";a:10:{i:1;a:7:{s:2:"id";s:1:"1";s:7:"form_id";s:1:"1";s:4:"type";s:5:"_text";s:5:"order";s:1:"0";s:4:"data";a:36:{s:5:"label";s:15:"Ваше имя";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"0";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:0:"";s:14:"user_address_2";s:0:"";s:9:"user_city";s:0:"";s:8:"user_zip";s:0:"";s:10:"user_phone";s:0:"";s:10:"user_email";s:0:"";s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"placeholder";s:0:"";s:13:"disable_input";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:10:"user_state";s:1:"0";s:16:"autocomplete_off";s:1:"0";s:8:"num_sort";s:1:"0";s:18:"default_value_type";s:0:"";s:11:"admin_label";s:0:"";s:26:"user_info_field_group_name";s:0:"";s:28:"user_info_field_group_custom";s:0:"";}s:6:"fav_id";s:1:"0";s:6:"def_id";s:1:"0";}i:14;a:7:{s:2:"id";s:2:"14";s:7:"form_id";s:1:"1";s:4:"type";s:5:"_text";s:5:"order";s:1:"1";s:4:"data";a:40:{s:5:"label";s:5:"Email";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:4:"mask";s:0:"";s:10:"datepicker";s:1:"0";s:5:"email";s:1:"1";s:10:"send_email";s:1:"0";s:10:"first_name";s:1:"0";s:9:"last_name";s:1:"0";s:9:"from_name";s:1:"0";s:14:"user_address_1";s:1:"0";s:14:"user_address_2";s:1:"0";s:9:"user_city";s:1:"0";s:8:"user_zip";s:1:"0";s:10:"user_phone";s:1:"0";s:10:"user_email";s:1:"1";s:21:"user_info_field_group";s:1:"1";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"calc_option";s:1:"0";s:11:"conditional";s:0:"";s:11:"placeholder";s:0:"";s:13:"disable_input";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:10:"user_state";s:1:"0";s:16:"autocomplete_off";s:1:"0";s:8:"num_sort";s:1:"0";s:18:"default_value_type";s:0:"";s:11:"admin_label";s:0:"";s:26:"user_info_field_group_name";s:0:"";s:28:"user_info_field_group_custom";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:13:"replyto_email";i:0;}s:6:"fav_id";N;s:6:"def_id";s:2:"14";}i:15;a:7:{s:2:"id";s:2:"15";s:7:"form_id";s:1:"1";s:4:"type";s:7:"_hidden";s:5:"order";s:1:"2";s:4:"data";a:13:{s:5:"label";s:16:"Проверка";s:15:"input_limit_msg";s:17:"character(s) left";s:18:"default_value_type";s:7:"_custom";s:13:"default_value";s:1:"2";s:5:"email";s:1:"0";s:10:"send_email";s:1:"0";s:17:"calc_auto_include";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}i:3;a:7:{s:2:"id";s:1:"3";s:7:"form_id";s:1:"1";s:4:"type";s:9:"_textarea";s:5:"order";s:1:"3";s:4:"data";a:19:{s:5:"label";s:18:"Сообщение";s:9:"label_pos";s:5:"above";s:13:"default_value";s:0:"";s:12:"textarea_rte";s:1:"0";s:14:"textarea_media";s:1:"0";s:18:"disable_rte_mobile";s:1:"0";s:3:"req";s:1:"1";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";s:17:"calc_auto_include";s:1:"0";s:11:"input_limit";s:0:"";s:16:"input_limit_type";s:4:"char";s:15:"input_limit_msg";s:0:"";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";}s:6:"fav_id";s:1:"0";s:6:"def_id";s:1:"0";}i:6;a:7:{s:2:"id";s:1:"6";s:7:"form_id";s:1:"1";s:4:"type";s:9:"_checkbox";s:5:"order";s:1:"4";s:4:"data";a:15:{s:5:"label";s:22:"Выбор да/нет";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:5:"above";s:13:"default_value";s:9:"unchecked";s:3:"req";s:1:"0";s:10:"calc_value";a:2:{s:7:"checked";s:1:"1";s:9:"unchecked";s:1:"0";}s:17:"calc_auto_include";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}i:12;a:7:{s:2:"id";s:2:"12";s:7:"form_id";s:1:"1";s:4:"type";s:5:"_desc";s:5:"order";s:1:"5";s:4:"data";a:8:{s:5:"label";s:4:"Text";s:15:"input_limit_msg";s:17:"character(s) left";s:13:"default_value";s:116:"проверка текстового сообщения\r\n\r\nпроверка текстового сообщения";s:7:"desc_el";s:3:"div";s:5:"class";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}i:9;a:7:{s:2:"id";s:1:"9";s:7:"form_id";s:1:"1";s:4:"type";s:5:"_list";s:5:"order";s:1:"6";s:4:"data";a:19:{s:5:"label";s:10:"Опции";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:4:"left";s:9:"list_type";s:5:"radio";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"0";s:4:"list";a:1:{s:7:"options";a:3:{i:0;a:4:{s:5:"label";s:8:"Option 1";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:8:"Option 2";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:8:"Option 3";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"1";s:17:"calc_auto_include";s:1:"0";s:10:"user_state";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}i:10;a:7:{s:2:"id";s:2:"10";s:7:"form_id";s:1:"1";s:4:"type";s:5:"_list";s:5:"order";s:1:"7";s:4:"data";a:19:{s:5:"label";s:12:"Выборы";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:4:"left";s:9:"list_type";s:8:"checkbox";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"0";s:4:"list";a:1:{s:7:"options";a:3:{i:0;a:4:{s:5:"label";s:8:"Option 1";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:8:"Option 2";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:8:"Option 3";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"0";s:17:"calc_auto_include";s:1:"0";s:10:"user_state";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}i:11;a:7:{s:2:"id";s:2:"11";s:7:"form_id";s:1:"1";s:4:"type";s:5:"_list";s:5:"order";s:1:"8";s:4:"data";a:19:{s:5:"label";s:18:"Выпадайка";s:15:"input_limit_msg";s:17:"character(s) left";s:9:"label_pos";s:5:"above";s:9:"list_type";s:8:"dropdown";s:10:"multi_size";s:1:"5";s:15:"list_show_value";s:1:"0";s:4:"list";a:1:{s:7:"options";a:3:{i:0;a:4:{s:5:"label";s:8:"Option 1";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:1;a:4:{s:5:"label";s:8:"Option 2";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}i:2;a:4:{s:5:"label";s:8:"Option 3";s:5:"value";s:0:"";s:4:"calc";s:0:"";s:8:"selected";s:1:"0";}}}s:21:"user_info_field_group";s:0:"";s:3:"req";s:1:"1";s:17:"calc_auto_include";s:1:"0";s:10:"user_state";s:1:"0";s:8:"num_sort";s:1:"0";s:11:"admin_label";s:0:"";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";N;s:6:"def_id";N;}i:5;a:7:{s:2:"id";s:1:"5";s:7:"form_id";s:1:"1";s:4:"type";s:7:"_submit";s:5:"order";s:1:"9";s:4:"data";a:7:{s:5:"label";s:18:"Отправить";s:5:"class";s:0:"";s:9:"show_help";s:1:"0";s:9:"help_text";s:0:"";s:9:"show_desc";s:1:"0";s:8:"desc_pos";s:4:"none";s:9:"desc_text";s:0:"";}s:6:"fav_id";s:1:"0";s:6:"def_id";s:1:"0";}}s:10:"field_keys";a:0:{}s:6:"errors";a:0:{}}', 'no'),
(1118, 'nf_converted_forms', 'a:1:{i:0;s:1:"3";}', 'yes'),
(1119, '_transient_timeout_nf_form_3', '1449867969', 'no'),
(1120, '_transient_nf_form_3', 'O:7:"NF_Form":5:{s:7:"form_id";s:1:"3";s:8:"settings";a:0:{}s:6:"fields";a:0:{}s:10:"field_keys";a:0:{}s:6:"errors";a:0:{}}', 'no'),
(1121, '_transient_timeout_nf_form_11', '1449867972', 'no'),
(1122, '_transient_nf_form_11', 'O:7:"NF_Form":5:{s:7:"form_id";s:2:"11";s:8:"settings";a:1:{s:6:"status";s:0:"";}s:6:"fields";a:0:{}s:10:"field_keys";a:0:{}s:6:"errors";a:0:{}}', 'no');

-- --------------------------------------------------------

--
-- Структура таблицы `str_postmeta`
--

DROP TABLE IF EXISTS `str_postmeta`;
CREATE TABLE `str_postmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1362 ;

--
-- Дамп данных таблицы `str_postmeta`
--

INSERT INTO `str_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 1, '_wp_old_slug', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80'),
(3, 1, '_edit_lock', '1445895527:1'),
(4, 1, '_edit_last', '1'),
(10, 16, '_edit_last', '1'),
(11, 16, '_edit_lock', '1445895506:1'),
(18, 20, '_edit_last', '1'),
(19, 20, '_edit_lock', '1445895546:1'),
(25, 23, '_edit_last', '1'),
(26, 23, '_edit_lock', '1445895502:1'),
(35, 25, '_edit_last', '1'),
(36, 25, '_edit_lock', '1445895500:1'),
(43, 28, '_wp_old_slug', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80'),
(44, 28, '_edit_lock', '1446010428:1'),
(45, 28, '_edit_last', '1'),
(51, 32, '_edit_lock', '1443681875:1'),
(52, 32, '_edit_last', '1'),
(53, 36, '_edit_lock', '1443681933:1'),
(54, 36, '_edit_last', '1'),
(55, 40, '_edit_lock', '1443681949:1'),
(56, 40, '_edit_last', '1'),
(57, 43, '_edit_lock', '1443681972:1'),
(58, 43, '_edit_last', '1'),
(59, 50, '_edit_last', '1'),
(60, 50, '_edit_lock', '1443681941:1'),
(62, 53, 'header_img', ''),
(63, 53, '_header_img', 'field_52f65021169ed'),
(64, 53, 'show_thumb', '0'),
(65, 53, '_show_thumb', 'field_559706ff40f79'),
(66, 1, 'header_img', ''),
(67, 1, '_header_img', 'field_52f65021169ed'),
(68, 1, 'show_thumb', '0'),
(69, 1, '_show_thumb', 'field_559706ff40f79'),
(71, 54, 'header_img', '17'),
(72, 54, '_header_img', 'field_52f65021169ed'),
(73, 54, 'show_thumb', '1'),
(74, 54, '_show_thumb', 'field_559706ff40f79'),
(75, 23, 'header_img', '17'),
(76, 23, '_header_img', 'field_52f65021169ed'),
(77, 23, 'show_thumb', '1'),
(78, 23, '_show_thumb', 'field_559706ff40f79'),
(79, 55, '_edit_last', '1'),
(80, 55, '_edit_lock', '1447444354:1'),
(82, 55, 'event_date', '1447286400'),
(83, 55, '_event_date', 'field_5596f9ea66508'),
(84, 55, 'event_time', '19.00'),
(85, 55, '_event_time', 'field_5596fa33c4d66'),
(86, 55, 'event_location', 'Москва, Московский международный дом музыки'),
(87, 55, '_event_location', 'field_5596fb25da192'),
(88, 55, 'event_address', 'Космодамианская набережная, дом 52, строение 8'),
(89, 55, '_event_address', 'field_5596fb62201b7'),
(90, 55, 'header_img', 'http://17'),
(91, 55, '_header_img', 'field_55fc1d210d9bb'),
(92, 56, '_edit_last', '1'),
(93, 56, '_edit_lock', '1447444454:1'),
(95, 56, 'event_date', '1445472000'),
(96, 56, '_event_date', 'field_5596f9ea66508'),
(97, 56, 'event_time', '18.00'),
(98, 56, '_event_time', 'field_5596fa33c4d66'),
(99, 56, 'event_location', 'Москва, Общественная палата РФ'),
(100, 56, '_event_location', 'field_5596fb25da192'),
(101, 56, 'event_address', 'ГСП-3, Миусская пл., д. 7, стр. 1'),
(102, 56, '_event_address', 'field_5596fb62201b7'),
(104, 56, '_header_img', 'field_55fc1d210d9bb'),
(105, 57, '_edit_last', '1'),
(106, 57, '_edit_lock', '1447444430:1'),
(108, 57, 'event_date', '1445731200'),
(109, 57, '_event_date', 'field_5596f9ea66508'),
(110, 57, 'event_time', '18.00'),
(111, 57, '_event_time', 'field_5596fa33c4d66'),
(112, 57, 'event_location', 'Москва, Общественная палата РФ'),
(113, 57, '_event_location', 'field_5596fb25da192'),
(114, 57, 'event_address', 'ГСП-3, Миусская пл., д. 7, стр. 1'),
(115, 57, '_event_address', 'field_5596fb62201b7'),
(117, 57, '_header_img', 'field_55fc1d210d9bb'),
(118, 58, '_edit_last', '1'),
(119, 58, '_edit_lock', '1447444226:1'),
(121, 58, 'event_date', '1448236800'),
(122, 58, '_event_date', 'field_5596f9ea66508'),
(123, 58, 'event_time', '19.00'),
(124, 58, '_event_time', 'field_5596fa33c4d66'),
(125, 58, 'event_location', 'Москва, Московский международный дом музыки'),
(126, 58, '_event_location', 'field_5596fb25da192'),
(127, 58, 'event_address', 'Космодамианская набережная, дом 52, строение 8'),
(128, 58, '_event_address', 'field_5596fb62201b7'),
(129, 58, 'header_img', '//giger.local/wp-content/uploads/2015/09/springf_b.jpg'),
(130, 58, '_header_img', 'field_55fc1d210d9bb'),
(131, 59, '_edit_last', '1'),
(132, 59, '_edit_lock', '1447541945:1'),
(135, 59, '_thumbnail_id', '252'),
(136, 61, '_edit_last', '1'),
(137, 61, '_edit_lock', '1447569575:1'),
(140, 61, '_thumbnail_id', '251'),
(141, 63, '_edit_last', '1'),
(142, 63, '_edit_lock', '1447541784:1'),
(148, 66, '_edit_last', '1'),
(149, 66, '_edit_lock', '1447541775:1'),
(150, 66, '_thumbnail_id', '246'),
(151, 67, '_edit_last', '1'),
(152, 67, '_edit_lock', '1447541777:1'),
(153, 67, '_thumbnail_id', '244'),
(154, 68, '_edit_last', '1'),
(155, 68, '_edit_lock', '1447570941:1'),
(156, 68, '_thumbnail_id', '242'),
(157, 2, '_edit_lock', '1447446090:1'),
(158, 2, '_edit_last', '1'),
(159, 72, '_edit_last', '1'),
(160, 72, '_wp_page_template', 'page-home.php'),
(161, 72, '_edit_lock', '1447747786:1'),
(162, 74, '_edit_last', '1'),
(163, 74, '_wp_page_template', 'default'),
(164, 74, '_edit_lock', '1447580828:1'),
(165, 76, '_edit_last', '1'),
(166, 76, '_edit_lock', '1443682489:1'),
(167, 77, '_wp_attached_file', '2015/09/doc-1.pdf'),
(168, 76, '_wp_page_template', 'default'),
(169, 79, '_edit_last', '1'),
(170, 79, '_edit_lock', '1449781681:1'),
(171, 79, '_wp_page_template', 'default'),
(172, 83, '_wp_old_slug', '6_email_'),
(173, 85, '_menu_item_type', 'post_type'),
(174, 85, '_menu_item_menu_item_parent', '0'),
(175, 85, '_menu_item_object_id', '2'),
(176, 85, '_menu_item_object', 'page'),
(177, 85, '_menu_item_target', ''),
(178, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(179, 85, '_menu_item_xfn', ''),
(180, 85, '_menu_item_url', ''),
(182, 86, '_menu_item_type', 'post_type'),
(183, 86, '_menu_item_menu_item_parent', '154'),
(184, 86, '_menu_item_object_id', '74'),
(185, 86, '_menu_item_object', 'page'),
(186, 86, '_menu_item_target', ''),
(187, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(188, 86, '_menu_item_xfn', ''),
(189, 86, '_menu_item_url', ''),
(200, 88, '_menu_item_type', 'custom'),
(201, 88, '_menu_item_menu_item_parent', '154'),
(202, 88, '_menu_item_object_id', '88'),
(203, 88, '_menu_item_object', 'custom'),
(204, 88, '_menu_item_target', ''),
(205, 88, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(206, 88, '_menu_item_xfn', ''),
(207, 88, '_menu_item_url', 'http://giger.local/projects/'),
(209, 90, '_edit_last', '1'),
(210, 90, '_wp_page_template', 'page-calendar.php'),
(211, 90, '_edit_lock', '1442588363:1'),
(212, 92, '_edit_last', '1'),
(213, 92, '_edit_lock', '1442588394:1'),
(214, 92, '_wp_page_template', 'default'),
(215, 94, '_menu_item_type', 'post_type'),
(216, 94, '_menu_item_menu_item_parent', '154'),
(217, 94, '_menu_item_object_id', '90'),
(218, 94, '_menu_item_object', 'page'),
(219, 94, '_menu_item_target', ''),
(220, 94, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(221, 94, '_menu_item_xfn', ''),
(222, 94, '_menu_item_url', ''),
(224, 95, '_menu_item_type', 'post_type'),
(225, 95, '_menu_item_menu_item_parent', '0'),
(226, 95, '_menu_item_object_id', '90'),
(227, 95, '_menu_item_object', 'page'),
(228, 95, '_menu_item_target', ''),
(229, 95, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(230, 95, '_menu_item_xfn', ''),
(231, 95, '_menu_item_url', ''),
(233, 96, '_menu_item_type', 'post_type'),
(234, 96, '_menu_item_menu_item_parent', '98'),
(235, 96, '_menu_item_object_id', '79'),
(236, 96, '_menu_item_object', 'page'),
(237, 96, '_menu_item_target', ''),
(238, 96, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(239, 96, '_menu_item_xfn', ''),
(240, 96, '_menu_item_url', ''),
(242, 97, '_menu_item_type', 'post_type'),
(243, 97, '_menu_item_menu_item_parent', '0'),
(244, 97, '_menu_item_object_id', '74'),
(245, 97, '_menu_item_object', 'page'),
(246, 97, '_menu_item_target', ''),
(247, 97, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(248, 97, '_menu_item_xfn', ''),
(249, 97, '_menu_item_url', ''),
(251, 98, '_menu_item_type', 'post_type'),
(252, 98, '_menu_item_menu_item_parent', '0'),
(253, 98, '_menu_item_object_id', '2'),
(254, 98, '_menu_item_object', 'page'),
(255, 98, '_menu_item_target', ''),
(256, 98, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(257, 98, '_menu_item_xfn', ''),
(258, 98, '_menu_item_url', ''),
(260, 99, '_menu_item_type', 'custom'),
(261, 99, '_menu_item_menu_item_parent', '0'),
(262, 99, '_menu_item_object_id', '99'),
(263, 99, '_menu_item_object', 'custom'),
(264, 99, '_menu_item_target', ''),
(265, 99, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(266, 99, '_menu_item_xfn', ''),
(267, 99, '_menu_item_url', 'http://giger.local/projects/'),
(269, 100, '_edit_last', '1'),
(270, 100, '_edit_lock', '1447445148:1'),
(272, 100, 'event_date', '1449878400'),
(273, 100, '_event_date', 'field_5596f9ea66508'),
(274, 100, 'event_time', '19.00'),
(275, 100, '_event_time', 'field_5596fa33c4d66'),
(276, 100, 'event_location', 'Москва, Московский международный дом музыки'),
(277, 100, '_event_location', 'field_5596fb25da192'),
(278, 100, 'event_address', 'Космодамианская набережная, дом 52, строение 8'),
(279, 100, '_event_address', 'field_5596fb62201b7'),
(280, 100, 'header_img', 'http://17'),
(281, 100, '_header_img', 'field_55fc1d210d9bb'),
(282, 101, '_menu_item_type', 'post_type'),
(283, 101, '_menu_item_menu_item_parent', '98'),
(284, 101, '_menu_item_object_id', '76'),
(285, 101, '_menu_item_object', 'page'),
(286, 101, '_menu_item_target', ''),
(287, 101, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(288, 101, '_menu_item_xfn', ''),
(289, 101, '_menu_item_url', ''),
(321, 108, '_edit_last', '1'),
(322, 108, '_edit_lock', '1445923829:1'),
(323, 108, 'header_img', ''),
(324, 108, '_header_img', 'field_55fc1d6c8ed96'),
(326, 109, '_edit_last', '1'),
(327, 109, '_edit_lock', '1449750615:1'),
(329, 109, '_header_img', 'field_55fc1d6c8ed96'),
(331, 110, '_edit_last', '1'),
(332, 110, '_edit_lock', '1447451160:1'),
(335, 110, '_header_img', 'field_55fc1d6c8ed96'),
(345, 112, '_menu_item_type', 'post_type'),
(346, 112, '_menu_item_menu_item_parent', '85'),
(347, 112, '_menu_item_object_id', '76'),
(348, 112, '_menu_item_object', 'page'),
(349, 112, '_menu_item_target', ''),
(350, 112, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(351, 112, '_menu_item_xfn', ''),
(352, 112, '_menu_item_url', ''),
(402, 121, 'target_state', 'no_target'),
(403, 121, 'is_finished', '0'),
(404, 121, 'total_funded', '1000'),
(405, 121, '_edit_last', '1'),
(406, 121, '_edit_lock', '1442612200:1'),
(407, 121, 'campaign_template', 'default'),
(408, 121, '_wp_old_slug', 'pomoch-nam'),
(409, 121, 'count_views', '3'),
(410, 122, '_menu_item_type', 'post_type'),
(411, 122, '_menu_item_menu_item_parent', '0'),
(412, 122, '_menu_item_object_id', '121'),
(413, 122, '_menu_item_object', 'leyka_campaign'),
(414, 122, '_menu_item_target', ''),
(415, 122, '_menu_item_classes', 'a:1:{i:0;s:6:"donate";}'),
(416, 122, '_menu_item_xfn', ''),
(417, 122, '_menu_item_url', ''),
(419, 110, 'show_thumb', '1'),
(420, 110, '_show_thumb', 'field_559706ff40f79'),
(421, 108, 'show_thumb', '1'),
(422, 108, '_show_thumb', 'field_559706ff40f79'),
(424, 28, 'header_img', ''),
(425, 28, '_header_img', 'field_52f65021169ed'),
(426, 28, 'show_thumb', '1'),
(427, 28, '_show_thumb', 'field_559706ff40f79'),
(429, 20, 'header_img', '17'),
(430, 20, '_header_img', 'field_52f65021169ed'),
(431, 20, 'show_thumb', '0'),
(432, 20, '_show_thumb', 'field_559706ff40f79'),
(433, 123, 'leyka_donation_amount', '500'),
(434, 123, 'leyka_donation_currency', 'rur'),
(435, 123, 'leyka_main_curr_amount', '500'),
(436, 123, 'leyka_donor_name', 'Маша'),
(437, 123, 'leyka_donor_email', 'nordworldofann@gmail.com'),
(438, 123, 'leyka_payment_method', 'bank_order'),
(439, 123, 'leyka_gateway', 'quittance'),
(440, 123, 'leyka_campaign_id', '121'),
(441, 123, '_leyka_donor_email_date', '0'),
(442, 123, '_leyka_managers_emails_date', '0'),
(443, 123, '_status_log', 'a:2:{i:0;a:2:{s:4:"date";i:1442645482;s:6:"status";s:9:"submitted";}i:1;a:2:{s:4:"date";i:1442645573;s:6:"status";s:6:"funded";}}'),
(444, 123, 'leyka_payment_type', 'single'),
(445, 123, 'leyka_recurrents_cancel_date', '0'),
(446, 121, 'count_submits', '2'),
(447, 124, 'leyka_donation_amount', '500'),
(448, 124, 'leyka_donation_currency', 'rur'),
(449, 124, 'leyka_main_curr_amount', '500'),
(450, 124, 'leyka_donor_name', 'Петр Семенович'),
(451, 124, 'leyka_donor_email', 'test@test.ru'),
(452, 124, 'leyka_payment_method', 'bank_order'),
(453, 124, 'leyka_gateway', 'quittance'),
(454, 124, 'leyka_campaign_id', '121'),
(455, 124, '_leyka_donor_email_date', '0'),
(456, 124, '_leyka_managers_emails_date', '0'),
(457, 124, '_status_log', 'a:2:{i:0;a:2:{s:4:"date";i:1442645515;s:6:"status";s:9:"submitted";}i:1;a:2:{s:4:"date";i:1442645553;s:6:"status";s:6:"funded";}}'),
(458, 124, 'leyka_payment_type', 'single'),
(459, 124, 'leyka_recurrents_cancel_date', '0'),
(460, 124, '_edit_lock', '1442645414:1'),
(461, 124, '_edit_last', '1'),
(462, 123, '_edit_lock', '1442645933:1'),
(463, 123, '_edit_last', '1'),
(465, 125, 'header_img', ''),
(466, 125, '_header_img', 'field_52f65021169ed'),
(467, 125, 'show_thumb', '0'),
(468, 125, '_show_thumb', 'field_559706ff40f79'),
(470, 126, 'header_img', '17'),
(471, 126, '_header_img', 'field_52f65021169ed'),
(472, 126, 'show_thumb', '0'),
(473, 126, '_show_thumb', 'field_559706ff40f79'),
(479, 128, '_edit_lock', '1446928468:1'),
(495, 128, '_edit_last', '1'),
(496, 76, 'header_img', ''),
(497, 76, '_header_img', 'field_55a0ae7eee28b'),
(498, 76, 'embed_posts_title', ''),
(499, 76, '_embed_posts_title', 'field_5602d1d1055a7'),
(500, 76, 'embed_posts', ''),
(501, 76, '_embed_posts', 'field_5602bd8ab85b3'),
(503, 79, '_header_img', 'field_55a0ae7eee28b'),
(504, 79, 'embed_posts_title', ''),
(505, 79, '_embed_posts_title', 'field_5602d1d1055a7'),
(506, 79, 'embed_posts', ''),
(507, 79, '_embed_posts', 'field_5602bd8ab85b3'),
(508, 139, '_edit_lock', '1445924873:1'),
(509, 139, '_edit_last', '1'),
(510, 143, '_edit_lock', '1446928545:1'),
(511, 143, '_edit_last', '1'),
(512, 149, '_edit_last', '1'),
(513, 149, '_edit_lock', '1447525902:1'),
(514, 149, '_wp_page_template', 'default'),
(515, 150, 'header_img', ''),
(516, 150, '_header_img', 'field_55a0ae7eee28b'),
(517, 150, 'embed_posts_title', ''),
(518, 150, '_embed_posts_title', 'field_5602d1d1055a7'),
(519, 150, 'embed_posts', ''),
(520, 150, '_embed_posts', 'field_5602bd8ab85b3'),
(522, 149, '_header_img', 'field_55a0ae7eee28b'),
(523, 149, 'embed_posts_title', 'Встроенные элементы'),
(524, 149, '_embed_posts_title', 'field_5602d1d1055a7'),
(525, 149, 'embed_posts', 'a:3:{i:0;s:2:"28";i:1;s:2:"16";i:2;s:2:"20";}'),
(526, 149, '_embed_posts', 'field_5602bd8ab85b3'),
(527, 151, 'header_img', ''),
(528, 151, '_header_img', 'field_55a0ae7eee28b'),
(529, 151, 'embed_posts_title', ''),
(530, 151, '_embed_posts_title', 'field_5602d1d1055a7'),
(531, 151, 'embed_posts', 'a:2:{i:0;s:2:"16";i:1;s:2:"20";}'),
(532, 151, '_embed_posts', 'field_5602bd8ab85b3'),
(542, 153, '_menu_item_type', 'post_type'),
(543, 153, '_menu_item_menu_item_parent', '85'),
(544, 153, '_menu_item_object_id', '79'),
(545, 153, '_menu_item_object', 'page'),
(546, 153, '_menu_item_target', ''),
(547, 153, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(548, 153, '_menu_item_xfn', ''),
(549, 153, '_menu_item_url', ''),
(551, 154, '_menu_item_type', 'post_type'),
(552, 154, '_menu_item_menu_item_parent', '0'),
(553, 154, '_menu_item_object_id', '149'),
(554, 154, '_menu_item_object', 'page'),
(555, 154, '_menu_item_target', ''),
(556, 154, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(557, 154, '_menu_item_xfn', ''),
(558, 154, '_menu_item_url', ''),
(562, 155, '_wp_attached_file', '2015/10/testface2.jpg'),
(563, 155, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:640;s:6:"height";i:425;s:4:"file";s:21:"2015/10/testface2.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"testface2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"testface2-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"testface2-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:21:"testface2-640x420.jpg";s:5:"width";i:640;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:21:"testface2-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:19:"testface2-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:21:"testface2-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(628, 159, '_menu_item_type', 'post_type'),
(629, 159, '_menu_item_menu_item_parent', '0'),
(630, 159, '_menu_item_object_id', '2'),
(631, 159, '_menu_item_object', 'page'),
(632, 159, '_menu_item_target', ''),
(633, 159, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(634, 159, '_menu_item_xfn', ''),
(635, 159, '_menu_item_url', ''),
(646, 161, '_menu_item_type', 'post_type'),
(647, 161, '_menu_item_menu_item_parent', '0'),
(648, 161, '_menu_item_object_id', '79'),
(649, 161, '_menu_item_object', 'page'),
(650, 161, '_menu_item_target', ''),
(651, 161, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(652, 161, '_menu_item_xfn', ''),
(653, 161, '_menu_item_url', ''),
(655, 162, '_menu_item_type', 'post_type'),
(656, 162, '_menu_item_menu_item_parent', '0'),
(657, 162, '_menu_item_object_id', '76'),
(658, 162, '_menu_item_object', 'page'),
(659, 162, '_menu_item_target', ''),
(660, 162, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(661, 162, '_menu_item_xfn', ''),
(662, 162, '_menu_item_url', ''),
(673, 164, 'header_img', ''),
(674, 164, '_header_img', 'field_55a0ae7eee28b'),
(675, 164, 'embed_posts_title', ''),
(676, 164, '_embed_posts_title', 'field_5602d1d1055a7'),
(677, 164, 'embed_posts', ''),
(678, 164, '_embed_posts', 'field_5602bd8ab85b3'),
(679, 2, 'header_img', '//giger.local/wp-content/uploads/2015/09/greena_k.jpg'),
(680, 2, '_header_img', 'field_55a0ae7eee28b'),
(681, 2, 'embed_posts_title', ''),
(682, 2, '_embed_posts_title', 'field_5602d1d1055a7'),
(683, 2, 'embed_posts', ''),
(684, 2, '_embed_posts', 'field_5602bd8ab85b3'),
(685, 165, '_menu_item_type', 'post_type'),
(686, 165, '_menu_item_menu_item_parent', '0'),
(687, 165, '_menu_item_object_id', '149'),
(688, 165, '_menu_item_object', 'page'),
(689, 165, '_menu_item_target', ''),
(690, 165, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(691, 165, '_menu_item_xfn', ''),
(692, 165, '_menu_item_url', ''),
(694, 166, '_menu_item_type', 'post_type'),
(695, 166, '_menu_item_menu_item_parent', '0'),
(696, 166, '_menu_item_object_id', '74'),
(697, 166, '_menu_item_object', 'page'),
(698, 166, '_menu_item_target', ''),
(699, 166, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(700, 166, '_menu_item_xfn', ''),
(701, 166, '_menu_item_url', ''),
(703, 167, '_menu_item_type', 'post_type'),
(704, 167, '_menu_item_menu_item_parent', '0'),
(705, 167, '_menu_item_object_id', '90'),
(706, 167, '_menu_item_object', 'page'),
(707, 167, '_menu_item_target', ''),
(708, 167, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(709, 167, '_menu_item_xfn', ''),
(710, 167, '_menu_item_url', ''),
(712, 168, '_menu_item_type', 'custom'),
(713, 168, '_menu_item_menu_item_parent', '0'),
(714, 168, '_menu_item_object_id', '168'),
(715, 168, '_menu_item_object', 'custom'),
(716, 168, '_menu_item_target', ''),
(717, 168, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(718, 168, '_menu_item_xfn', ''),
(719, 168, '_menu_item_url', 'http://giger.local/projects/'),
(755, 72, '_header_img', 'field_5602f579fa897'),
(757, 72, '_partners_bg', 'field_55a56a875c831'),
(758, 72, 'home_partners', 'a:4:{i:0;s:2:"61";i:1;s:2:"67";i:2;s:2:"66";i:3;s:2:"59";}'),
(759, 72, '_home_partners', 'field_55a56ac7e1529'),
(798, 182, '_menu_item_type', 'custom'),
(799, 182, '_menu_item_menu_item_parent', '0'),
(800, 182, '_menu_item_object_id', '182'),
(801, 182, '_menu_item_object', 'custom'),
(802, 182, '_menu_item_target', ''),
(803, 182, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(804, 182, '_menu_item_xfn', ''),
(805, 182, '_menu_item_url', 'https://www.facebook.com/TeplitsaST'),
(807, 183, '_menu_item_type', 'custom'),
(808, 183, '_menu_item_menu_item_parent', '0'),
(809, 183, '_menu_item_object_id', '183'),
(810, 183, '_menu_item_object', 'custom'),
(811, 183, '_menu_item_target', ''),
(812, 183, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(813, 183, '_menu_item_xfn', ''),
(814, 183, '_menu_item_url', 'http://vk.com/public36626584'),
(855, 191, '_wp_attached_file', '2015/10/green_o.gif'),
(856, 191, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:369;s:6:"height";i:282;s:4:"file";s:19:"2015/10/green_o.gif";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"green_o-150x150.gif";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/gif";}s:6:"medium";a:4:{s:4:"file";s:19:"green_o-300x229.gif";s:5:"width";i:300;s:6:"height";i:229;s:9:"mime-type";s:9:"image/gif";}s:14:"post-thumbnail";a:4:{s:4:"file";s:19:"green_o-369x208.gif";s:5:"width";i:369;s:6:"height";i:208;s:9:"mime-type";s:9:"image/gif";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:19:"green_o-369x260.gif";s:5:"width";i:369;s:6:"height";i:260;s:9:"mime-type";s:9:"image/gif";}s:6:"avatar";a:4:{s:4:"file";s:17:"green_o-40x40.gif";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:9:"image/gif";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:19:"green_o-190x142.gif";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:9:"image/gif";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(906, 25, 'header_img', ''),
(907, 25, '_header_img', 'field_52f65021169ed'),
(908, 25, 'show_thumb', '1'),
(909, 25, '_show_thumb', 'field_559706ff40f79'),
(918, 196, 'header_img', '194'),
(919, 196, '_header_img', 'field_52f65021169ed'),
(920, 196, 'show_thumb', '1'),
(921, 196, '_show_thumb', 'field_559706ff40f79'),
(922, 16, 'header_img', '194'),
(923, 16, '_header_img', 'field_52f65021169ed'),
(924, 16, 'show_thumb', '1'),
(925, 16, '_show_thumb', 'field_559706ff40f79'),
(981, 206, 'header_img', ''),
(982, 206, '_header_img', 'field_5602f579fa897'),
(983, 206, 'partners_bg', '194'),
(984, 206, '_partners_bg', 'field_55a56a875c831'),
(985, 206, 'home_partners', 'a:4:{i:0;s:2:"61";i:1;s:2:"63";i:2;s:2:"59";i:3;s:2:"68";}'),
(986, 206, '_home_partners', 'field_55a56ac7e1529'),
(987, 208, '_wp_attached_file', '2015/09/greena_k.jpg'),
(988, 208, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:526;s:4:"file";s:20:"2015/09/greena_k.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"greena_k-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"greena_k-300x197.jpg";s:5:"width";i:300;s:6:"height";i:197;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:20:"greena_k-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:20:"greena_k-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:20:"greena_k-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:18:"greena_k-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:20:"greena_k-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(989, 209, '_wp_attached_file', '2015/09/springf_b.jpg'),
(990, 209, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:819;s:4:"file";s:21:"2015/09/springf_b.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"springf_b-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"springf_b-300x240.jpg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"springf_b-1024x819.jpg";s:5:"width";i:1024;s:6:"height";i:819;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"springf_b-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:21:"springf_b-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:21:"springf_b-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:19:"springf_b-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:21:"springf_b-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(991, 210, '_wp_attached_file', '2015/09/Thistle_b.jpg'),
(992, 210, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1024;s:6:"height";i:768;s:4:"file";s:21:"2015/09/Thistle_b.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"Thistle_b-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"Thistle_b-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"Thistle_b-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:21:"Thistle_b-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:21:"Thistle_b-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:21:"Thistle_b-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:19:"Thistle_b-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:21:"Thistle_b-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(993, 28, '_thumbnail_id', '208'),
(995, 25, '_thumbnail_id', '210'),
(997, 23, '_thumbnail_id', '209'),
(999, 16, '_thumbnail_id', '208'),
(1001, 20, '_thumbnail_id', '209'),
(1003, 1, '_thumbnail_id', '208'),
(1005, 110, '_thumbnail_id', '209'),
(1006, 108, '_thumbnail_id', '208'),
(1007, 109, '_thumbnail_id', '210'),
(1008, 58, '_thumbnail_id', '209'),
(1009, 57, '_thumbnail_id', '208'),
(1010, 56, '_thumbnail_id', '210'),
(1011, 55, '_thumbnail_id', '208'),
(1012, 100, '_thumbnail_id', '210'),
(1013, 211, 'header_img', ''),
(1014, 211, '_header_img', 'field_5602f579fa897'),
(1015, 211, 'partners_bg', '194'),
(1016, 211, '_partners_bg', 'field_55a56a875c831'),
(1017, 211, 'home_partners', 'a:4:{i:0;s:2:"61";i:1;s:2:"63";i:2;s:2:"59";i:3;s:2:"68";}'),
(1018, 211, '_home_partners', 'field_55a56ac7e1529'),
(1019, 212, 'header_img', ''),
(1020, 212, '_header_img', 'field_5602f579fa897'),
(1021, 212, 'partners_bg', '210'),
(1022, 212, '_partners_bg', 'field_55a56a875c831'),
(1023, 212, 'home_partners', 'a:4:{i:0;s:2:"61";i:1;s:2:"63";i:2;s:2:"59";i:3;s:2:"68";}'),
(1024, 212, '_home_partners', 'field_55a56ac7e1529'),
(1025, 213, 'header_img', ''),
(1026, 213, '_header_img', 'field_5602f579fa897'),
(1027, 213, 'partners_bg', '208'),
(1028, 213, '_partners_bg', 'field_55a56a875c831'),
(1029, 213, 'home_partners', 'a:4:{i:0;s:2:"61";i:1;s:2:"63";i:2;s:2:"59";i:3;s:2:"68";}'),
(1030, 213, '_home_partners', 'field_55a56ac7e1529'),
(1031, 214, 'header_img', ''),
(1032, 214, '_header_img', 'field_55a0ae7eee28b'),
(1033, 214, 'embed_posts_title', ''),
(1034, 214, '_embed_posts_title', 'field_5602d1d1055a7'),
(1035, 214, 'embed_posts', 'a:3:{i:0;s:2:"16";i:1;s:2:"20";i:2;s:2:"28";}'),
(1036, 214, '_embed_posts', 'field_5602bd8ab85b3'),
(1037, 215, 'header_img', ''),
(1038, 215, '_header_img', 'field_55a0ae7eee28b'),
(1039, 215, 'embed_posts_title', ''),
(1040, 215, '_embed_posts_title', 'field_5602d1d1055a7'),
(1041, 215, 'embed_posts', 'a:3:{i:0;s:2:"28";i:1;s:2:"16";i:2;s:2:"20";}'),
(1042, 215, '_embed_posts', 'field_5602bd8ab85b3'),
(1043, 218, '_edit_lock', '1446928788:1'),
(1044, 226, 'embed_posts_title', 'Встроенные элементы'),
(1045, 226, '_embed_posts_title', 'field_5602d1d1055a7'),
(1046, 226, 'embed_posts', 'a:3:{i:0;s:2:"28";i:1;s:2:"16";i:2;s:2:"20";}'),
(1047, 226, '_embed_posts', 'field_5602bd8ab85b3'),
(1048, 226, 'header_img', ''),
(1049, 226, '_header_img', 'field_55a0ae7eee28b'),
(1103, 221, '_edit_lock', '1446930923:1'),
(1122, 233, 'header_img', ''),
(1123, 233, '_header_img', 'field_55a0ae7eee28b'),
(1124, 234, '_edit_last', '1'),
(1125, 234, '_edit_lock', '1449750768:1'),
(1126, 234, '_thumbnail_id', '208'),
(1128, 235, 'header_img', ''),
(1129, 235, '_header_img', 'field_52f65021169ed'),
(1130, 235, 'show_thumb', '1'),
(1131, 235, '_show_thumb', 'field_559706ff40f79'),
(1132, 234, 'header_img', '//giger.local/wp-content/uploads/2015/09/greena_k.jpg'),
(1133, 234, '_header_img', 'field_52f65021169ed'),
(1134, 234, 'show_thumb', '1'),
(1135, 234, '_show_thumb', 'field_559706ff40f79'),
(1137, 236, 'header_img', ''),
(1138, 236, '_header_img', 'field_52f65021169ed'),
(1139, 236, 'show_thumb', '1'),
(1140, 236, '_show_thumb', 'field_559706ff40f79'),
(1141, 237, '_wp_old_slug', '9_email_'),
(1142, 237, '_wp_old_slug', '9_email_438'),
(1143, 238, 'header_img', ''),
(1144, 238, '_header_img', 'field_55a0ae7eee28b'),
(1145, 239, 'header_img', ''),
(1146, 239, '_header_img', 'field_55a0ae7eee28b'),
(1147, 240, 'header_img', ''),
(1148, 240, '_header_img', 'field_55a0ae7eee28b'),
(1149, 242, '_wp_attached_file', '2015/09/audit.png'),
(1150, 242, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:310;s:6:"height";i:73;s:4:"file";s:17:"2015/09/audit.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:16:"audit-150x73.png";s:5:"width";i:150;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:16:"audit-300x71.png";s:5:"width";i:300;s:6:"height";i:71;s:9:"mime-type";s:9:"image/png";}s:6:"avatar";a:4:{s:4:"file";s:15:"audit-40x40.png";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:9:"image/png";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:16:"audit-190x73.png";s:5:"width";i:190;s:6:"height";i:73;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1151, 244, '_wp_attached_file', '2015/09/itv.png'),
(1152, 244, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:400;s:6:"height";i:200;s:4:"file";s:15:"2015/09/itv.png";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:15:"itv-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:15:"itv-300x150.png";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:14:"post-thumbnail";a:4:{s:4:"file";s:15:"itv-370x200.png";s:5:"width";i:370;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:15:"itv-400x200.png";s:5:"width";i:400;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";}s:6:"avatar";a:4:{s:4:"file";s:13:"itv-40x40.png";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:9:"image/png";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:15:"itv-190x142.png";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1153, 246, '_wp_attached_file', '2015/09/paseka.png'),
(1154, 246, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:326;s:6:"height";i:131;s:4:"file";s:18:"2015/09/paseka.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"paseka-150x131.png";s:5:"width";i:150;s:6:"height";i:131;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"paseka-300x121.png";s:5:"width";i:300;s:6:"height";i:121;s:9:"mime-type";s:9:"image/png";}s:6:"avatar";a:4:{s:4:"file";s:16:"paseka-40x40.png";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:9:"image/png";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:18:"paseka-190x131.png";s:5:"width";i:190;s:6:"height";i:131;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1157, 249, '_wp_attached_file', '2015/09/leyka.png'),
(1158, 249, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:356;s:6:"height";i:147;s:4:"file";s:17:"2015/09/leyka.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"leyka-150x147.png";s:5:"width";i:150;s:6:"height";i:147;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"leyka-300x124.png";s:5:"width";i:300;s:6:"height";i:124;s:9:"mime-type";s:9:"image/png";}s:6:"avatar";a:4:{s:4:"file";s:15:"leyka-40x40.png";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:9:"image/png";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:17:"leyka-190x142.png";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1159, 63, '_thumbnail_id', '249'),
(1160, 251, '_wp_attached_file', '2015/09/teplitsa.png'),
(1161, 251, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:259;s:6:"height";i:170;s:4:"file";s:20:"2015/09/teplitsa.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"teplitsa-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"avatar";a:4:{s:4:"file";s:18:"teplitsa-40x40.png";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:9:"image/png";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:20:"teplitsa-190x142.png";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1162, 252, '_wp_attached_file', '2015/09/asi-logo-blank-sm.png'),
(1163, 252, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:232;s:6:"height";i:80;s:4:"file";s:29:"2015/09/asi-logo-blank-sm.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"asi-logo-blank-sm-150x80.png";s:5:"width";i:150;s:6:"height";i:80;s:9:"mime-type";s:9:"image/png";}s:6:"avatar";a:4:{s:4:"file";s:27:"asi-logo-blank-sm-40x40.png";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:9:"image/png";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:28:"asi-logo-blank-sm-190x80.png";s:5:"width";i:190;s:6:"height";i:80;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1166, 254, '_wp_old_slug', '6_email_'),
(1167, 255, '_wp_old_slug', '9_email_438'),
(1168, 256, 'header_img', ''),
(1169, 256, '_header_img', 'field_55a0ae7eee28b'),
(1170, 6, '_edit_lock', '1449741208:1'),
(1171, 2, 'header_img_id', '208'),
(1172, 58, 'header_img_id', '209'),
(1174, 234, 'header_img_id', '208'),
(1177, 260, '_edit_last', '1'),
(1178, 260, '_edit_lock', '1447530327:1'),
(1179, 260, '_thumbnail_id', '155'),
(1180, 261, '_edit_last', '1'),
(1181, 261, '_edit_lock', '1447534508:1'),
(1182, 261, '_thumbnail_id', '155'),
(1183, 262, '_edit_last', '1'),
(1184, 262, '_edit_lock', '1447572166:1'),
(1185, 262, '_thumbnail_id', '191'),
(1186, 263, '_edit_last', '1'),
(1187, 263, '_edit_lock', '1447570873:1'),
(1188, 264, '_wp_attached_file', '2015/11/ch1_b.jpg'),
(1189, 264, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:600;s:4:"file";s:17:"2015/11/ch1_b.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"ch1_b-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"ch1_b-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"ch1_b-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:17:"ch1_b-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:17:"ch1_b-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:15:"ch1_b-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:17:"ch1_b-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1190, 265, '_wp_attached_file', '2015/11/ch2_b.jpg'),
(1191, 265, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:600;s:4:"file";s:17:"2015/11/ch2_b.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"ch2_b-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"ch2_b-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"ch2_b-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:17:"ch2_b-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:17:"ch2_b-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:15:"ch2_b-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:17:"ch2_b-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1192, 266, '_wp_attached_file', '2015/11/ch3_o.jpg'),
(1193, 266, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:600;s:4:"file";s:17:"2015/11/ch3_o.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"ch3_o-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"ch3_o-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"ch3_o-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:17:"ch3_o-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:17:"ch3_o-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:15:"ch3_o-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:17:"ch3_o-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1194, 267, '_wp_attached_file', '2015/11/ch4_k.jpg'),
(1195, 267, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:801;s:6:"height";i:600;s:4:"file";s:17:"2015/11/ch4_k.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"ch4_k-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"ch4_k-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"ch4_k-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:17:"ch4_k-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:17:"ch4_k-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:15:"ch4_k-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:17:"ch4_k-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1198, 269, '_wp_attached_file', '2015/11/ch6_k.jpg'),
(1199, 269, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:600;s:4:"file";s:17:"2015/11/ch6_k.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"ch6_k-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"ch6_k-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:17:"ch6_k-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:17:"ch6_k-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:17:"ch6_k-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:15:"ch6_k-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:17:"ch6_k-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1200, 263, '_thumbnail_id', '269'),
(1201, 270, '_edit_last', '1'),
(1202, 270, '_edit_lock', '1447571092:1'),
(1203, 271, '_wp_attached_file', '2015/11/ch2_b1.jpg'),
(1204, 271, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:600;s:4:"file";s:18:"2015/11/ch2_b1.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"ch2_b1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"ch2_b1-300x225.jpg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";}s:14:"post-thumbnail";a:4:{s:4:"file";s:18:"ch2_b1-370x208.jpg";s:5:"width";i:370;s:6:"height";i:208;s:9:"mime-type";s:10:"image/jpeg";}s:5:"embed";a:4:{s:4:"file";s:18:"ch2_b1-760x420.jpg";s:5:"width";i:760;s:6:"height";i:420;s:9:"mime-type";s:10:"image/jpeg";}s:15:"thumbnail-embed";a:4:{s:4:"file";s:18:"ch2_b1-400x260.jpg";s:5:"width";i:400;s:6:"height";i:260;s:9:"mime-type";s:10:"image/jpeg";}s:6:"avatar";a:4:{s:4:"file";s:16:"ch2_b1-40x40.jpg";s:5:"width";i:40;s:6:"height";i:40;s:9:"mime-type";s:10:"image/jpeg";}s:19:"thumbnail-landscape";a:4:{s:4:"file";s:18:"ch2_b1-190x142.jpg";s:5:"width";i:190;s:6:"height";i:142;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1205, 270, '_thumbnail_id', '271'),
(1206, 272, '_edit_last', '1'),
(1207, 272, '_edit_lock', '1447571242:1'),
(1208, 272, '_thumbnail_id', '267'),
(1218, 274, '_menu_item_type', 'taxonomy'),
(1219, 274, '_menu_item_menu_item_parent', '85'),
(1220, 274, '_menu_item_object_id', '11'),
(1221, 274, '_menu_item_object', 'person_cat'),
(1222, 274, '_menu_item_target', ''),
(1223, 274, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1224, 274, '_menu_item_xfn', ''),
(1225, 274, '_menu_item_url', ''),
(1227, 275, '_menu_item_type', 'taxonomy'),
(1228, 275, '_menu_item_menu_item_parent', '85'),
(1229, 275, '_menu_item_object_id', '12'),
(1230, 275, '_menu_item_object', 'org_cat'),
(1231, 275, '_menu_item_target', ''),
(1232, 275, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1233, 275, '_menu_item_xfn', ''),
(1234, 275, '_menu_item_url', ''),
(1236, 276, '_menu_item_type', 'taxonomy'),
(1237, 276, '_menu_item_menu_item_parent', '0'),
(1238, 276, '_menu_item_object_id', '13'),
(1239, 276, '_menu_item_object', 'person_cat'),
(1240, 276, '_menu_item_target', ''),
(1241, 276, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1242, 276, '_menu_item_xfn', ''),
(1243, 276, '_menu_item_url', ''),
(1245, 277, '_edit_last', '1'),
(1246, 277, '_edit_lock', '1447582755:1'),
(1247, 277, '_thumbnail_id', '264'),
(1248, 278, '_thumbnail_id', '266'),
(1249, 278, '_edit_last', '1'),
(1250, 278, '_edit_lock', '1447572026:1'),
(1251, 279, '_edit_last', '1'),
(1252, 279, '_edit_lock', '1447572293:1'),
(1253, 279, '_thumbnail_id', '191'),
(1254, 280, '_menu_item_type', 'taxonomy'),
(1255, 280, '_menu_item_menu_item_parent', '0'),
(1256, 280, '_menu_item_object_id', '12'),
(1257, 280, '_menu_item_object', 'org_cat'),
(1258, 280, '_menu_item_target', ''),
(1259, 280, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1260, 280, '_menu_item_xfn', ''),
(1261, 280, '_menu_item_url', ''),
(1263, 281, '_menu_item_type', 'taxonomy'),
(1264, 281, '_menu_item_menu_item_parent', '0'),
(1265, 281, '_menu_item_object_id', '11'),
(1266, 281, '_menu_item_object', 'person_cat'),
(1267, 281, '_menu_item_target', ''),
(1268, 281, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1269, 281, '_menu_item_xfn', ''),
(1270, 281, '_menu_item_url', ''),
(1272, 282, '_menu_item_type', 'taxonomy'),
(1273, 282, '_menu_item_menu_item_parent', '98'),
(1274, 282, '_menu_item_object_id', '12'),
(1275, 282, '_menu_item_object', 'org_cat'),
(1276, 282, '_menu_item_target', ''),
(1277, 282, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1278, 282, '_menu_item_xfn', ''),
(1279, 282, '_menu_item_url', ''),
(1281, 283, '_menu_item_type', 'taxonomy'),
(1282, 283, '_menu_item_menu_item_parent', '98'),
(1283, 283, '_menu_item_object_id', '11'),
(1284, 283, '_menu_item_object', 'person_cat'),
(1285, 283, '_menu_item_target', ''),
(1286, 283, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1287, 283, '_menu_item_xfn', ''),
(1288, 283, '_menu_item_url', ''),
(1290, 284, '_menu_item_type', 'taxonomy'),
(1291, 284, '_menu_item_menu_item_parent', '0'),
(1292, 284, '_menu_item_object_id', '13'),
(1293, 284, '_menu_item_object', 'person_cat'),
(1294, 284, '_menu_item_target', ''),
(1295, 284, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1296, 284, '_menu_item_xfn', ''),
(1297, 284, '_menu_item_url', ''),
(1299, 285, '_menu_item_type', 'post_type'),
(1300, 285, '_menu_item_menu_item_parent', '0'),
(1301, 285, '_menu_item_object_id', '121'),
(1302, 285, '_menu_item_object', 'leyka_campaign'),
(1303, 285, '_menu_item_target', ''),
(1304, 285, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1305, 285, '_menu_item_xfn', ''),
(1306, 285, '_menu_item_url', ''),
(1312, 72, 'home_profiles_order', 'second'),
(1313, 72, 'home_news_order', 'first'),
(1314, 72, 'home_projects_order', 'third'),
(1315, 72, 'home_profiles_cat', '13'),
(1316, 72, 'home_news_cat', '3'),
(1317, 288, '_edit_last', '1'),
(1318, 288, '_edit_lock', '1447580713:1'),
(1319, 288, '_thumbnail_id', '264'),
(1320, 288, '_wp_old_slug', 'masha-ivanova-2'),
(1321, 289, '_edit_last', '1'),
(1322, 289, '_edit_lock', '1447743210:1'),
(1323, 289, '_wp_trash_meta_status', 'draft'),
(1324, 289, '_wp_trash_meta_time', '1447743278'),
(1325, 7, '_edit_lock', '1449741188:1'),
(1326, 7, '_edit_last', '1'),
(1327, 7, '_wp_page_template', 'page-simple.php'),
(1328, 6, '_edit_last', '1'),
(1329, 6, '_wp_page_template', 'page-simple.php'),
(1330, 293, '_edit_last', '1'),
(1331, 293, '_edit_lock', '1449741308:1'),
(1332, 293, '_wp_page_template', 'page-simple.php'),
(1333, 295, '_menu_item_type', 'custom'),
(1334, 295, '_menu_item_menu_item_parent', '0'),
(1335, 295, '_menu_item_object_id', '295'),
(1336, 295, '_menu_item_object', 'custom'),
(1337, 295, '_menu_item_target', ''),
(1338, 295, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1339, 295, '_menu_item_xfn', ''),
(1340, 295, '_menu_item_url', 'http://www.youtube.com/user/teplitsast'),
(1342, 296, '_menu_item_type', 'taxonomy'),
(1343, 296, '_menu_item_menu_item_parent', '166'),
(1344, 296, '_menu_item_object_id', '3'),
(1345, 296, '_menu_item_object', 'category'),
(1346, 296, '_menu_item_target', ''),
(1347, 296, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1348, 296, '_menu_item_xfn', ''),
(1349, 296, '_menu_item_url', ''),
(1351, 297, '_menu_item_type', 'taxonomy'),
(1352, 297, '_menu_item_menu_item_parent', '166');
INSERT INTO `str_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1353, 297, '_menu_item_object_id', '1'),
(1354, 297, '_menu_item_object', 'category'),
(1355, 297, '_menu_item_target', ''),
(1356, 297, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1357, 297, '_menu_item_xfn', ''),
(1358, 297, '_menu_item_url', ''),
(1360, 109, 'support_block_text', 'Ваше пожертвование сделает жизнь детей с ОВЗ лучше и полнее, поможет им лучше адаптироваться в мире и и найти свое призвание.');

-- --------------------------------------------------------

--
-- Структура таблицы `str_posts`
--

DROP TABLE IF EXISTS `str_posts`;
CREATE TABLE `str_posts` (
`ID` bigint(20) unsigned NOT NULL,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=301 ;

--
-- Дамп данных таблицы `str_posts`
--

INSERT INTO `str_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2015-09-18 11:25:35', '2015-09-18 08:25:35', 'С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\r\n\r\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\r\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\r\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\r\n\r\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\r\n\r\n<ul>\r\n	<li>физическая активность,</li>\r\n\r\n	<li>контроль уровня холестерина,</li>\r\n\r\n	<li>контроль сахара в крови,</li>\r\n\r\n	<li>контроль кровяного давления,</li>\r\n\r\n	<li>здоровое питание,</li>\r\n\r\n	<li>поддержание здорового веса и</li>\r\n\r\n	<li>исключение курения.</li>\r\n</ul>\r\n\r\n\r\n\r\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\r\n<ul>\r\n\r\n	<li>недостаточное (от 0 до 4 баллов),</li>\r\n\r\n	<li>среднее (от 5 до 9 баллов) и</li>\r\n\r\n	<li>оптимальное (от 10 до 14 баллов).</li>\r\n</ul>\r\n\r\n\r\n\r\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\r\n\r\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь.  Проблема остается только в одном: заставить себя изменить образ жизни  лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!', 'Образ жизни поможет значительно снизить риск инсульта', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. ', 'publish', 'closed', 'closed', '', 'privet-mir', '', '', '2015-10-27 00:41:07', '2015-10-26 21:41:07', '', 0, 'http://starter.local/core/?p=1', 0, 'post', '', 1),
(2, 1, '2015-09-18 11:25:35', '2015-09-18 08:25:35', 'Фонд занимается организацией помощи детям с онкологическими и другими тяжёлыми заболеваниями головного мозга. \r\n\r\nОсновные направления работы Фонда: помощь в организации обследования и лечения детей, покупка медикаментов, организация реабилитационных программ, помощь профильным отделениям российских медицинских учреждений, повышение квалификации врачей и информационная работа с родителями, направленная на улучшение ранней диагностики тяжелых заболеваний головного мозга.\r\n\r\n<h4>Наша миссия — вовремя оказаться рядом и помочь, ведь тогда ребенка с заболеванием головного мозга можно спасти!</h4>\r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\n', 'О фонде', '', 'publish', 'closed', 'closed', '', 'about', '', '', '2015-11-13 21:24:42', '2015-11-13 18:24:42', '', 0, 'http://starter.local/core/?page_id=2', 0, 'page', '', 0),
(4, 1, '2015-09-18 15:59:09', '2015-09-18 12:59:09', '{"theme_css":"ui-lightness","theme_name":"UI Lightness","center_form":"","form_width":"100%","form_align":"left","direction":"ltr","fieldset":"0px","fieldset_color":"000000","fieldset_padding":"0 0 15px 0","fieldset_bg_color":"","title_size":"20px","title_color":"444444","form_desc_size":"14px","form_desc_color":"666666","font":"\\"Lucida Grande\\",\\"Lucida Sans Unicode\\",Tahoma,sans-serif","font_size":"14px","label_color":"444444","weight":"bold","position":"none","align":"left","width":"150px","required_color":"B94A48","required_weight":"bold","label_padding":"0 0 3px 0","description_font_size":"12px","description_color":"666666","description_weight":"normal","description_style":"normal","description_align":"left","field_font_size":"14px","field_height":"32px","line_height":"normal","field_width":"100%","auto_width":"","field_pad":"6px 10px","field_margin":"20px","text_color":"555555","border_color":"cccccc","field_border_width":"1px","field_border_style":"solid","bg_color":"ffffff","bg_color_active":"ffffff","border_color_active":"66afe9","text_color_error":"444444","bg_color_error":"ffffff","border_color_error":"B94A48","border_width_error":"1px","border_style_error":"solid","bg_color_disabled":"ffffff","border_color_disabled":"E5E5E5","text_color_disabled":"A1A1A1","radio_align":"block","check_align":"block","check_font_size":"13px","check_label_color":"444444","check_weight":"normal","section_font_size":"18px","section_color":"444444","section_weight":"bold","section_pad":"15px 0 3px 0","section_mar_top":"15px","section_mar_bottom":"12px","section_bg_color":"","section_border_color":"e8e8e8","section_border_width":"2px","section_border_style":"solid","section_border_loc":"-top","collapse_icon":"6","collapse_pos":"after","repeat_icon":"1","submit_style":"","submit_font_size":"14px","submit_width":"auto","submit_height":"auto","submit_bg_color":"ffffff","submit_border_color":"cccccc","submit_border_width":"1px","submit_text_color":"444444","submit_weight":"normal","submit_border_radius":"4px","submit_bg_img":"","submit_margin":"10px","submit_padding":"6px 11px","submit_shadow_color":"eeeeee","submit_hover_bg_color":"efefef","submit_hover_color":"444444","submit_hover_border_color":"cccccc","submit_active_bg_color":"efefef","submit_active_color":"444444","submit_active_border_color":"cccccc","border_radius":"4px","error_bg":"F2DEDE","error_border":"EBCCD1","error_text":"B94A48","error_font_size":"14px","success_bg_color":"DFF0D8","success_border_color":"D6E9C6","success_text_color":"468847","success_font_size":"14px","important_style":"","custom_css":""}', 'Formidable Style', '', 'publish', 'closed', 'closed', '', 'formidable-style', '', '', '2015-09-18 15:59:09', '2015-09-18 12:59:09', '', 0, 'http://starter.local/formidable-style/', 1, 'frm_styles', '', 0),
(5, 0, '2015-04-06 17:18:12', '2015-04-06 17:18:12', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'open', 'open', '', '1_email_1', '', '', '2015-10-27 00:36:31', '2015-10-26 21:36:31', '', 0, 'http://starter.local/1_email_1/', 1, 'frm_form_actions', '', 0),
(6, 1, '2015-09-18 15:59:10', '2015-09-18 12:59:10', 'Ура! Ваше пожертвование выполнено. Мы искренне благодарим вас за неравнодушие!', 'Ваше пожертвование выполнено!', '', 'publish', 'closed', 'closed', '', 'thank-you-for-your-donation', '', '', '2015-12-10 12:55:46', '2015-12-10 09:55:46', '', 0, 'http://starter.local/thank-you-for-your-donation/', 0, 'page', '', 0),
(7, 1, '2015-09-18 15:59:10', '2015-09-18 12:59:10', 'Извините, но по какой-то причине мы не смогли получить ваше пожертвование. Ваши деньги вернутся на ваш счёт. Пожалуйста, попробуйте ещё раз попозже!', 'Пожертвование не выполнено', '', 'publish', 'closed', 'closed', '', 'sorry-donation-failure', '', '', '2015-12-10 12:55:27', '2015-12-10 09:55:27', '', 0, 'http://starter.local/sorry-donation-failure/', 0, 'page', '', 0),
(8, 0, '2015-04-06 17:18:12', '2015-04-06 17:18:12', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'open', 'open', '', '2_email_1', '', '', '2015-10-27 00:36:32', '2015-10-26 21:36:32', '', 0, 'http://starter.local/frm_form_actions/2_email_1/', 2, 'frm_form_actions', '', 0),
(9, 0, '2015-04-06 17:18:12', '2015-04-06 17:18:12', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'open', 'open', '', '3_email_1', '', '', '2015-10-27 00:36:32', '2015-10-26 21:36:32', '', 0, 'http://starter.local/frm_form_actions/3_email_1/', 3, 'frm_form_actions', '', 0),
(10, 0, '2015-04-06 17:18:12', '2015-04-06 17:18:12', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'open', 'open', '', '4_email_1', '', '', '2015-10-27 00:36:32', '2015-10-26 21:36:32', '', 0, 'http://starter.local/frm_form_actions/4_email_1/', 4, 'frm_form_actions', '', 0),
(11, 0, '2015-04-06 17:18:12', '2015-04-06 17:18:12', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'open', 'open', '', '5_email_1', '', '', '2015-10-27 00:36:32', '2015-10-26 21:36:32', '', 0, 'http://starter.local/frm_form_actions/5_email_1/', 5, 'frm_form_actions', '', 0),
(12, 1, '2015-09-18 16:56:41', '2015-09-18 13:56:41', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\n\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\n\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\n\n<ul>\n	<li>\nфизическая активность,\nконтроль уровня холестерина,\nконтроль сахара в крови,\nконтроль кровяного давления,\nздоровое питание,\nподдержание здорового веса и\nисключение курения.\n\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\n\nнедостаточное (от 0 до 4 баллов),\nсреднее (от 5 до 9 баллов) и\nоптимальное (от 10 до 14 баллов).\n\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\n\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь.  Проблема остается только в одном: заставить себя изменить образ жизни  лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!\nВ следующих статьях я постараюсь рассказать подробнее про каждую из составляющих образа жизни, изменив которую вы сможете значительно увеличить ваши шансы избежать инсульта.\n<h6>Статья была впервые опубликована на сайте фонда <a href="http://www.orbifond.ru/insult/prophylaxis/privichki/obraz_zhizni_pomozhet_znachitelno_snizit_risk_insulta_/">ОРБИ</a>.</h6>', 'Привет, мир!', '', 'inherit', 'closed', 'closed', '', '1-autosave-v1', '', '', '2015-09-18 16:56:41', '2015-09-18 13:56:41', '', 1, 'http://starter.local/1-autosave-v1/', 0, 'revision', '', 0),
(13, 1, '2015-09-18 16:57:33', '2015-09-18 13:57:33', 'С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\r\n\r\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\r\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\r\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\r\n\r\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\r\n\r\n<ul>\r\n	<li>физическая активность,</li>\r\n\r\n	<li>контроль уровня холестерина,</li>\r\n\r\n	<li>контроль сахара в крови,</li>\r\n\r\n	<li>контроль кровяного давления,</li>\r\n\r\n	<li>здоровое питание,</li>\r\n\r\n	<li>поддержание здорового веса и</li>\r\n\r\n	<li>исключение курения.</li>\r\n</ul>\r\n\r\n\r\n\r\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\r\n<ul>\r\n\r\n	<li>недостаточное (от 0 до 4 баллов),</li>\r\n\r\n	<li>среднее (от 5 до 9 баллов) и</li>\r\n\r\n	<li>оптимальное (от 10 до 14 баллов).</li>\r\n</ul>\r\n\r\n\r\n\r\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\r\n\r\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь.  Проблема остается только в одном: заставить себя изменить образ жизни  лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!', 'Привет, мир!', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. ', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2015-09-18 16:57:33', '2015-09-18 13:57:33', '', 1, 'http://starter.local/1-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2015-09-18 17:06:29', '2015-09-18 14:06:29', 'По словам руководителя «Экклесии» Ивана Моисеева, задача ребят состояла в том, чтобы рассказать зрителю о светлом празднике Пасхи в молодёжном формате. Программа включала совершенно разные номера: рок-музыку, хоровое пение, вокал под гитару, пантомиму, танцы, великолепные стихи и светодиодное шоу.\r\n\r\nПеред началом концерта в фойе ЦМИ прошла выставка детских поделок «Воскресение Господне». Каждый имел возможность приобрести одну из них, тем самым внеся вклад в сбор средств на лечение Ани Хлыстовой – девочки с тяжёлым заболеванием.\r\n\r\n', 'Благотворительный концерт "Пасхальная Радость"', '3 апреля в Центре молодёжных инициатив состоялся ежегодный благотворительный концерт «Пасхальная радость», организованный активистами православного общества «Экклесия».', 'publish', 'closed', 'closed', '', 'blagotvoritelnyj-kontsert-pashalnaya-radost', '', '', '2015-10-27 00:40:33', '2015-10-26 21:40:33', '', 0, 'http://starter.local/?p=16', 0, 'post', '', 0),
(19, 1, '2015-09-18 17:06:29', '2015-09-18 14:06:29', 'По словам руководителя «Экклесии» Ивана Моисеева, задача ребят состояла в том, чтобы рассказать зрителю о светлом празднике Пасхи в молодёжном формате. Программа включала совершенно разные номера: рок-музыку, хоровое пение, вокал под гитару, пантомиму, танцы, великолепные стихи и светодиодное шоу.\r\n\r\nПеред началом концерта в фойе ЦМИ прошла выставка детских поделок «Воскресение Господне». Каждый имел возможность приобрести одну из них, тем самым внеся вклад в сбор средств на лечение Ани Хлыстовой – девочки с тяжёлым заболеванием.\r\n\r\n', 'Благотворительный концерт "Пасхальная Радость"', '3 апреля в Центре молодёжных инициатив состоялся ежегодный благотворительный концерт «Пасхальная радость», организованный активистами православного общества «Экклесия».', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2015-09-18 17:06:29', '2015-09-18 14:06:29', '', 16, 'http://starter.local/16-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2015-09-18 17:09:15', '2015-09-18 14:09:15', '[gallery link="file" size="thumbnail-landscape" ids="14,18,17"]\r\n\r\nИм, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта каждого благотворителя — остаться без работы', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'publish', 'closed', 'closed', '', 'mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty', '', '', '2015-10-27 00:40:44', '2015-10-26 21:40:44', '', 0, 'http://starter.local/?p=20', 0, 'post', '', 0),
(21, 1, '2015-09-18 17:09:15', '2015-09-18 14:09:15', 'Им, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта каждого благотворителя — остаться без работы', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2015-09-18 17:09:15', '2015-09-18 14:09:15', '', 20, 'http://starter.local/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2015-09-18 17:09:42', '2015-09-18 14:09:42', '[gallery link="file" size="thumbnail-landscape" ids="14,18,17"]\r\n\r\nИм, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта каждого благотворителя — остаться без работы', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2015-09-18 17:09:42', '2015-09-18 14:09:42', '', 20, 'http://starter.local/20-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2015-09-18 17:10:32', '2015-09-18 14:10:32', '[gallery link="file" size="thumbnail-landscape" ids="14,18,17"]\r\n\r\nИм, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта и благотворительность', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'publish', 'closed', 'closed', '', 'mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty-2', '', '', '2015-10-27 00:40:13', '2015-10-26 21:40:13', '', 0, 'http://starter.local/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty-2/', 0, 'post', '', 0),
(25, 1, '2015-09-18 17:10:45', '2015-09-18 14:10:45', 'По словам руководителя «Экклесии» Ивана Моисеева, задача ребят состояла в том, чтобы рассказать зрителю о светлом празднике Пасхи в молодёжном формате. Программа включала совершенно разные номера: рок-музыку, хоровое пение, вокал под гитару, пантомиму, танцы, великолепные стихи и светодиодное шоу.\r\n\r\nПеред началом концерта в фойе ЦМИ прошла выставка детских поделок «Воскресение Господне». Каждый имел возможность приобрести одну из них, тем самым внеся вклад в сбор средств на лечение Ани Хлыстовой – девочки с тяжёлым заболеванием.\r\n\r\n', 'Благотворительный концерт "Пасхальный сезон"', '3 апреля в Центре молодёжных инициатив состоялся ежегодный благотворительный концерт «Пасхальная радость», организованный активистами православного общества «Экклесия».', 'publish', 'closed', 'closed', '', 'blagotvoritelnyj-kontsert-pashalnaya-radost-2', '', '', '2015-10-27 00:39:59', '2015-10-26 21:39:59', '', 0, 'http://starter.local/blagotvoritelnyj-kontsert-pashalnaya-radost-2/', 0, 'post', '', 0),
(26, 1, '2015-09-18 17:11:11', '2015-09-18 14:11:11', 'С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\r\n\r\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\r\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\r\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\r\n\r\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\r\n\r\n<ul>\r\n	<li>физическая активность,</li>\r\n\r\n	<li>контроль уровня холестерина,</li>\r\n\r\n	<li>контроль сахара в крови,</li>\r\n\r\n	<li>контроль кровяного давления,</li>\r\n\r\n	<li>здоровое питание,</li>\r\n\r\n	<li>поддержание здорового веса и</li>\r\n\r\n	<li>исключение курения.</li>\r\n</ul>\r\n\r\n\r\n\r\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\r\n<ul>\r\n\r\n	<li>недостаточное (от 0 до 4 баллов),</li>\r\n\r\n	<li>среднее (от 5 до 9 баллов) и</li>\r\n\r\n	<li>оптимальное (от 10 до 14 баллов).</li>\r\n</ul>\r\n\r\n\r\n\r\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\r\n\r\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь.  Проблема остается только в одном: заставить себя изменить образ жизни  лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!', 'Образ жизни поможет значительно снизить риск инсульта', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. ', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2015-09-18 17:11:11', '2015-09-18 14:11:11', '', 1, 'http://starter.local/1-revision-v1/', 0, 'revision', '', 0);
INSERT INTO `str_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(28, 1, '2015-09-18 17:11:28', '2015-09-18 14:11:28', 'С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\r\n\r\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\r\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\r\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\r\n\r\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\r\n\r\n<ul>\r\n	<li>физическая активность,</li>\r\n\r\n	<li>контроль уровня холестерина,</li>\r\n\r\n	<li>контроль сахара в крови,</li>\r\n\r\n	<li>контроль кровяного давления,</li>\r\n\r\n	<li>здоровое питание,</li>\r\n\r\n	<li>поддержание здорового веса и</li>\r\n\r\n	<li>исключение курения.</li>\r\n</ul>\r\n\r\n\r\n\r\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\r\n<ul>\r\n\r\n	<li>недостаточное (от 0 до 4 баллов),</li>\r\n\r\n	<li>среднее (от 5 до 9 баллов) и</li>\r\n\r\n	<li>оптимальное (от 10 до 14 баллов).</li>\r\n</ul>\r\n\r\n\r\n\r\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\r\n\r\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь.  Проблема остается только в одном: заставить себя изменить образ жизни  лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!', 'Образ жизни поможет снизить риск болезни', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. ', 'publish', 'closed', 'closed', '', 'privet-mir-2', '', '', '2015-10-27 00:39:15', '2015-10-26 21:39:15', '', 0, 'http://starter.local/privet-mir-2/', 0, 'post', '', 0),
(29, 1, '2015-09-18 17:11:46', '2015-09-18 14:11:46', 'С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\r\n\r\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\r\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\r\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\r\n\r\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\r\n\r\n<ul>\r\n	<li>физическая активность,</li>\r\n\r\n	<li>контроль уровня холестерина,</li>\r\n\r\n	<li>контроль сахара в крови,</li>\r\n\r\n	<li>контроль кровяного давления,</li>\r\n\r\n	<li>здоровое питание,</li>\r\n\r\n	<li>поддержание здорового веса и</li>\r\n\r\n	<li>исключение курения.</li>\r\n</ul>\r\n\r\n\r\n\r\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\r\n<ul>\r\n\r\n	<li>недостаточное (от 0 до 4 баллов),</li>\r\n\r\n	<li>среднее (от 5 до 9 баллов) и</li>\r\n\r\n	<li>оптимальное (от 10 до 14 баллов).</li>\r\n</ul>\r\n\r\n\r\n\r\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\r\n\r\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь.  Проблема остается только в одном: заставить себя изменить образ жизни  лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!', 'Образ жизни поможет снизить риск болезни', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. ', 'inherit', 'closed', 'closed', '', '28-revision-v1', '', '', '2015-09-18 17:11:46', '2015-09-18 14:11:46', '', 28, 'http://starter.local/28-revision-v1/', 0, 'revision', '', 0),
(30, 1, '2015-09-18 17:11:59', '2015-09-18 14:11:59', 'По словам руководителя «Экклесии» Ивана Моисеева, задача ребят состояла в том, чтобы рассказать зрителю о светлом празднике Пасхи в молодёжном формате. Программа включала совершенно разные номера: рок-музыку, хоровое пение, вокал под гитару, пантомиму, танцы, великолепные стихи и светодиодное шоу.\r\n\r\nПеред началом концерта в фойе ЦМИ прошла выставка детских поделок «Воскресение Господне». Каждый имел возможность приобрести одну из них, тем самым внеся вклад в сбор средств на лечение Ани Хлыстовой – девочки с тяжёлым заболеванием.\r\n\r\n', 'Благотворительный концерт "Пасхальный сезон"', '3 апреля в Центре молодёжных инициатив состоялся ежегодный благотворительный концерт «Пасхальная радость», организованный активистами православного общества «Экклесия».', 'inherit', 'closed', 'closed', '', '25-revision-v1', '', '', '2015-09-18 17:11:59', '2015-09-18 14:11:59', '', 25, 'http://starter.local/25-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2015-09-18 17:12:46', '2015-09-18 14:12:46', '[gallery link="file" size="thumbnail-landscape" ids="14,18,17"]\r\n\r\nИм, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта и благотворительность', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2015-09-18 17:12:46', '2015-09-18 14:12:46', '', 23, 'http://starter.local/23-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:8:"taxonomy";s:8:"operator";s:2:"==";s:5:"value";s:6:"auctor";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Настройки автора', 'nastrojki-avtora', 'publish', 'closed', 'closed', '', 'group_5596e61e0f971', '', '', '2015-09-18 17:15:26', '2015-09-18 14:15:26', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=32', 0, 'acf-field-group', '', 0),
(33, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Фото', 'auctor_photo', 'publish', 'closed', 'closed', '', 'field_5596e682e842f', '', '', '2015-09-18 17:15:06', '2015-09-18 14:15:06', '', 32, 'http://starter.local/?post_type=acf-field&p=33', 0, 'acf-field', '', 0),
(34, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение заставки', 'header_img', 'publish', 'closed', 'closed', '', 'field_559c5762b30f8', '', '', '2015-09-18 17:15:06', '2015-09-18 14:15:06', '', 32, 'http://starter.local/?post_type=acf-field&p=34', 1, 'acf-field', '', 0),
(35, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'Профиль на Facebook', 'auctor_facebook', 'publish', 'closed', 'closed', '', 'field_55a81f6a64493', '', '', '2015-09-18 17:15:06', '2015-09-18 14:15:06', '', 32, 'http://starter.local/?post_type=acf-field&p=35', 2, 'acf-field', '', 0),
(36, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Настройки записи', 'nastrojki-zapisi', 'publish', 'closed', 'closed', '', 'group_5596bb39d7507', '', '', '2015-10-01 09:47:52', '2015-10-01 06:47:52', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=36', 0, 'acf-field-group', '', 0),
(37, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:239:"Укажите изображение для верхней заставки на странице записи. При не заполненном поле будет использовано изображение по умолчанию";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение для заставки', 'header_img', 'publish', 'closed', 'closed', '', 'field_52f65021169ed', '', '', '2015-09-18 17:15:06', '2015-09-18 14:15:06', '', 36, 'http://starter.local/?post_type=acf-field&p=37', 0, 'acf-field', '', 0),
(38, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:7:{s:4:"type";s:10:"true_false";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"message";s:74:"Показывать миниатюру на странице записи";s:13:"default_value";i:1;}', 'Показывать миниатюру на странице', 'show_thumb', 'publish', 'closed', 'closed', '', 'field_559706ff40f79', '', '', '2015-09-18 17:15:55', '2015-09-18 14:15:55', '', 36, 'http://starter.local/?post_type=acf-field&#038;p=38', 1, 'acf-field', '', 0),
(40, 1, '2015-09-18 17:15:06', '2015-09-18 14:15:06', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:8:"taxonomy";s:8:"operator";s:2:"==";s:5:"value";s:8:"category";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Настройки рубрики', 'nastrojki-rubriki', 'publish', 'closed', 'closed', '', 'group_559a5ecd59220', '', '', '2015-09-18 17:16:29', '2015-09-18 14:16:29', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=40', 0, 'acf-field-group', '', 0),
(42, 1, '2015-09-18 17:15:07', '2015-09-18 14:15:07', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение заставки', 'header_img', 'publish', 'closed', 'closed', '', 'field_559c56f54f99f', '', '', '2015-09-18 17:16:29', '2015-09-18 14:16:29', '', 40, 'http://starter.local/?post_type=acf-field&#038;p=42', 0, 'acf-field', '', 0),
(43, 1, '2015-09-18 17:15:07', '2015-09-18 14:15:07', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"event";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Настройки события', 'nastrojki-sobytiya', 'publish', 'closed', 'closed', '', 'group_5596f9bb26898', '', '', '2015-09-18 17:19:00', '2015-09-18 14:19:00', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=43', 0, 'acf-field-group', '', 0),
(44, 1, '2015-09-18 17:15:07', '2015-09-18 14:15:07', 'a:8:{s:4:"type";s:11:"date_picker";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:14:"display_format";s:5:"d.m.Y";s:13:"return_format";s:5:"Y-m-d";s:9:"first_day";i:1;}', 'Дата события', 'event_date', 'publish', 'closed', 'closed', '', 'field_5596f9ea66508', '', '', '2015-09-18 17:15:07', '2015-09-18 14:15:07', '', 43, 'http://starter.local/?post_type=acf-field&p=44', 0, 'acf-field', '', 0),
(45, 1, '2015-09-18 17:15:07', '2015-09-18 14:15:07', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:53:"Укажите время начала события";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Начало', 'event_time', 'publish', 'closed', 'closed', '', 'field_5596fa33c4d66', '', '', '2015-09-18 17:15:07', '2015-09-18 14:15:07', '', 43, 'http://starter.local/?post_type=acf-field&p=45', 1, 'acf-field', '', 0),
(46, 1, '2015-09-18 17:15:07', '2015-09-18 14:15:07', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:137:"Укажите город и название места проведения, например "Москва, Парк Горького"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Место проведения события', 'event_location', 'publish', 'closed', 'closed', '', 'field_5596fb25da192', '', '', '2015-09-18 17:17:16', '2015-09-18 14:17:16', '', 43, 'http://starter.local/?post_type=acf-field&#038;p=46', 2, 'acf-field', '', 0),
(47, 1, '2015-09-18 17:15:07', '2015-09-18 14:15:07', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:112:"Укажите адрес места проведения (город уже указывать не нужно)";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Адрес', 'event_address', 'publish', 'closed', 'closed', '', 'field_5596fb62201b7', '', '', '2015-09-18 17:17:16', '2015-09-18 14:17:16', '', 43, 'http://starter.local/?post_type=acf-field&#038;p=47', 3, 'acf-field', '', 0),
(49, 1, '2015-09-18 17:19:00', '2015-09-18 14:19:00', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:239:"Укажите изображение для верхней заставки на странице записи. При не заполненном поле будет использовано изображение по умолчанию";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение для заставки', 'header_img', 'publish', 'closed', 'closed', '', 'field_55fc1d210d9bb', '', '', '2015-09-18 17:19:00', '2015-09-18 14:19:00', '', 43, 'http://starter.local/?post_type=acf-field&p=49', 4, 'acf-field', '', 0),
(50, 1, '2015-09-18 17:19:49', '2015-09-18 14:19:49', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"project";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Настройки программы', 'nastrojki-programmy', 'publish', 'closed', 'closed', '', 'group_55fc1d63b8919', '', '', '2015-09-18 17:19:56', '2015-09-18 14:19:56', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=50', 0, 'acf-field-group', '', 0),
(51, 1, '2015-09-18 17:19:49', '2015-09-18 14:19:49', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:239:"Укажите изображение для верхней заставки на странице записи. При не заполненном поле будет использовано изображение по умолчанию";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение для заставки', 'header_img', 'publish', 'closed', 'closed', '', 'field_55fc1d6c8ed96', '', '', '2015-09-18 17:19:49', '2015-09-18 14:19:49', '', 50, 'http://starter.local/?post_type=acf-field&p=51', 0, 'acf-field', '', 0),
(53, 1, '2015-09-18 17:20:50', '2015-09-18 14:20:50', 'С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\r\n\r\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\r\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\r\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\r\n\r\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\r\n\r\n<ul>\r\n	<li>физическая активность,</li>\r\n\r\n	<li>контроль уровня холестерина,</li>\r\n\r\n	<li>контроль сахара в крови,</li>\r\n\r\n	<li>контроль кровяного давления,</li>\r\n\r\n	<li>здоровое питание,</li>\r\n\r\n	<li>поддержание здорового веса и</li>\r\n\r\n	<li>исключение курения.</li>\r\n</ul>\r\n\r\n\r\n\r\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\r\n<ul>\r\n\r\n	<li>недостаточное (от 0 до 4 баллов),</li>\r\n\r\n	<li>среднее (от 5 до 9 баллов) и</li>\r\n\r\n	<li>оптимальное (от 10 до 14 баллов).</li>\r\n</ul>\r\n\r\n\r\n\r\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\r\n\r\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь.  Проблема остается только в одном: заставить себя изменить образ жизни  лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!', 'Образ жизни поможет значительно снизить риск инсульта', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. ', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2015-09-18 17:20:50', '2015-09-18 14:20:50', '', 1, 'http://starter.local/1-revision-v1/', 0, 'revision', '', 0),
(54, 1, '2015-09-18 17:21:13', '2015-09-18 14:21:13', '[gallery link="file" size="thumbnail-landscape" ids="14,18,17"]\r\n\r\nИм, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта и благотворительность', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'inherit', 'closed', 'closed', '', '23-revision-v1', '', '', '2015-09-18 17:21:13', '2015-09-18 14:21:13', '', 23, 'http://starter.local/23-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2015-09-18 17:25:03', '2015-09-18 14:25:03', '1 ноября Марфо-Мариинская обитель милосердия совместно с православной службой помощи «Милосердие» проводит благотворительный концерт в честь 150-летия со дня рождения основательницы обители – великой княгини Елизаветы Федоровны Романовой. Большой симфонический оркестр им. П.И. Чайковского и его руководитель Владимир Федосеев уже много лет являются друзьями службы «Милосердие» и Марфо-Мариинской обители – сердца отечественной благотворительности.\r\n\r\nВ рамках концерта, в котором кроме оркестра примут участие Академический хор имени А. Д. Кожевникова и солистка Московской филармонии Катя Сканави, прозвучат произведения П. Чайковского, М. Глинки, В. Калинникова, Ф. Шуберта, Р. Шумана, С. Рахманинова и Д. Шостаковича.\r\n\r\nОтрывки из воспоминаний Великой княгини Елизаветы и ее переписки с супругом, Великим князем Сергеем Александровичем, будут читать артистка театра «Мастерская П. Фоменко» Полина Кутепова и артист Московского академического театра им. Вл. Маяковского Михаил Филиппов.', 'Благотворительный концерт "Надежда впереди"', 'Приобрести билеты на концерт «Великая княгиня Елисавета. 150 лет со дня рождения», который пройдет в Светлановском зале Московского Дома музыки, можно уже сейчас.', 'publish', 'closed', 'closed', '', 'blagotvoritelnyj-kontsert-nadezhda-vperedi', '', '', '2015-11-13 22:53:09', '2015-11-13 19:53:09', '', 0, 'http://starter.local/?post_type=event&#038;p=55', 0, 'event', '', 0),
(56, 1, '2015-09-18 17:28:23', '2015-09-18 14:28:23', 'Чаще всего по инициативе активных сотрудников, при поступлении запросов с просьбой о помощи со стороны разных социальных групп.\r\n\r\nПри этом при реализации и спонсировании различных благотворительных акций бизнес сталкивается с разными видами сложностей и рисков:\r\n<ul>\r\n\r\n    	<li>Сложность получения отчетности по итогам (содержательной, финансовой) – к отчетности о расходовании средств в благотворительности всегда крайне повышенный интерес;</li>\r\n\r\n    	<li>Сложность оценки эффективности и полезности для жертвователей – могут последовать негативные оценки со стороны НКО (акция плохая, не помогает, а только вредит;</li>\r\n\r\n    	<li>Существенные бюджеты и растущие запросы и бюджеты от акции к акции – зачастую запрашиваемые суммы бывают очень значительными;</li>\r\n\r\n   	<li> Сложность освящения благотворительной деятельности компании в СМИ;</li>\r\n\r\n    	<li>Сложности в решении внутренних корпоративных задач.</li>\r\n</ul>\r\n\r\nУчастники семинара получат советы и рекомендации из первых рук – экспертами выступят спикеры-практики:\r\n\r\n<strong>Александр Гезалов</strong>, международный эксперт по социальному сиротству, более 15 лет эффективно занимающийся данной деятельностью. Помощник депутата ГД РФ Баталиной О. Ю., тренер-эксперт Общественной палаты России, член совета Министерства образования России по вопросам детей и сиротства. Выпускник советского детского дома. Имеет государственные, ведомственные и церковные награды. 	\r\n\r\n<strong>Ольга Будина</strong>, актриса кино, лауреат Государственной премии России, Президент и учредитель Благотворительного фонда духовного и физического развития подрастающего поколения Ольги Будиной «Обереги Будущее»\r\n\r\n<strong>Матвей Масальцев</strong>, главный редактор электронного журнала «Филантроп» — ведущего издания в России, посвященного благотворительности. 	\r\n\r\n<strong>Кирилл Гопиус</strong>, коуч, исследователь, ведущий в России эксперт по Сторителлингу. Автор специальных программ по Сторителлингу. Руководитель в центр прикладных знаний «Prime Life «Funky» Education».', 'Семинар «Корпоративная благотворительность: как сделать ее максимально эффективной?»', 'Сегодня бизнес является одним из основных доноров в некоммерческом секторе при решении социальных проблем. Зачастую благотворительная деятельность в компаниях возникает достаточно стихийно. ', 'publish', 'closed', 'closed', '', 'seminar-korporativnaya-blagotvoritelnost-kak-sdelat-ee-maksimalno-effektivnoj', '', '', '2015-11-13 22:56:34', '2015-11-13 19:56:34', '', 0, 'http://starter.local/?post_type=event&#038;p=56', 0, 'event', '', 0),
(57, 1, '2015-09-18 17:34:03', '2015-09-18 14:34:03', 'Чаще всего по инициативе активных сотрудников, при поступлении запросов с просьбой о помощи со стороны разных социальных групп.\r\n\r\nПри этом при реализации и спонсировании различных благотворительных акций бизнес сталкивается с разными видами сложностей и рисков:\r\n<ul>\r\n\r\n    	<li>Сложность получения отчетности по итогам (содержательной, финансовой) – к отчетности о расходовании средств в благотворительности всегда крайне повышенный интерес;</li>\r\n\r\n    	<li>Сложность оценки эффективности и полезности для жертвователей – могут последовать негативные оценки со стороны НКО (акция плохая, не помогает, а только вредит;</li>\r\n\r\n    	<li>Существенные бюджеты и растущие запросы и бюджеты от акции к акции – зачастую запрашиваемые суммы бывают очень значительными;</li>\r\n\r\n   	<li> Сложность освящения благотворительной деятельности компании в СМИ;</li>\r\n\r\n    	<li>Сложности в решении внутренних корпоративных задач.</li>\r\n</ul>\r\n\r\nУчастники семинара получат советы и рекомендации из первых рук – экспертами выступят спикеры-практики:\r\n\r\n<strong>Александр Гезалов</strong>, международный эксперт по социальному сиротству, более 15 лет эффективно занимающийся данной деятельностью. Помощник депутата ГД РФ Баталиной О. Ю., тренер-эксперт Общественной палаты России, член совета Министерства образования России по вопросам детей и сиротства. Выпускник советского детского дома. Имеет государственные, ведомственные и церковные награды. 	\r\n\r\n<strong>Ольга Будина</strong>, актриса кино, лауреат Государственной премии России, Президент и учредитель Благотворительного фонда духовного и физического развития подрастающего поколения Ольги Будиной «Обереги Будущее»\r\n\r\n<strong>Матвей Масальцев</strong>, главный редактор электронного журнала «Филантроп» — ведущего издания в России, посвященного благотворительности. 	\r\n\r\n<strong>Кирилл Гопиус</strong>, коуч, исследователь, ведущий в России эксперт по Сторителлингу. Автор специальных программ по Сторителлингу. Руководитель в центр прикладных знаний «Prime Life «Funky» Education».', 'Семинар "Корпоративная благотворительность: как повысить эффективность?"', 'Сегодня бизнес является одним из основных доноров в некоммерческом секторе при решении социальных проблем. Зачастую благотворительная деятельность в компаниях возникает достаточно стихийно. ', 'publish', 'closed', 'closed', '', 'seminar-korporativnaya-blagotvoritelnost-kak-sdelat-ee-maksimalno-effektivnoj-2', '', '', '2015-11-13 22:56:07', '2015-11-13 19:56:07', '', 0, 'http://starter.local/event/seminar-korporativnaya-blagotvoritelnost-kak-sdelat-ee-maksimalno-effektivnoj-2/', 0, 'event', '', 0),
(58, 1, '2015-09-18 17:34:08', '2015-09-18 14:34:08', '1 ноября Марфо-Мариинская обитель милосердия совместно с православной службой помощи «Милосердие» проводит благотворительный концерт в честь 150-летия со дня рождения основательницы обители – великой княгини Елизаветы Федоровны Романовой. Большой симфонический оркестр им. П.И. Чайковского и его руководитель Владимир Федосеев уже много лет являются друзьями службы «Милосердие» и Марфо-Мариинской обители – сердца отечественной благотворительности.\r\n\r\nВ рамках концерта, в котором кроме оркестра примут участие Академический хор имени А. Д. Кожевникова и солистка Московской филармонии Катя Сканави, прозвучат произведения П. Чайковского, М. Глинки, В. Калинникова, Ф. Шуберта, Р. Шумана, С. Рахманинова и Д. Шостаковича.\r\n\r\nОтрывки из воспоминаний Великой княгини Елизаветы и ее переписки с супругом, Великим князем Сергеем Александровичем, будут читать артистка театра «Мастерская П. Фоменко» Полина Кутепова и артист Московского академического театра им. Вл. Маяковского Михаил Филиппов.', 'Благотворительный концерт "Надежда навсегда"', 'Приобрести билеты на концерт «Великая княгиня Елисавета. 150 лет со дня рождения», который пройдет в Светлановском зале Московского Дома музыки, можно уже сейчас.', 'publish', 'closed', 'closed', '', 'blagotvoritelnyj-kontsert-nadezhda-vperedi-2', '', '', '2015-11-13 22:51:39', '2015-11-13 19:51:39', '', 0, 'http://starter.local/event/blagotvoritelnyj-kontsert-nadezhda-vperedi-2/', 0, 'event', '', 0),
(59, 1, '2015-09-18 17:36:59', '2015-09-18 14:36:59', 'Агентство социальной информации – ведущая экспертная организация российского некоммерческого сектора и профессиональное информационное агентство, специализирующееся на освещении гражданских инициатив.', 'Агентство социальной информации', 'http://www.asi.org.ru', 'publish', 'closed', 'closed', '', 'bbdo-group', '', '', '2015-11-15 01:59:04', '2015-11-14 22:59:04', '', 0, 'http://starter.local/?post_type=org&#038;p=59', 0, 'org', '', 0);
INSERT INTO `str_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(61, 1, '2015-09-18 17:39:01', '2015-09-18 14:39:01', '«Теплица социальных технологий» – это общественный образовательный проект, направленный на развитие сотрудничества между некоммерческим сектором и IT-специалистами.', 'Теплица социальных технологий', 'https://te-st.ru/', 'publish', 'closed', 'closed', '', 'fitoguru', '', '', '2015-11-15 01:59:01', '2015-11-14 22:59:01', '', 0, 'http://starter.local/?post_type=org&#038;p=61', 0, 'org', '', 0),
(63, 1, '2015-09-18 17:39:38', '2015-09-18 14:39:38', 'Система для краудфандинга, фандрайзинга и сбора пожертвований на сайте', 'Онлайн-Лейка', 'https://leyka.te-st.ru/', 'publish', 'closed', 'closed', '', 'run-magazine', '', '', '2015-11-15 01:58:36', '2015-11-14 22:58:36', '', 0, 'http://starter.local/?post_type=org&#038;p=63', 0, 'org', '', 0),
(66, 1, '2015-09-18 17:40:03', '2015-09-18 14:40:03', 'Пасека — добровольная система поиска, отбора и рекомендации лучших веб-студий и креативных агентств, заинтересованных в качественной работе с некоммерческими организациями.', 'Пасека', 'http://paseka.te-st.ru/', 'publish', 'closed', 'closed', '', 'live-up', '', '', '2015-11-15 01:58:25', '2015-11-14 22:58:25', '', 0, 'http://starter.local/?post_type=org&#038;p=66', 0, 'org', '', 0),
(67, 1, '2015-10-18 17:40:23', '2015-10-18 14:40:23', 'сервис для создания сайтов, логотипов, буклетов и текстов для некоммерческих организаций', 'it-волонтер', 'https://itv.te-st.ru/', 'publish', 'closed', 'closed', '', 'live-up-2', '', '', '2015-11-15 01:58:09', '2015-11-14 22:58:09', '', 0, 'http://starter.local/org/live-up-2/', 0, 'org', '', 0),
(68, 1, '2015-09-18 17:40:27', '2015-09-18 14:40:27', 'Система тестов, специально разработанных для сайта НКО, позволит определить удобство вашего сайта для пользователя и простоту текстов для понимания', 'Аудит сайта НКО', 'https://audit.te-st.ru/', 'publish', 'closed', 'closed', '', 'run-magazine-2', '', '', '2015-11-15 09:42:32', '2015-11-15 06:42:32', '', 0, 'http://starter.local/org/run-magazine-2/', 0, 'org', '', 0),
(69, 1, '2015-09-18 17:46:37', '2015-09-18 14:46:37', 'Фонд занимается организацией помощи детям с онкологическими и другими тяжёлыми заболеваниями головного мозга. Основные направления работы Фонда: помощь в организации обследования и лечения детей, покупка медикаментов, организация реабилитационных программ, помощь профильным отделениям российских медицинских учреждений, повышение квалификации врачей и информационная работа с родителями, направленная на улучшение ранней диагностики тяжелых заболеваний головного мозга.\n\nНаша миссия — вовремя оказаться рядом и помочь, ведь тогда ребенка с заболеванием головного мозга можно спасти!\n\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \n\n\n', 'О фонде', '', 'inherit', 'closed', 'closed', '', '2-autosave-v1', '', '', '2015-09-18 17:46:37', '2015-09-18 14:46:37', '', 2, 'http://starter.local/2-autosave-v1/', 0, 'revision', '', 0),
(70, 1, '2015-09-18 17:46:46', '2015-09-18 14:46:46', 'Фонд занимается организацией помощи детям с онкологическими и другими тяжёлыми заболеваниями головного мозга. Основные направления работы Фонда: помощь в организации обследования и лечения детей, покупка медикаментов, организация реабилитационных программ, помощь профильным отделениям российских медицинских учреждений, повышение квалификации врачей и информационная работа с родителями, направленная на улучшение ранней диагностики тяжелых заболеваний головного мозга.\r\n\r\n<h4>Наша миссия — вовремя оказаться рядом и помочь, ведь тогда ребенка с заболеванием головного мозга можно спасти!</h4>\r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\n\r\n', 'О фонде', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2015-09-18 17:46:46', '2015-09-18 14:46:46', '', 2, 'http://starter.local/2-revision-v1/', 0, 'revision', '', 0),
(71, 1, '2015-09-18 17:47:17', '2015-09-18 14:47:17', 'Фонд занимается организацией помощи детям с онкологическими и другими тяжёлыми заболеваниями головного мозга. Основные направления работы Фонда: помощь в организации обследования и лечения детей, покупка медикаментов, организация реабилитационных программ, помощь профильным отделениям российских медицинских учреждений, повышение квалификации врачей и информационная работа с родителями, направленная на улучшение ранней диагностики тяжелых заболеваний головного мозга.\r\n\r\n<h4>Наша миссия — вовремя оказаться рядом и помочь, ведь тогда ребенка с заболеванием головного мозга можно спасти!</h4>\r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\n<h5>Команда фонда</h5>\r\n\r\nпридумать простой и эффективный способ отображения команды\r\n\r\n', 'О фонде', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2015-09-18 17:47:17', '2015-09-18 14:47:17', '', 2, 'http://starter.local/2-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2015-09-18 17:47:38', '2015-09-18 14:47:38', 'Наш фонд был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью. ', 'Главная', '', 'publish', 'closed', 'closed', '', 'glavnaya', '', '', '2015-11-15 13:54:21', '2015-11-15 10:54:21', '', 0, 'http://starter.local/?page_id=72', 0, 'page', '', 0),
(74, 1, '2015-09-18 17:47:52', '2015-09-18 14:47:52', '', 'Новости', '', 'publish', 'closed', 'closed', '', 'novosti', '', '', '2015-09-18 17:47:52', '2015-09-18 14:47:52', '', 0, 'http://starter.local/?page_id=74', 0, 'page', '', 0),
(75, 1, '2015-09-18 17:47:52', '2015-09-18 14:47:52', '', 'Новости', '', 'inherit', 'closed', 'closed', '', '74-revision-v1', '', '', '2015-09-18 17:47:52', '2015-09-18 14:47:52', '', 74, 'http://starter.local/74-revision-v1/', 0, 'revision', '', 0),
(76, 1, '2015-09-18 17:50:27', '2015-09-18 14:50:27', 'На этой странице представлены отчеты и официальные документы фонда, вы можете ознакомиться с ними, скачав нужный файл.\r\n\r\n<h5>2014 год. Годовой отчет</h5>\r\n\r\nНебольшое текстовое описание может содержать некоторые основные моменты и достижения, подробнее рассмотренные в документе.\r\n<a href="//giger.local/wp-content/uploads/2015/09/doc-1.pdf" target="_blank">Скачать файл (.pdf)</a> \r\n\r\n<h5>2013 год. Годовой отчет</h5>\r\n\r\nНебольшое текстовое описание может содержать некоторые основные моменты и достижения, подробнее рассмотренные в документе.\r\n<a href="//giger.local/wp-content/uploads/2015/09/doc-1.pdf" target="_blank">Скачать файл (.pdf)</a> \r\n\r\n<h5>2012 год. Годовой отчет</h5>\r\n\r\nНебольшое текстовое описание может содержать некоторые основные моменты и достижения, подробнее рассмотренные в документе.\r\n<a href="//giger.local/wp-content/uploads/2015/09/doc-1.pdf" target="_blank">Скачать файл (.pdf)</a> ', 'Отчеты', '', 'publish', 'closed', 'closed', '', 'otchety', '', '', '2015-10-01 09:46:13', '2015-10-01 06:46:13', '', 2, 'http://starter.local/?page_id=76', 0, 'page', '', 0),
(77, 1, '2015-09-18 17:49:46', '2015-09-18 14:49:46', '', 'doc-1', '', 'inherit', 'closed', 'closed', '', 'doc-1', '', '', '2015-09-18 17:49:46', '2015-09-18 14:49:46', '', 76, '//starter.local/wp-content/uploads/2015/09/doc-1.pdf', 0, 'attachment', 'application/pdf', 0),
(78, 1, '2015-09-18 17:50:27', '2015-09-18 14:50:27', 'На этой странице представлены отчеты и официальные документы фонда, вы можете ознакомиться с ними, скачав нужный файл.\r\n\r\n<h5>2014 год. Годовой отчет</h5>\r\n\r\nНебольшое текстовое описание может содержать некоторые основные моменты и достижения, подробнее рассмотренные в документе.\r\n<a href="//giger.local/wp-content/uploads/2015/09/doc-1.pdf" target="_blank">Скачать файл (.pdf)</a> \r\n\r\n<h5>2013 год. Годовой отчет</h5>\r\n\r\nНебольшое текстовое описание может содержать некоторые основные моменты и достижения, подробнее рассмотренные в документе.\r\n<a href="//giger.local/wp-content/uploads/2015/09/doc-1.pdf" target="_blank">Скачать файл (.pdf)</a> \r\n\r\n<h5>2012 год. Годовой отчет</h5>\r\n\r\nНебольшое текстовое описание может содержать некоторые основные моменты и достижения, подробнее рассмотренные в документе.\r\n<a href="//giger.local/wp-content/uploads/2015/09/doc-1.pdf" target="_blank">Скачать файл (.pdf)</a> ', 'Отчеты', '', 'inherit', 'closed', 'closed', '', '76-revision-v1', '', '', '2015-09-18 17:50:27', '2015-09-18 14:50:27', '', 76, 'http://starter.local/76-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2015-09-18 17:52:35', '2015-09-18 14:52:35', '<strong>8 800 123-45-45</strong> \r\nбесплатный для всех регионов России\r\n\r\n<strong>+7 (985) 123-33-33</strong>\r\nдля партнеров\r\n\r\nЮридический адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nПочтовый адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nE-mail: info@domain.ru\r\n\r\n[pw_map address="Россия, Москва, Лубянский пр-д, 19, стр. 1" width="100%" height="330px"]\r\n\r\n[ninja_forms id=1]', 'Контакты', '', 'publish', 'closed', 'closed', '', 'contacts', '', '', '2015-12-11 00:08:00', '2015-12-10 21:08:00', '', 2, 'http://starter.local/?page_id=79', 0, 'page', '', 0),
(83, 1, '2015-09-18 17:54:08', '2015-09-18 14:54:08', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'closed', 'closed', '', '6_email_83', '', '', '2015-09-18 17:56:49', '2015-09-18 14:56:49', '', 0, 'http://starter.local/frm_form_actions/6_email_/', 6, 'frm_form_actions', '', 0),
(85, 1, '2015-09-18 17:58:59', '2015-09-18 14:58:59', ' ', '', '', 'publish', 'closed', 'closed', '', '85', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://starter.local/?p=85', 7, 'nav_menu_item', '', 0),
(86, 1, '2015-09-18 17:58:59', '2015-09-18 14:58:59', ' ', '', '', 'publish', 'closed', 'closed', '', '86', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://starter.local/?p=86', 3, 'nav_menu_item', '', 0),
(88, 1, '2015-09-18 17:58:59', '2015-09-18 14:58:59', '', 'Проекты', '', 'publish', 'closed', 'closed', '', 'proekty', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://starter.local/?p=88', 2, 'nav_menu_item', '', 0),
(90, 1, '2015-09-18 17:59:57', '2015-09-18 14:59:57', '', 'Календарь', '', 'publish', 'closed', 'closed', '', 'calendar', '', '', '2015-09-18 18:01:20', '2015-09-18 15:01:20', '', 0, 'http://starter.local/?page_id=90', 0, 'page', '', 0),
(91, 1, '2015-09-18 17:59:57', '2015-09-18 14:59:57', '', 'Календарь', '', 'inherit', 'closed', 'closed', '', '90-revision-v1', '', '', '2015-09-18 17:59:57', '2015-09-18 14:59:57', '', 90, 'http://starter.local/90-revision-v1/', 0, 'revision', '', 0),
(92, 1, '2015-09-18 18:01:59', '2015-09-18 15:01:59', '[tst_sitemap]', 'Карта сайта', '', 'publish', 'closed', 'closed', '', 'sitemap', '', '', '2015-09-18 18:02:12', '2015-09-18 15:02:12', '', 0, 'http://starter.local/?page_id=92', 0, 'page', '', 0),
(93, 1, '2015-09-18 18:01:59', '2015-09-18 15:01:59', '[tst_sitemap]', 'Карта сайта', '', 'inherit', 'closed', 'closed', '', '92-revision-v1', '', '', '2015-09-18 18:01:59', '2015-09-18 15:01:59', '', 92, 'http://starter.local/92-revision-v1/', 0, 'revision', '', 0),
(94, 1, '2015-09-18 18:02:32', '2015-09-18 15:02:32', ' ', '', '', 'publish', 'closed', 'closed', '', '94', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://starter.local/?p=94', 4, 'nav_menu_item', '', 0),
(95, 1, '2015-09-18 18:05:02', '2015-09-18 15:05:02', ' ', '', '', 'publish', 'closed', 'closed', '', '95', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://starter.local/?p=95', 8, 'nav_menu_item', '', 0),
(96, 1, '2015-09-18 18:05:02', '2015-09-18 15:05:02', ' ', '', '', 'publish', 'closed', 'closed', '', '96', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 2, 'http://starter.local/?p=96', 5, 'nav_menu_item', '', 0),
(97, 1, '2015-09-18 18:05:02', '2015-09-18 15:05:02', ' ', '', '', 'publish', 'closed', 'closed', '', '97', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://starter.local/?p=97', 7, 'nav_menu_item', '', 0),
(98, 1, '2015-09-18 18:05:02', '2015-09-18 15:05:02', ' ', '', '', 'publish', 'closed', 'closed', '', '98', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://starter.local/?p=98', 1, 'nav_menu_item', '', 0),
(99, 1, '2015-09-18 18:05:02', '2015-09-18 15:05:02', '', 'Проекты', '', 'publish', 'closed', 'closed', '', 'proekty-2', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://starter.local/?p=99', 6, 'nav_menu_item', '', 0),
(100, 1, '2015-08-18 18:54:35', '2015-08-18 15:54:35', '1 ноября Марфо-Мариинская обитель милосердия совместно с православной службой помощи «Милосердие» проводит благотворительный концерт в честь 150-летия со дня рождения основательницы обители – великой княгини Елизаветы Федоровны Романовой. Большой симфонический оркестр им. П.И. Чайковского и его руководитель Владимир Федосеев уже много лет являются друзьями службы «Милосердие» и Марфо-Мариинской обители – сердца отечественной благотворительности.\r\n\r\nВ рамках концерта, в котором кроме оркестра примут участие Академический хор имени А. Д. Кожевникова и солистка Московской филармонии Катя Сканави, прозвучат произведения П. Чайковского, М. Глинки, В. Калинникова, Ф. Шуберта, Р. Шумана, С. Рахманинова и Д. Шостаковича.\r\n\r\nОтрывки из воспоминаний Великой княгини Елизаветы и ее переписки с супругом, Великим князем Сергеем Александровичем, будут читать артистка театра «Мастерская П. Фоменко» Полина Кутепова и артист Московского академического театра им. Вл. Маяковского Михаил Филиппов.', 'Благотворительный концерт "Надежда детям"', 'Приобрести билеты на концерт «Великая княгиня Елисавета. 150 лет со дня рождения», который пройдет в Светлановском зале Московского Дома музыки, можно уже сейчас.', 'publish', 'closed', 'closed', '', 'blagotvoritelnyj-kontsert-nadezhda-vperedi-3', '', '', '2015-11-13 22:57:00', '2015-11-13 19:57:00', '', 0, 'http://starter.local/event/blagotvoritelnyj-kontsert-nadezhda-vperedi-3/', 0, 'event', '', 0),
(101, 1, '2015-09-18 18:58:55', '2015-09-18 15:58:55', ' ', '', '', 'publish', 'closed', 'closed', '', '101', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 2, 'http://starter.local/?p=101', 3, 'nav_menu_item', '', 0),
(108, 1, '2015-09-18 20:26:59', '2015-09-18 17:26:59', 'Социальная адаптация детей через игру, подготавливающую к будущей трудовой деятельности.\r\n\r\n<h4>Что мы делаем</h4>\r\n\r\nМы обучаем детей из региональных детских домов делать несложные сувениры (открытки, ароматное мыло, свечи, мягкие игрушки, роспись кружек, декупаж фоторамок), которые затем реализуются за пожертвования компаниям и на различных мероприятиях. За каждый качественно сделанный сувенир ребёнку начисляется фиксированная сумма баллов (1 балл=1 рубль), размер которой зависит от сложности изготовления продукта.\r\n\r\nКоординаторы проекта «Социальные метры» регулярно организуют поездки ребят в торговые центры, где дети имеют возможность приобрести то, что им хочется в соответствии с накопленной суммой. Активисты проекта имеют возможность потратить в торговых центрах до 15 тысяч рублей.\r\nПочему мы это делаем\r\n\r\nВ детских домах все бытовые вопросы за детей решают воспитатели, государство, благотворители. В результате, начиная самостоятельную жизнь в 16 лет (большинство идут в колледж после 9-го класса), ребята оказываются не готовы к самым обычным бытовым, финансовым и прочим проблемам. Навык обращения с деньгами является большой проблемой. Ребята привыкают получать всё просто так, бесплатно: питание, одежда, развлекательные мероприятия и бесконечные подарки от спонсоров.\r\n\r\nВ одном подмосковном детском доме как-то на Новый год ребята получили каждый по 35 подарков от разных спонсоров. В итоге у многих появляется иждивенская позиция «мне все должны», нет ценности вещам, которые доставались всю жизнь даром.\r\n\r\n<h4>Сколько «зарабатывают» дети</h4>\r\n\r\nЗа каждым товаром закреплено неизменное количество баллов (1 балл = 1 рубль), начисляемый ребёнку.\r\n\r\nНакопления ребёнка соизмеримы его труду, они зависят от сложности изготовления сувенира. Например, вощинная свеча делается с лёгкостью за 1-3 минуты и стоит 10 баллов, а на изготовление мыла уходит больше времени. Изготовление открыток требует выдумки и аккуратности, они стоят от 20 до 40 баллов.\r\n\r\nОдна из базовых целей проекта – помочь понять детям, что деньги приходят не просто так, а вследствие прилежного регулярного труда, и необоснованно увеличивая процент, получаемый ребёнком, мы опять-таки будем воспитывать в нём потребительское отношение к жизни. Потому что в будущем, за простой физической труд им не будет никто платить больших денег.\r\n\r\nТакже пожертвования идут на «жизнедеятельность» проекта: административные, офисные, транспортные расходы. Наш проект независим, у нас нет спонсоров, дающих денег просто так.\r\n\r\nАктивисты зарабатывают очень хорошие баллы и покупают в магазинах товаров на суммы до 15 тыс.рублей.\r\n\r\n<h4>Как дети тратят «заработанное»</h4>\r\n\r\nПериодически дети в сопровождении волонтёров выезжают за покупками в торговый центр. Каждый ребёнок покупает товаров на ту сумму, какое количество баллов он заработал. Большой ассортимент товаров, возможность посоветоваться со старшим и пример окружающих позволяют не только потратить деньги, но и приобрести позитивный опыт выбора товара. А старшие ребята уже научились выбирать покупки через интернет.\r\n\r\nОдна из первых поездок ярко продемонстрировала, что такое социальная адаптация. Многие из ребят впервые видели эскалатор, а кто-то даже лифт. Никто не знал своих размеров одежды и обуви, не разбирался в маркировках размеров на одежде. Младшие плохо соотносили товар и цену, не могли «прочесть» цену, хотя знали цифры. Но коронный вопрос задала восьмилетняя девочка, причём вопрос прозвучал уже после покупок: «А что здесь можно купить бесплатно?».\r\n\r\n\r\n\r\n', 'Социальные метры', '', 'publish', 'closed', 'closed', '', 'sotsialnye-metry', '', '', '2015-10-27 00:41:49', '2015-10-26 21:41:49', '', 0, 'http://starter.local/?post_type=project&#038;p=108', 0, 'project', '', 0),
(109, 1, '2015-09-18 20:28:13', '2015-09-18 17:28:13', 'Цель проекта дать подросткам представление о разных профессиях и возможных местах работы.\r\n\r\n<strong>Проблема:</strong> наши подопечные живут в небольших поселках, большую часть своей жизни проводят в стенах учреждения, изолированного от внешнего мира, и это сильно ограничивает представление ребят о сфере профессиональной деятельности. Перед их глазами единственный пример профессии – педагог. Даже такие слова, как «администратор», «курьер», «официант» – это что-то очень далекое и не очень понятное.\r\n\r\n<strong>Решение:</strong> Подростки из детских домов приезжают на неделю в Москву, живут в хостеле, каждый день посещают пару предприятий (завод, типография, гостиница и т.д.) чтобы посмотреть «изнутри» на ту или иную профессию. Они видят реальных людей в реальном мире за реальными - самыми разнообразными - делами. Непосредственно на рабочем месте сотрудники компаний объясняют и показывают ребятам, чем именно они занимаются, рассказывают о тонкостях своей профессии и необходимом образовании.\r\n\r\n[gallery link="file" size="thumbnail-landscape" ids="195,194,17"]\r\n\r\n<strong>Мы стараемся охватить именно те специальности, которые будут доступны нашим детям в будущем: автомеханик, повар, парикмахер, секретарь-машинист, кассир, швея, мастер маникюра и т.д.</strong>\r\n\r\nТакже во время проживания в Москве происходит социальная адаптация. Многие дети впервые в жизни имеют доступ к холодильнику на кухне и возможность самостоятельно выбрать и приготовить себе еду. Всех ребят очень радует передвижение на метро и наземном транспорте – это для них редкое событие, ведь чаще всего спонсоры организуют доставку автобусом. ', 'Я выбираю профессию', '', 'publish', 'closed', 'closed', '', 'ya-vybirayu-professiyu', '', '', '2015-12-10 14:35:15', '2015-12-10 11:35:15', '', 0, 'http://starter.local/?post_type=project&#038;p=109', 0, 'project', '', 0),
(110, 1, '2015-09-18 20:29:01', '2015-09-18 17:29:01', '<strong>Проблема:</strong> сегодня люди с ограниченными возможностями здоровья и семьи, воспитывающие ребенка с инвалидностью, - одна из самых социально незащищенных групп населения. Именно им трудно (а зачастую невозможно) найти стабильную работу и поддерживать достойный уровень жизни, растить и лечить своих детей.\r\n\r\n<strong>Решение:</strong> Оказание адресной материальной, социальной, информационной и иной помощи людям с ограниченными возможностями здоровья и семьям, воспитывающим детей с инвалидностью.\r\n\r\nМы материально поддерживаем две семьи, в которых растут дети с ограниченными возможностями. Именно их мамы шьют для наших ярмарок чудесные мягкие игрушки!', 'Соучастие', '<strong>Цель программы:</strong> улучшение качества жизни социально-незащищенных категорий населения.', 'publish', 'closed', 'closed', '', 'souchastie', '', '', '2015-11-13 23:35:34', '2015-11-13 20:35:34', '', 0, 'http://starter.local/?post_type=project&#038;p=110', 0, 'project', '', 0),
(112, 1, '2015-09-18 20:31:04', '2015-09-18 17:31:04', ' ', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 2, 'http://starter.local/?p=112', 9, 'nav_menu_item', '', 0),
(113, 1, '2015-09-18 20:35:20', '2015-09-18 17:35:20', 'Фонд занимается организацией помощи детям с онкологическими и другими тяжёлыми заболеваниями головного мозга. Основные направления работы Фонда: помощь в организации обследования и лечения детей, покупка медикаментов, организация реабилитационных программ, помощь профильным отделениям российских медицинских учреждений, повышение квалификации врачей и информационная работа с родителями, направленная на улучшение ранней диагностики тяжелых заболеваний головного мозга.\r\n\r\n<h4>Наша миссия — вовремя оказаться рядом и помочь, ведь тогда ребенка с заболеванием головного мозга можно спасти!</h4>\r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\n<h4>Команда фонда</h4>\r\n\r\nпридумать простой и эффективный способ отображения команды\r\n\r\n', 'О фонде', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2015-09-18 20:35:20', '2015-09-18 17:35:20', '', 2, 'http://starter.local/2-revision-v1/', 0, 'revision', '', 0),
(121, 1, '2015-09-19 00:38:00', '2015-09-18 21:38:00', 'Мы поддерживаем тех, кто нуждается в помощи.', 'Помочь нам', 'Нам помочь можно прямо здесь и сейчас - правда же, это здорово!', 'publish', 'closed', 'closed', '', 'help-us', '', '', '2015-09-19 00:38:27', '2015-09-18 21:38:27', '', 0, 'http://starter.local/?post_type=leyka_campaign&#038;p=121', 0, 'leyka_campaign', '', 0),
(122, 1, '2015-09-19 00:57:33', '2015-09-18 21:57:33', ' ', '', '', 'publish', 'closed', 'closed', '', '122', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://starter.local/?p=122', 6, 'nav_menu_item', '', 0),
(123, 1, '2015-09-19 06:51:22', '2015-09-19 03:51:22', '', 'Помочь нам', '', 'funded', 'closed', 'closed', '', 'pomoch-nam', '', '', '2015-09-19 09:52:53', '2015-09-19 06:52:53', '', 0, 'http://starter.local/donation/pomoch-nam/', 0, 'leyka_donation', '', 0),
(124, 1, '2015-09-19 06:51:55', '2015-09-19 03:51:55', '', 'Помочь нам', '', 'funded', 'closed', 'closed', '', 'pomoch-nam-2', '', '', '2015-09-19 09:52:33', '2015-09-19 06:52:33', '', 0, 'http://starter.local/donation/pomoch-nam-2/', 0, 'leyka_donation', '', 0),
(125, 1, '2015-09-19 12:16:25', '2015-09-19 09:16:25', '[gallery link="file" size="thumbnail-landscape" ids="14,18,17"]\r\n\r\nИм, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта каждого благотворителя — остаться без работы', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2015-09-19 12:16:25', '2015-09-19 09:16:25', '', 20, 'http://starter.local/20-revision-v1/', 0, 'revision', '', 0),
(126, 1, '2015-09-19 12:16:40', '2015-09-19 09:16:40', '[gallery link="file" size="thumbnail-landscape" ids="14,18,17"]\r\n\r\nИм, в отличие от детей и стариков, помогать не принято.\r\n\r\nПять лет назад в России появился фонд «Живой», который занимается помощью взрослым. «Медуза» поговорила с директором фонда Ольгой Пинскер о том, как в кризис собирать деньги для тех, кому и без всякого кризиса сложно найти поддержку.\r\n\r\n<strong>— Как вам в голову пришла эта идея — сделать фонд для помощи взрослым?</strong>\r\n\r\n— Учредители «Живого» — это руководители фондов, которые помогают детям. Дело в том, что когда человек достигает 18-летнего возраста, он выходит из поля зрения детских фондов: они уже не имеют права ему помогать. И многие люди оказываются в безвоздушном пространстве — им некуда идти. Сначала приходилось собирать деньги частным образом, но это неправильно, помогать нужно системно. И мы сделали фонд «Живой».\r\n\r\nУ нас, например, есть девочка — ей в подростковом возрасте неудачно удалили гланды. Открылось кровотечение, ее с трудом реанимировали, но головной мозг пострадал, и из прекрасной цветущей девочки-подростка она превратилась в беспомощную больную. Всеобщими усилиями детских фондов ее постепенно реабилитируют, она начала понемногу стоять на ногах, разговаривать. Но скоро ей стукнет 18 — и все, детские фонды ей помогать не смогут. И тогда потребуется помощь таких фондов, как наш.\r\n\r\nЧитайте полную версию интервью на сайте <a href="https://meduza.io/feature/2015/03/18/mechta-kazhdogo-blagotvoritelya-ostatsya-bez-raboty" target="_blank">Meduza</a>', 'Мечта каждого благотворителя — остаться без работы', 'Интервью директора фонда «Живой» Ольги Пинскер опубликовано на портале Meduza.  Российские благотворители говорят, что самая проблемная категория нуждающихся — люди от 18 до 60 лет. ', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2015-09-19 12:16:40', '2015-09-19 09:16:40', '', 20, 'http://starter.local/20-revision-v1/', 0, 'revision', '', 0),
(127, 1, '2015-09-19 13:27:25', '2015-09-19 10:27:25', 'Фонд занимается организацией помощи детям с онкологическими и другими тяжёлыми заболеваниями головного мозга. \r\n\r\nОсновные направления работы Фонда: помощь в организации обследования и лечения детей, покупка медикаментов, организация реабилитационных программ, помощь профильным отделениям российских медицинских учреждений, повышение квалификации врачей и информационная работа с родителями, направленная на улучшение ранней диагностики тяжелых заболеваний головного мозга.\r\n\r\n<h4>Наша миссия — вовремя оказаться рядом и помочь, ведь тогда ребенка с заболеванием головного мозга можно спасти!</h4>\r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\n<h4>Команда фонда</h4>\r\n\r\nпридумать простой и эффективный способ отображения команды\r\n\r\n', 'О фонде', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2015-09-19 13:27:25', '2015-09-19 10:27:25', '', 2, 'http://starter.local/2-revision-v1/', 0, 'revision', '', 0),
(128, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:7:{s:8:"location";a:1:{i:0;a:2:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}i:1;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:14:"page-cards.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Встроенные карточки', 'vstroennye-kartochki', 'publish', 'closed', 'closed', '', 'group_55e854b3c5454', '', '', '2015-11-07 23:35:01', '2015-11-07 20:35:01', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=128', 0, 'acf-field-group', '', 0),
(129, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"block";s:12:"button_label";s:16:"Добавить";}', 'Категории объектов', 'object_categories', 'publish', 'closed', 'closed', '', 'field_55e854b3d0036', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 128, 'http://starter.local/?post_type=acf-field&p=129', 0, 'acf-field', '', 0),
(130, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Название категории объектов', 'category_name', 'publish', 'closed', 'closed', '', 'field_55e865096b2a5', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 129, 'http://starter.local/?post_type=acf-field&p=130', 0, 'acf-field', '', 0),
(131, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:79:"Вступительный текст описывающий категорию";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";i:4;s:9:"new_lines";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Описание', 'category_text', 'publish', 'closed', 'closed', '', 'field_560283262b1cc', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 129, 'http://starter.local/?post_type=acf-field&p=131', 1, 'acf-field', '', 0),
(132, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:16:"Добавить";}', 'Объект', 'objects', 'publish', 'closed', 'closed', '', 'field_55e863f76b2a0', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 129, 'http://starter.local/?post_type=acf-field&p=132', 2, 'acf-field', '', 0),
(133, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Имя', 'name', 'publish', 'closed', 'closed', '', 'field_55e864586b2a1', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 132, 'http://starter.local/?post_type=acf-field&p=133', 0, 'acf-field', '', 0),
(134, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:12:{s:4:"type";s:8:"textarea";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:9:"maxlength";s:0:"";s:4:"rows";s:0:"";s:9:"new_lines";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Описание', 'descr', 'publish', 'closed', 'closed', '', 'field_55e864b86b2a3', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 132, 'http://starter.local/?post_type=acf-field&p=134', 1, 'acf-field', '', 0);
INSERT INTO `str_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(135, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Фото/лого', 'pic', 'publish', 'closed', 'closed', '', 'field_55e864c76b2a4', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 132, 'http://starter.local/?post_type=acf-field&p=135', 2, 'acf-field', '', 0),
(136, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:7:{s:4:"type";s:3:"url";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";}', 'URL', 'url', 'publish', 'closed', 'closed', '', 'field_55e9995b22484', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 132, 'http://starter.local/?post_type=acf-field&p=136', 3, 'acf-field', '', 0),
(139, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:7:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"72";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Настройки главной', 'nastrojki-glavnoj', 'publish', 'closed', 'closed', '', 'group_55a43831d9912', '', '', '2015-10-01 09:47:09', '2015-10-01 06:47:09', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=139', 0, 'acf-field-group', '', 0),
(140, 1, '2015-10-01 09:43:26', '2015-10-01 06:43:26', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение для заставки', 'header_img', 'publish', 'closed', 'closed', '', 'field_5602f579fa897', '', '', '2015-10-01 09:43:26', '2015-10-01 06:43:26', '', 139, 'http://starter.local/?post_type=acf-field&p=140', 0, 'acf-field', '', 0),
(141, 1, '2015-10-01 09:43:27', '2015-10-01 06:43:27', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Фоновое изображение для блока партнеров', 'partners_bg', 'publish', 'closed', 'closed', '', 'field_55a56a875c831', '', '', '2015-10-01 09:43:27', '2015-10-01 06:43:27', '', 139, 'http://starter.local/?post_type=acf-field&p=141', 1, 'acf-field', '', 0),
(142, 1, '2015-10-01 09:43:27', '2015-10-01 06:43:27', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:1:{i:0;s:3:"org";}s:8:"taxonomy";a:0:{}s:7:"filters";a:1:{i:0;s:6:"search";}s:8:"elements";a:1:{i:0;s:14:"featured_image";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:6:"object";}', 'Партнеры', 'home_partners', 'publish', 'closed', 'closed', '', 'field_55a56ac7e1529', '', '', '2015-10-01 09:43:27', '2015-10-01 06:43:27', '', 139, 'http://starter.local/?post_type=acf-field&p=142', 2, 'acf-field', '', 0),
(143, 1, '2015-10-01 09:43:27', '2015-10-01 06:43:27', 'a:7:{s:8:"location";a:1:{i:0;a:2:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}i:1;a:3:{s:5:"param";s:4:"page";s:8:"operator";s:2:"!=";s:5:"value";s:2:"72";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Настройки страницы', 'nastrojki-stranitsy', 'publish', 'closed', 'closed', '', 'group_55a0ae6b2f1b8', '', '', '2015-11-07 23:38:04', '2015-11-07 20:38:04', '', 0, 'http://starter.local/?post_type=acf-field-group&#038;p=143', 0, 'acf-field-group', '', 0),
(144, 1, '2015-10-01 09:43:27', '2015-10-01 06:43:27', 'a:15:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:2:"id";s:12:"preview_size";s:14:"post-thumbnail";s:7:"library";s:3:"all";s:9:"min_width";s:0:"";s:10:"min_height";s:0:"";s:8:"min_size";s:0:"";s:9:"max_width";s:0:"";s:10:"max_height";s:0:"";s:8:"max_size";s:0:"";s:10:"mime_types";s:0:"";}', 'Изображение для заставки', 'header_img', 'publish', 'closed', 'closed', '', 'field_55a0ae7eee28b', '', '', '2015-10-01 09:43:27', '2015-10-01 06:43:27', '', 143, 'http://starter.local/?post_type=acf-field&p=144', 0, 'acf-field', '', 0),
(149, 1, '2015-10-01 09:55:16', '2015-10-01 06:55:16', 'Это пример страницы посвященной деятельности фонда по направлениям и результатам.\r\n\r\nМы помогаем детям. Миссия нашего Фонда – сохранять, возвращать, создавать опору детям, находящимся в трудной жизненной ситуации, для обретения ими душевной гармонии, веры в жизнь и в себя.\r\n\r\nБлаготворительный детский фонд «Виктория» создан в 2004 году Николаем Александровичем Цветковым для помощи детям, оставшимся без попечения родителей и детям, находящимся в трудной жизненной ситуации. Нашими подопечными стали мальчики и девочки, живущие в детских домах и школах-интернатах в 46 регионах страны. Ближе познакомившись с жизнью воспитанников детских домов, мы поняли, что часто дети изымаются из родной семьи органами опеки, потому что родителям не была вовремя оказана нужная помощь.\r\n\r\nПриоритетным направлением деятельности Благотворительного фонда стала профилактика социального сиротства. В настоящее время Фонд реализует собственные программы по следующим ключевым направлениям:\r\n\r\n<strong>Профилактика социального сиротства и комплексная психолого-педагогическая помощь кризисным семьям</strong>.  Для нас очень важно, чтобы в России не увеличивалось число сирот при живых родителях. Наша задача – сохранить, спасти семью, не допустить, чтобы ребёнок лишился своих биологических родителей. Тесно взаимодействуя с органами опеки и попечительства, мы выявляем семьи, находящиеся в группе риска и оказавшиеся в кризисной ситуации и работаем с ними.  Мы создаем механизмы, позволяющие поддержать семью на самой ранней стадии «непогоды в доме»,  работаем с детьми, оказываем помощь и поддержку их родителям.\r\n\r\n<strong>Семейное устройство детей-сирот и поддержка приемных семей.</strong> Мы хотим, чтобы каждый ребёнок жил и воспитывался в любящей семье. Наша задача – помочь обрести детям-сиротам новую семью, а маме и папе подготовиться к ответственному шагу и новому этапу их жизни. Созданная Фондом Школа приемных семей Арбат занимается подготовкой потенциальных приёмных родителей и психолого-педагогическим сопровождением новых приёмных семей. Отдельным  направлением нашей работы является подготовка специалистов для работы с приемными семьями, семьями группы риска и семьями, находящимися в кризисной ситуации.\r\n', 'Что мы делаем', '', 'publish', 'closed', 'closed', '', 'activity', '', '', '2015-11-14 21:17:54', '2015-11-14 18:17:54', '', 0, 'http://starter.local/?page_id=149', 0, 'page', '', 0),
(150, 1, '2015-10-01 09:55:16', '2015-10-01 06:55:16', 'Это пример страницы посвященной деятельности фонда по направлениям и результатам.\r\n\r\nМы помогаем детям. Миссия нашего Фонда – сохранять, возвращать, создавать опору детям, находящимся в трудной жизненной ситуации, для обретения ими душевной гармонии, веры в жизнь и в себя.\r\n\r\nБлаготворительный детский фонд «Виктория» создан в 2004 году Николаем Александровичем Цветковым для помощи детям, оставшимся без попечения родителей и детям, находящимся в трудной жизненной ситуации. Нашими подопечными стали мальчики и девочки, живущие в детских домах и школах-интернатах в 46 регионах страны. Ближе познакомившись с жизнью воспитанников детских домов, мы поняли, что часто дети изымаются из родной семьи органами опеки, потому что родителям не была вовремя оказана нужная помощь.\r\n\r\nПриоритетным направлением деятельности Благотворительного фонда стала профилактика социального сиротства. В настоящее время Фонд реализует собственные программы по следующим ключевым направлениям:\r\n\r\n<strong>Профилактика социального сиротства и комплексная психолого-педагогическая помощь кризисным семьям</strong>.  Для нас очень важно, чтобы в России не увеличивалось число сирот при живых родителях. Наша задача – сохранить, спасти семью, не допустить, чтобы ребёнок лишился своих биологических родителей. Тесно взаимодействуя с органами опеки и попечительства, мы выявляем семьи, находящиеся в группе риска и оказавшиеся в кризисной ситуации и работаем с ними.  Мы создаем механизмы, позволяющие поддержать семью на самой ранней стадии «непогоды в доме»,  работаем с детьми, оказываем помощь и поддержку их родителям.\r\n\r\n<strong>Семейное устройство детей-сирот и поддержка приемных семей.</strong> Мы хотим, чтобы каждый ребёнок жил и воспитывался в любящей семье. Наша задача – помочь обрести детям-сиротам новую семью, а маме и папе подготовиться к ответственному шагу и новому этапу их жизни. Созданная Фондом Школа приемных семей Арбат занимается подготовкой потенциальных приёмных родителей и психолого-педагогическим сопровождением новых приёмных семей. Отдельным  направлением нашей работы является подготовка специалистов для работы с приемными семьями, семьями группы риска и семьями, находящимися в кризисной ситуации.\r\n', 'Что мы делаем', '', 'inherit', 'closed', 'closed', '', '149-revision-v1', '', '', '2015-10-01 09:55:16', '2015-10-01 06:55:16', '', 149, 'http://starter.local/149-revision-v1/', 0, 'revision', '', 0),
(151, 1, '2015-10-01 09:55:45', '2015-10-01 06:55:45', 'Это пример страницы посвященной деятельности фонда по направлениям и результатам.\r\n\r\nМы помогаем детям. Миссия нашего Фонда – сохранять, возвращать, создавать опору детям, находящимся в трудной жизненной ситуации, для обретения ими душевной гармонии, веры в жизнь и в себя.\r\n\r\nБлаготворительный детский фонд «Виктория» создан в 2004 году Николаем Александровичем Цветковым для помощи детям, оставшимся без попечения родителей и детям, находящимся в трудной жизненной ситуации. Нашими подопечными стали мальчики и девочки, живущие в детских домах и школах-интернатах в 46 регионах страны. Ближе познакомившись с жизнью воспитанников детских домов, мы поняли, что часто дети изымаются из родной семьи органами опеки, потому что родителям не была вовремя оказана нужная помощь.\r\n\r\nПриоритетным направлением деятельности Благотворительного фонда стала профилактика социального сиротства. В настоящее время Фонд реализует собственные программы по следующим ключевым направлениям:\r\n\r\n<strong>Профилактика социального сиротства и комплексная психолого-педагогическая помощь кризисным семьям</strong>.  Для нас очень важно, чтобы в России не увеличивалось число сирот при живых родителях. Наша задача – сохранить, спасти семью, не допустить, чтобы ребёнок лишился своих биологических родителей. Тесно взаимодействуя с органами опеки и попечительства, мы выявляем семьи, находящиеся в группе риска и оказавшиеся в кризисной ситуации и работаем с ними.  Мы создаем механизмы, позволяющие поддержать семью на самой ранней стадии «непогоды в доме»,  работаем с детьми, оказываем помощь и поддержку их родителям.\r\n\r\n<strong>Семейное устройство детей-сирот и поддержка приемных семей.</strong> Мы хотим, чтобы каждый ребёнок жил и воспитывался в любящей семье. Наша задача – помочь обрести детям-сиротам новую семью, а маме и папе подготовиться к ответственному шагу и новому этапу их жизни. Созданная Фондом Школа приемных семей Арбат занимается подготовкой потенциальных приёмных родителей и психолого-педагогическим сопровождением новых приёмных семей. Отдельным  направлением нашей работы является подготовка специалистов для работы с приемными семьями, семьями группы риска и семьями, находящимися в кризисной ситуации.\r\n', 'Что мы делаем', '', 'inherit', 'closed', 'closed', '', '149-revision-v1', '', '', '2015-10-01 09:55:45', '2015-10-01 06:55:45', '', 149, 'http://starter.local/149-revision-v1/', 0, 'revision', '', 0),
(153, 1, '2015-10-01 09:56:13', '2015-10-01 06:56:13', ' ', '', '', 'publish', 'closed', 'closed', '', '153', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 2, 'http://starter.local/?p=153', 11, 'nav_menu_item', '', 0),
(154, 1, '2015-10-01 09:56:30', '2015-10-01 06:56:30', ' ', '', '', 'publish', 'closed', 'closed', '', '154', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://starter.local/?p=154', 1, 'nav_menu_item', '', 0),
(155, 1, '2015-10-01 10:07:30', '2015-10-01 07:07:30', '', 'testface2', '', 'inherit', 'closed', 'closed', '', 'testface2', '', '', '2015-10-01 10:07:30', '2015-10-01 07:07:30', '', 2, '//starter.local/wp-content/uploads/2015/10/testface2.jpg', 0, 'attachment', 'image/jpeg', 0),
(159, 1, '2015-10-01 10:16:05', '2015-10-01 07:16:05', ' ', '', '', 'publish', 'closed', 'closed', '', '159', '', '', '2015-11-15 10:27:44', '2015-11-15 07:27:44', '', 0, 'http://starter.local/?p=159', 1, 'nav_menu_item', '', 0),
(161, 1, '2015-10-01 10:16:05', '2015-10-01 07:16:05', ' ', '', '', 'publish', 'closed', 'closed', '', '161', '', '', '2015-11-15 10:27:45', '2015-11-15 07:27:45', '', 2, 'http://starter.local/?p=161', 5, 'nav_menu_item', '', 0),
(162, 1, '2015-10-01 10:16:05', '2015-10-01 07:16:05', ' ', '', '', 'publish', 'closed', 'closed', '', '162', '', '', '2015-11-15 10:27:44', '2015-11-15 07:27:44', '', 2, 'http://starter.local/?p=162', 3, 'nav_menu_item', '', 0),
(164, 1, '2015-10-01 10:18:20', '2015-10-01 07:18:20', 'Фонд занимается организацией помощи детям с онкологическими и другими тяжёлыми заболеваниями головного мозга. \r\n\r\nОсновные направления работы Фонда: помощь в организации обследования и лечения детей, покупка медикаментов, организация реабилитационных программ, помощь профильным отделениям российских медицинских учреждений, повышение квалификации врачей и информационная работа с родителями, направленная на улучшение ранней диагностики тяжелых заболеваний головного мозга.\r\n\r\n<h4>Наша миссия — вовремя оказаться рядом и помочь, ведь тогда ребенка с заболеванием головного мозга можно спасти!</h4>\r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\nОпухоли головного мозга составляют примерно 96% всех опухолей центральной нервной системы у детей, и занимают второе место после лейкозов по частоте онкологических заболеваний у детей.  Каждый год около 850 детей в России сталкиваются с диагнозом опухоль головного мозга.  Болезнь редко удается победить в первый год, поэтому количество нуждающихся в помощи с каждым годом растет. \r\n\r\n', 'О фонде', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2015-10-01 10:18:20', '2015-10-01 07:18:20', '', 2, 'http://starter.local/2-revision-v1/', 0, 'revision', '', 0),
(165, 1, '2015-10-01 10:21:29', '2015-10-01 07:21:29', ' ', '', '', 'publish', 'closed', 'closed', '', '165', '', '', '2015-12-10 14:17:05', '2015-12-10 11:17:05', '', 0, 'http://starter.local/?p=165', 1, 'nav_menu_item', '', 0),
(166, 1, '2015-10-01 10:21:29', '2015-10-01 07:21:29', ' ', '', '', 'publish', 'closed', 'closed', '', '166', '', '', '2015-12-10 14:17:05', '2015-12-10 11:17:05', '', 0, 'http://starter.local/?p=166', 3, 'nav_menu_item', '', 0),
(167, 1, '2015-10-01 10:21:29', '2015-10-01 07:21:29', ' ', '', '', 'publish', 'closed', 'closed', '', '167', '', '', '2015-12-10 14:17:05', '2015-12-10 11:17:05', '', 0, 'http://starter.local/?p=167', 6, 'nav_menu_item', '', 0),
(168, 1, '2015-10-01 10:21:29', '2015-10-01 07:21:29', '', 'Проекты', '', 'publish', 'closed', 'closed', '', 'programmy', '', '', '2015-12-10 14:17:05', '2015-12-10 11:17:05', '', 0, 'http://starter.local/?p=168', 2, 'nav_menu_item', '', 0),
(182, 1, '2015-10-13 20:21:21', '2015-10-13 17:21:21', '', 'FB', '', 'publish', 'closed', 'closed', '', 'fb', '', '', '2015-12-10 13:48:35', '2015-12-10 10:48:35', '', 0, 'http://giger.local/?p=182', 1, 'nav_menu_item', '', 0),
(183, 1, '2015-10-13 20:21:21', '2015-10-13 17:21:21', '', 'VK', '', 'publish', 'closed', 'closed', '', 'vk', '', '', '2015-12-10 13:48:36', '2015-12-10 10:48:36', '', 0, 'http://giger.local/?p=183', 2, 'nav_menu_item', '', 0),
(191, 1, '2015-10-15 21:21:42', '2015-10-15 18:21:42', '', 'green_o', '', 'inherit', 'closed', 'closed', '', 'green_o', '', '', '2015-10-15 21:21:42', '2015-10-15 18:21:42', '', 2, '//giger.local/wp-content/uploads/2015/10/green_o.gif', 0, 'attachment', 'image/gif', 0),
(196, 1, '2015-10-15 22:00:34', '2015-10-15 19:00:34', 'По словам руководителя «Экклесии» Ивана Моисеева, задача ребят состояла в том, чтобы рассказать зрителю о светлом празднике Пасхи в молодёжном формате. Программа включала совершенно разные номера: рок-музыку, хоровое пение, вокал под гитару, пантомиму, танцы, великолепные стихи и светодиодное шоу.\r\n\r\nПеред началом концерта в фойе ЦМИ прошла выставка детских поделок «Воскресение Господне». Каждый имел возможность приобрести одну из них, тем самым внеся вклад в сбор средств на лечение Ани Хлыстовой – девочки с тяжёлым заболеванием.\r\n\r\n', 'Благотворительный концерт "Пасхальная Радость"', '3 апреля в Центре молодёжных инициатив состоялся ежегодный благотворительный концерт «Пасхальная радость», организованный активистами православного общества «Экклесия».', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2015-10-15 22:00:34', '2015-10-15 19:00:34', '', 16, 'http://giger.local/16-revision-v1/', 0, 'revision', '', 0),
(206, 1, '2015-10-18 23:21:46', '2015-10-18 20:21:46', '[gallery link="file" size="thumbnail-landscape" ids="194,195,17"]\r\n\r\n<strong>Наш фонд</strong> был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью. \r\n\r\n<b>Фонд</b> является экспериментальной площадкой, где происходит устойчивое развитие и неустойчивое продвижение.', 'Главная', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-10-18 23:21:46', '2015-10-18 20:21:46', '', 72, 'http://giger.local/72-revision-v1/', 0, 'revision', '', 0),
(208, 1, '2015-10-27 00:38:47', '2015-10-26 21:38:47', '', 'greena_k', '', 'inherit', 'closed', 'closed', '', 'greena_k', '', '', '2015-10-27 00:38:47', '2015-10-26 21:38:47', '', 28, '//giger.local/wp-content/uploads/2015/09/greena_k.jpg', 0, 'attachment', 'image/jpeg', 0),
(209, 1, '2015-10-27 00:38:49', '2015-10-26 21:38:49', '', 'springf_b', '', 'inherit', 'closed', 'closed', '', 'springf_b', '', '', '2015-10-27 00:38:49', '2015-10-26 21:38:49', '', 28, '//giger.local/wp-content/uploads/2015/09/springf_b.jpg', 0, 'attachment', 'image/jpeg', 0),
(210, 1, '2015-10-27 00:38:52', '2015-10-26 21:38:52', '', 'Thistle_b', '', 'inherit', 'closed', 'closed', '', 'thistle_b', '', '', '2015-10-27 00:38:52', '2015-10-26 21:38:52', '', 28, '//giger.local/wp-content/uploads/2015/09/Thistle_b.jpg', 0, 'attachment', 'image/jpeg', 0),
(211, 1, '2015-10-27 00:44:55', '2015-10-26 21:44:55', '[gallery link="file" size="thumbnail-landscape" ids="210,209,208"]\r\n\r\n<strong>Наш фонд</strong> был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью. \r\n\r\n<b>Фонд</b> является экспериментальной площадкой, где происходит устойчивое развитие и неустойчивое продвижение.', 'Главная', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-10-27 00:44:55', '2015-10-26 21:44:55', '', 72, 'http://giger.local/72-revision-v1/', 0, 'revision', '', 0),
(212, 1, '2015-10-27 08:46:28', '2015-10-27 05:46:28', '[gallery link="file" size="thumbnail-landscape" ids="210,209,208"]\r\n\r\n<strong>Наш фонд</strong> был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью. \r\n\r\n<b>Фонд</b> является экспериментальной площадкой, где происходит устойчивое развитие и неустойчивое продвижение.', 'Главная', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-10-27 08:46:28', '2015-10-27 05:46:28', '', 72, 'http://giger.local/72-revision-v1/', 0, 'revision', '', 0),
(213, 1, '2015-10-27 08:46:59', '2015-10-27 05:46:59', '[gallery link="file" size="thumbnail-landscape" ids="210,209,208"]\r\n\r\n<strong>Наш фонд</strong> был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью. \r\n\r\n<b>Фонд</b> является экспериментальной площадкой, где происходит устойчивое развитие и неустойчивое продвижение.', 'Главная', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-10-27 08:46:59', '2015-10-27 05:46:59', '', 72, 'http://giger.local/72-revision-v1/', 0, 'revision', '', 0),
(214, 1, '2015-10-27 08:50:42', '2015-10-27 05:50:42', 'Это пример страницы посвященной деятельности фонда по направлениям и результатам.\r\n\r\nМы помогаем детям. Миссия нашего Фонда – сохранять, возвращать, создавать опору детям, находящимся в трудной жизненной ситуации, для обретения ими душевной гармонии, веры в жизнь и в себя.\r\n\r\nБлаготворительный детский фонд «Виктория» создан в 2004 году Николаем Александровичем Цветковым для помощи детям, оставшимся без попечения родителей и детям, находящимся в трудной жизненной ситуации. Нашими подопечными стали мальчики и девочки, живущие в детских домах и школах-интернатах в 46 регионах страны. Ближе познакомившись с жизнью воспитанников детских домов, мы поняли, что часто дети изымаются из родной семьи органами опеки, потому что родителям не была вовремя оказана нужная помощь.\r\n\r\nПриоритетным направлением деятельности Благотворительного фонда стала профилактика социального сиротства. В настоящее время Фонд реализует собственные программы по следующим ключевым направлениям:\r\n\r\n<strong>Профилактика социального сиротства и комплексная психолого-педагогическая помощь кризисным семьям</strong>.  Для нас очень важно, чтобы в России не увеличивалось число сирот при живых родителях. Наша задача – сохранить, спасти семью, не допустить, чтобы ребёнок лишился своих биологических родителей. Тесно взаимодействуя с органами опеки и попечительства, мы выявляем семьи, находящиеся в группе риска и оказавшиеся в кризисной ситуации и работаем с ними.  Мы создаем механизмы, позволяющие поддержать семью на самой ранней стадии «непогоды в доме»,  работаем с детьми, оказываем помощь и поддержку их родителям.\r\n\r\n<strong>Семейное устройство детей-сирот и поддержка приемных семей.</strong> Мы хотим, чтобы каждый ребёнок жил и воспитывался в любящей семье. Наша задача – помочь обрести детям-сиротам новую семью, а маме и папе подготовиться к ответственному шагу и новому этапу их жизни. Созданная Фондом Школа приемных семей Арбат занимается подготовкой потенциальных приёмных родителей и психолого-педагогическим сопровождением новых приёмных семей. Отдельным  направлением нашей работы является подготовка специалистов для работы с приемными семьями, семьями группы риска и семьями, находящимися в кризисной ситуации.\r\n', 'Что мы делаем', '', 'inherit', 'closed', 'closed', '', '149-revision-v1', '', '', '2015-10-27 08:50:42', '2015-10-27 05:50:42', '', 149, 'http://giger.local/149-revision-v1/', 0, 'revision', '', 0),
(215, 1, '2015-10-27 08:55:30', '2015-10-27 05:55:30', 'Это пример страницы посвященной деятельности фонда по направлениям и результатам.\r\n\r\nМы помогаем детям. Миссия нашего Фонда – сохранять, возвращать, создавать опору детям, находящимся в трудной жизненной ситуации, для обретения ими душевной гармонии, веры в жизнь и в себя.\r\n\r\nБлаготворительный детский фонд «Виктория» создан в 2004 году Николаем Александровичем Цветковым для помощи детям, оставшимся без попечения родителей и детям, находящимся в трудной жизненной ситуации. Нашими подопечными стали мальчики и девочки, живущие в детских домах и школах-интернатах в 46 регионах страны. Ближе познакомившись с жизнью воспитанников детских домов, мы поняли, что часто дети изымаются из родной семьи органами опеки, потому что родителям не была вовремя оказана нужная помощь.\r\n\r\nПриоритетным направлением деятельности Благотворительного фонда стала профилактика социального сиротства. В настоящее время Фонд реализует собственные программы по следующим ключевым направлениям:\r\n\r\n<strong>Профилактика социального сиротства и комплексная психолого-педагогическая помощь кризисным семьям</strong>.  Для нас очень важно, чтобы в России не увеличивалось число сирот при живых родителях. Наша задача – сохранить, спасти семью, не допустить, чтобы ребёнок лишился своих биологических родителей. Тесно взаимодействуя с органами опеки и попечительства, мы выявляем семьи, находящиеся в группе риска и оказавшиеся в кризисной ситуации и работаем с ними.  Мы создаем механизмы, позволяющие поддержать семью на самой ранней стадии «непогоды в доме»,  работаем с детьми, оказываем помощь и поддержку их родителям.\r\n\r\n<strong>Семейное устройство детей-сирот и поддержка приемных семей.</strong> Мы хотим, чтобы каждый ребёнок жил и воспитывался в любящей семье. Наша задача – помочь обрести детям-сиротам новую семью, а маме и папе подготовиться к ответственному шагу и новому этапу их жизни. Созданная Фондом Школа приемных семей Арбат занимается подготовкой потенциальных приёмных родителей и психолого-педагогическим сопровождением новых приёмных семей. Отдельным  направлением нашей работы является подготовка специалистов для работы с приемными семьями, семьями группы риска и семьями, находящимися в кризисной ситуации.\r\n', 'Что мы делаем', '', 'inherit', 'closed', 'closed', '', '149-revision-v1', '', '', '2015-10-27 08:55:30', '2015-10-27 05:55:30', '', 149, 'http://giger.local/149-revision-v1/', 0, 'revision', '', 0),
(216, 1, '2015-10-28 08:22:49', '2015-10-28 05:22:49', 'С одной стороны, это печальная информация, ведь статистика просто пугает – миллионы смертей от ССЗ, и в том числе от инсульта, во всем мире.\n\nС другой стороны, она должна вселять оптимизм, ведь в большинстве случаев эти заболевания можно предотвратить с помощью своего образа жизни.\n\nК сожалению, не все знают о том, что незначительные изменения в привычках могут серьезно снизить шансы возникновения у вас инсульта. Особенно незначительными эти изменения кажутся, если их сравнивать с тем, что человеку приходится менять в своей жизни после инсульта.\n\nБольшое исследование, проведенное в США, показало, что образ жизни, позволяющий держать в норме семь факторов здоровья, помогает снизить риск инсульта.\n\nУченые исследовали почти 23 тысячи американцев в возрасте от 45 лет и старше. Их риски оценивались при помощи семи простых факторов здоровья, предложенных Американской ассоциацией кардиологов:\n<ul>\n	<li>физическая активность,</li>\n	<li>контроль уровня холестерина,</li>\n	<li>контроль сахара в крови,</li>\n	<li>контроль кровяного давления,</li>\n	<li>здоровое питание,</li>\n	<li>поддержание здорового веса и</li>\n	<li>исключение курения.</li>\n</ul>\nВ течение пяти лет наблюдения среди участников было зарегистрировано 432 приступа инсульта. Все семь факторов сыграли важную роль в прогнозировании риска инсульта. В ходе исследования ученые квалифицировали соблюдение участниками семи показателей здоровья по категориям и выделили следующие:\n<ul>\n	<li>недостаточное (от 0 до 4 баллов),</li>\n	<li>среднее (от 5 до 9 баллов) и</li>\n	<li>оптимальное (от 10 до 14 баллов).</li>\n</ul>\nТак вот: увеличение показателя всего на 1 пункт связывалось с сокращением риска развития инсульта на 8%. У людей с оптимальными показателями риск инсульта был на 48% ниже, а у людей со средними показателями — на 27% ниже, чем у тех, чьи показатели оценивались как недостаточные.\n\nНа мой взгляд, эти данные выглядят очень позитивно: они доказывают, что в наших руках возможность предотвратить смертельную болезнь. Проблема остается только в одном: заставить себя изменить образ жизни лучшую сторону. Большинству из нас сделать это достаточно сложно. Кто-то не знает, с чего начать. Кто-то теряется в противоречивой информации о здоровом образе жизни. А кто-то даже не задумывается о том, насколько это важно!', 'Образ жизни поможет снизить риск болезни', 'Основными причинами смерти во всем мире уже несколько лет являются сердечно-сосудистые заболевания (ССЗ). От них страдает не только развитый западный мир, но и страны третьего мира. ', 'inherit', 'closed', 'closed', '', '28-autosave-v1', '', '', '2015-10-28 08:22:49', '2015-10-28 05:22:49', '', 28, 'http://giger.local/28-autosave-v1/', 0, 'revision', '', 0),
(218, 1, '2015-11-07 23:33:30', '2015-11-07 20:33:30', 'a:7:{s:8:"location";a:1:{i:0;a:2:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}i:1;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:7:"default";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Встроенные элементы', 'vstroennye-elementy', 'publish', 'closed', 'closed', '', 'group_5633143a4384e', '', '', '2015-11-07 23:33:30', '2015-11-07 20:33:30', '', 0, 'http://giger.local/?post_type=acf-field-group&p=218', 0, 'acf-field-group', '', 0),
(219, 1, '2015-11-07 23:33:30', '2015-11-07 20:33:30', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', 'Встроенные элементы - заголовок', 'embed_posts_title', 'publish', 'closed', 'closed', '', 'field_5602d1d1055a7', '', '', '2015-11-07 23:33:30', '2015-11-07 20:33:30', '', 218, 'http://giger.local/?post_type=acf-field&p=219', 0, 'acf-field', '', 0),
(220, 1, '2015-11-07 23:33:30', '2015-11-07 20:33:30', 'a:12:{s:4:"type";s:12:"relationship";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:9:"post_type";a:5:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:5:"event";i:3;s:3:"org";i:4;s:7:"project";}s:8:"taxonomy";a:0:{}s:7:"filters";a:2:{i:0;s:6:"search";i:1;s:9:"post_type";}s:8:"elements";a:1:{i:0;s:14:"featured_image";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:13:"return_format";s:6:"object";}', 'Встроенные элементы', 'embed_posts', 'publish', 'closed', 'closed', '', 'field_5602bd8ab85b3', '', '', '2015-11-07 23:33:30', '2015-11-07 20:33:30', '', 218, 'http://giger.local/?post_type=acf-field&p=220', 1, 'acf-field', '', 0),
(221, 1, '2015-11-07 23:33:30', '2015-11-07 20:33:30', 'a:7:{s:8:"location";a:1:{i:0;a:2:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"page";}i:1;a:3:{s:5:"param";s:13:"page_template";s:8:"operator";s:2:"==";s:5:"value";s:19:"page-post_cards.php";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";}', 'Карточки из материалов', 'kartochki-iz-materialov', 'publish', 'closed', 'closed', '', 'group_5633158f95c6d', '', '', '2015-11-07 23:33:30', '2015-11-07 20:33:30', '', 0, 'http://giger.local/?post_type=acf-field-group&p=221', 0, 'acf-field-group', '', 0),
(222, 1, '2015-11-07 23:33:30', '2015-11-07 20:33:30', 'a:14:{s:4:"type";s:6:"select";s:12:"instructions";s:58:"Укажите тип записи для карточки";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:8:"children";s:8:"Дети";s:3:"org";s:16:"Партнеры";}s:13:"default_value";a:0:{}s:10:"allow_null";i:1;s:8:"multiple";i:0;s:2:"ui";i:0;s:4:"ajax";i:0;s:11:"placeholder";s:0:"";s:8:"disabled";i:0;s:8:"readonly";i:0;}', 'Тип контента', 'cards_post_type', 'publish', 'closed', 'closed', '', 'field_563315aef7e82', '', '', '2015-11-07 23:33:30', '2015-11-07 20:33:30', '', 221, 'http://giger.local/?post_type=acf-field&p=222', 0, 'acf-field', '', 0),
(223, 1, '2015-11-07 23:33:30', '2015-11-07 20:33:30', 'a:13:{s:4:"type";s:8:"taxonomy";s:12:"instructions";s:0:"";s:8:"required";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:8:"taxonomy";s:15:"children_status";s:10:"field_type";s:6:"select";s:10:"allow_null";i:1;s:8:"add_term";i:0;s:10:"save_terms";i:0;s:10:"load_terms";i:0;s:13:"return_format";s:2:"id";s:8:"multiple";i:0;s:17:"conditional_logic";a:1:{i:0;a:1:{i:0;a:3:{s:5:"field";s:19:"field_563315aef7e82";s:8:"operator";s:2:"==";s:5:"value";s:8:"children";}}}}', 'Фильтр по статусу', 'filter_children_status', 'publish', 'closed', 'closed', '', 'field_5633164a836c2', '', '', '2015-11-07 23:33:30', '2015-11-07 20:33:30', '', 221, 'http://giger.local/?post_type=acf-field&p=223', 1, 'acf-field', '', 0),
(224, 1, '2015-11-07 23:33:30', '2015-11-07 20:33:30', 'a:10:{s:4:"type";s:5:"radio";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:7:"choices";a:2:{s:6:"bottom";s:40:"Внизу (после карточек)";s:3:"top";s:46:"Вверху (перед карточками)";}s:12:"other_choice";i:0;s:17:"save_other_choice";i:0;s:13:"default_value";s:6:"bottom";s:6:"layout";s:8:"vertical";}', 'Показывать текстовое содержание', 'page_content_on', 'publish', 'closed', 'closed', '', 'field_5633175c29c63', '', '', '2015-11-07 23:33:30', '2015-11-07 20:33:30', '', 221, 'http://giger.local/?post_type=acf-field&p=224', 2, 'acf-field', '', 0);
INSERT INTO `str_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(226, 1, '2015-11-07 23:41:15', '2015-11-07 20:41:15', 'Это пример страницы посвященной деятельности фонда по направлениям и результатам.\r\n\r\nМы помогаем детям. Миссия нашего Фонда – сохранять, возвращать, создавать опору детям, находящимся в трудной жизненной ситуации, для обретения ими душевной гармонии, веры в жизнь и в себя.\r\n\r\nБлаготворительный детский фонд «Виктория» создан в 2004 году Николаем Александровичем Цветковым для помощи детям, оставшимся без попечения родителей и детям, находящимся в трудной жизненной ситуации. Нашими подопечными стали мальчики и девочки, живущие в детских домах и школах-интернатах в 46 регионах страны. Ближе познакомившись с жизнью воспитанников детских домов, мы поняли, что часто дети изымаются из родной семьи органами опеки, потому что родителям не была вовремя оказана нужная помощь.\r\n\r\nПриоритетным направлением деятельности Благотворительного фонда стала профилактика социального сиротства. В настоящее время Фонд реализует собственные программы по следующим ключевым направлениям:\r\n\r\n<strong>Профилактика социального сиротства и комплексная психолого-педагогическая помощь кризисным семьям</strong>.  Для нас очень важно, чтобы в России не увеличивалось число сирот при живых родителях. Наша задача – сохранить, спасти семью, не допустить, чтобы ребёнок лишился своих биологических родителей. Тесно взаимодействуя с органами опеки и попечительства, мы выявляем семьи, находящиеся в группе риска и оказавшиеся в кризисной ситуации и работаем с ними.  Мы создаем механизмы, позволяющие поддержать семью на самой ранней стадии «непогоды в доме»,  работаем с детьми, оказываем помощь и поддержку их родителям.\r\n\r\n<strong>Семейное устройство детей-сирот и поддержка приемных семей.</strong> Мы хотим, чтобы каждый ребёнок жил и воспитывался в любящей семье. Наша задача – помочь обрести детям-сиротам новую семью, а маме и папе подготовиться к ответственному шагу и новому этапу их жизни. Созданная Фондом Школа приемных семей Арбат занимается подготовкой потенциальных приёмных родителей и психолого-педагогическим сопровождением новых приёмных семей. Отдельным  направлением нашей работы является подготовка специалистов для работы с приемными семьями, семьями группы риска и семьями, находящимися в кризисной ситуации.\r\n', 'Что мы делаем', '', 'inherit', 'closed', 'closed', '', '149-revision-v1', '', '', '2015-11-07 23:41:15', '2015-11-07 20:41:15', '', 149, 'http://giger.local/149-revision-v1/', 0, 'revision', '', 0),
(233, 1, '2015-11-11 09:04:53', '2015-11-11 06:04:53', '<strong>8 800 123-45-45</strong> \r\nбесплатный для всех регионов России\r\n\r\n<strong>+7 (985) 123-33-33</strong>\r\nдля партнеров\r\n\r\nЮридический адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nПочтовый адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nE-mail: info@domain.ru\r\n\r\n[pw_map address="Россия, Москва, Лубянский пр-д, 19, стр. 1" width="100%" height="330px"]\r\n\r\n[formidable id="6"]', 'Контакты', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2015-11-11 09:04:53', '2015-11-11 06:04:53', '', 79, 'http://giger.local/79-revision-v1/', 0, 'revision', '', 0),
(234, 1, '2015-11-11 09:06:42', '2015-11-11 06:06:42', '<strong>Интеграция</strong> иллюстрирует конвергентный штраф. Перестрахование защищает целевой сегмент рынка. В данном случае можно согласиться с А.А. Земляковским и с румынским исследователем <a href="http://iskorka.local/children/zhukova-elizaveta/">Альбертом Ковачем</a>, считающими, что бренд <em>прочно отражает сюжетный суд</em>. Корпоративная культура, в первом приближении, начинает конструктивный дискурс. Муниципальная собственность тормозит гарант. Экспансия, безусловно, предоставляет диалектический характер.\r\n\r\n<ul>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ul>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n\r\n<ol>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ol>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n[tst_quote name="Николай Иванов, волонтер"]<img src="//giger.local/wp-content/uploads/2015/10/testface2-150x150.jpg" alt="testface2" width="150" height="150" class="alignleft size-thumbnail wp-image-155" /> Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.\r\n[/tst_quote]\r\n\r\nЭто просто кусочек предложения, который нужно убрать, но он есть.\r\n\r\n<blockquote>Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.</blockquote>\r\n\r\n[su_spoiler title="Стать донором костного мозга"]Давайте напишем небольшой релевантный и понятный текст о том, как же им стать и а подробную информацию можно будет получить по ссылкам.\r\n\r\n<a href="https://www.miloserdie.ru/article/donorstvo-i-transplantaciya-kostnogo-mozga-chasto-zadavaemye-voprosy/">Донорство костного мозга. Часто задаваемые вопросы</a>[/su_spoiler]\r\n\r\nСтратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.\r\n\r\n[tst_tabs]\r\n[tab title="Первое"]Это первое. Стратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.[/tab]\r\n[tab title="Второе"]Это второе. Стратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.[/tab]\r\n[tab title="Третье"]Это третье. Стратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.[/tab]\r\n[/tst_tabs]', 'Демонстрация элементов текста', 'Это тестовая статья - не удаляте ее пожалуйста до окончания отладки, кроме того, элементы оформления в ней можно использовать как пример элементов оформления.', 'publish', 'closed', 'closed', '', 'demonstratsiya-elementov-teksta', '', '', '2015-12-10 15:32:46', '2015-12-10 12:32:46', '', 0, 'http://giger.local/?p=234', 0, 'post', '', 0),
(235, 1, '2015-11-11 09:06:42', '2015-11-11 06:06:42', '<strong>Интеграция</strong> иллюстрирует конвергентный штраф. Перестрахование защищает целевой сегмент рынка. В данном случае можно согласиться с А.А. Земляковским и с румынским исследователем <a href="http://iskorka.local/children/zhukova-elizaveta/">Альбертом Ковачем</a>, считающими, что бренд <em>прочно отражает сюжетный суд</em>. Корпоративная культура, в первом приближении, начинает конструктивный дискурс. Муниципальная собственность тормозит гарант. Экспансия, безусловно, предоставляет диалектический характер.\r\n\r\n<ul>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ul>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n\r\n<ol>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ol>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n[tst_quote name="Николай Иванов, волонтер"]<img src="//iskorka.local/wp-content/uploads/2015/10/testface2-150x150.jpg" alt="testface2" width="150" height="150" class="alignleft size-thumbnail wp-image-155" /> Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.\r\n[/tst_quote]\r\n\r\nЭто просто кусочек предложения, который нужно убрать, но он есть.\r\n\r\n<blockquote>Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.</blockquote>\r\n\r\n[su_spoiler title="Стать донором костного мозга"]Давайте напишем небольшой релевантный и понятный текст о том, как же им стать и а подробную информацию можно будет получить по ссылкам.\r\n\r\n<a href="https://www.miloserdie.ru/article/donorstvo-i-transplantaciya-kostnogo-mozga-chasto-zadavaemye-voprosy/">Донорство костного мозга. Часто задаваемые вопросы</a>[/su_spoiler]\r\n\r\nСтратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.', 'Демонстрация элементов текста', 'Это тестовая статья - не удаляте ее пожалуйста до окончания отладки, кроме того, элементы оформления в ней можно использовать как пример элементов оформления.', 'inherit', 'closed', 'closed', '', '234-revision-v1', '', '', '2015-11-11 09:06:42', '2015-11-11 06:06:42', '', 234, 'http://giger.local/234-revision-v1/', 0, 'revision', '', 0),
(236, 1, '2015-11-11 09:20:16', '2015-11-11 06:20:16', '<strong>Интеграция</strong> иллюстрирует конвергентный штраф. Перестрахование защищает целевой сегмент рынка. В данном случае можно согласиться с А.А. Земляковским и с румынским исследователем <a href="http://iskorka.local/children/zhukova-elizaveta/">Альбертом Ковачем</a>, считающими, что бренд <em>прочно отражает сюжетный суд</em>. Корпоративная культура, в первом приближении, начинает конструктивный дискурс. Муниципальная собственность тормозит гарант. Экспансия, безусловно, предоставляет диалектический характер.\r\n\r\n<ul>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ul>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n\r\n<ol>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ol>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n[tst_quote name="Николай Иванов, волонтер"]<img src="//giger.local/wp-content/uploads/2015/10/testface2-150x150.jpg" alt="testface2" width="150" height="150" class="alignleft size-thumbnail wp-image-155" /> Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.\r\n[/tst_quote]\r\n\r\nЭто просто кусочек предложения, который нужно убрать, но он есть.\r\n\r\n<blockquote>Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.</blockquote>\r\n\r\n[su_spoiler title="Стать донором костного мозга"]Давайте напишем небольшой релевантный и понятный текст о том, как же им стать и а подробную информацию можно будет получить по ссылкам.\r\n\r\n<a href="https://www.miloserdie.ru/article/donorstvo-i-transplantaciya-kostnogo-mozga-chasto-zadavaemye-voprosy/">Донорство костного мозга. Часто задаваемые вопросы</a>[/su_spoiler]\r\n\r\nСтратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.', 'Демонстрация элементов текста', 'Это тестовая статья - не удаляте ее пожалуйста до окончания отладки, кроме того, элементы оформления в ней можно использовать как пример элементов оформления.', 'inherit', 'closed', 'closed', '', '234-revision-v1', '', '', '2015-11-11 09:20:16', '2015-11-11 06:20:16', '', 234, 'http://giger.local/234-revision-v1/', 0, 'revision', '', 0),
(237, 1, '2015-11-11 01:18:16', '2015-11-10 22:18:16', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'closed', 'closed', '', '7_email_237', '', '', '2015-11-11 09:41:13', '2015-11-11 06:41:13', '', 0, 'http://giger.local/frm_form_actions/9_email_438/', 7, 'frm_form_actions', '', 0),
(238, 1, '2015-11-11 10:00:21', '2015-11-11 07:00:21', '<strong>8 800 123-45-45</strong> \r\nбесплатный для всех регионов России\r\n\r\n<strong>+7 (985) 123-33-33</strong>\r\nдля партнеров\r\n\r\nЮридический адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nПочтовый адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nE-mail: info@domain.ru\r\n\r\n[pw_map address="Россия, Москва, Лубянский пр-д, 19, стр. 1" width="100%" height="330px"]\r\n\r\n[formidable id=6 title=true description=true]', 'Контакты', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2015-11-11 10:00:21', '2015-11-11 07:00:21', '', 79, 'http://giger.local/79-revision-v1/', 0, 'revision', '', 0),
(239, 1, '2015-11-11 10:37:10', '2015-11-11 07:37:10', '<strong>8 800 123-45-45</strong> \r\nбесплатный для всех регионов России\r\n\r\n<strong>+7 (985) 123-33-33</strong>\r\nдля партнеров\r\n\r\nЮридический адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nПочтовый адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nE-mail: info@domain.ru\r\n\r\n[pw_map_1 address="Россия, Москва, Лубянский пр-д, 19, стр. 1" width="100%" height="330px"]\r\n\r\n[formidable id=6 title=true description=true]', 'Контакты', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2015-11-11 10:37:10', '2015-11-11 07:37:10', '', 79, 'http://giger.local/79-revision-v1/', 0, 'revision', '', 0),
(240, 1, '2015-11-11 11:16:34', '2015-11-11 08:16:34', '<strong>8 800 123-45-45</strong> \r\nбесплатный для всех регионов России\r\n\r\n<strong>+7 (985) 123-33-33</strong>\r\nдля партнеров\r\n\r\nЮридический адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nПочтовый адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nE-mail: info@domain.ru\r\n\r\n[pw_map address="Россия, Москва, Лубянский пр-д, 19, стр. 1" width="100%" height="330px"]\r\n\r\n[formidable id=6 title=true description=true]', 'Контакты', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2015-11-11 11:16:34', '2015-11-11 08:16:34', '', 79, 'http://giger.local/79-revision-v1/', 0, 'revision', '', 0),
(241, 1, '2015-11-11 11:37:57', '2015-11-11 08:37:57', 'Система тестов, специально разработанных для сайта НКО, позволит определить удобство вашего сайта для пользователя и простоту текстов для понимания', 'Аудит сайта НКО', '', 'inherit', 'closed', 'closed', '', '68-autosave-v1', '', '', '2015-11-11 11:37:57', '2015-11-11 08:37:57', '', 68, 'http://giger.local/68-autosave-v1/', 0, 'revision', '', 0),
(242, 1, '2015-11-11 11:38:04', '2015-11-11 08:38:04', '', 'audit', '', 'inherit', 'closed', 'closed', '', 'audit', '', '', '2015-11-11 11:38:04', '2015-11-11 08:38:04', '', 68, '//giger.local/wp-content/uploads/2015/09/audit.png', 0, 'attachment', 'image/png', 0),
(243, 1, '2015-11-11 11:40:48', '2015-11-11 08:40:48', 'сервис для создания сайтов, логотипов, буклетов и текстов для некоммерческих организаций', 'it-волонтер', '', 'inherit', 'closed', 'closed', '', '67-autosave-v1', '', '', '2015-11-11 11:40:48', '2015-11-11 08:40:48', '', 67, 'http://giger.local/67-autosave-v1/', 0, 'revision', '', 0),
(244, 1, '2015-11-11 11:40:56', '2015-11-11 08:40:56', '', 'itv', '', 'inherit', 'closed', 'closed', '', 'itv', '', '', '2015-11-11 11:40:56', '2015-11-11 08:40:56', '', 67, '//giger.local/wp-content/uploads/2015/09/itv.png', 0, 'attachment', 'image/png', 0),
(245, 1, '2015-11-11 11:43:38', '2015-11-11 08:43:38', 'Live up! — блог о здоровом образе жизни и долголетии, который существует с марта 2013 года. Автор — Юлия Корнева — рассказывает о том, чему она научилась и что испытала на собственном опыте в поисках здорового образа жизни, системы правильного питания, простых и полезных физических нагрузок, методов борьбы со стрессом, эффективной превентивной медицины. ', 'Пасека', '', 'inherit', 'closed', 'closed', '', '66-autosave-v1', '', '', '2015-11-11 11:43:38', '2015-11-11 08:43:38', '', 66, 'http://giger.local/66-autosave-v1/', 0, 'revision', '', 0),
(246, 1, '2015-11-11 11:45:08', '2015-11-11 08:45:08', '', 'paseka', '', 'inherit', 'closed', 'closed', '', 'paseka', '', '', '2015-11-11 11:45:08', '2015-11-11 08:45:08', '', 66, '//giger.local/wp-content/uploads/2015/09/paseka.png', 0, 'attachment', 'image/png', 0),
(248, 1, '2015-11-11 11:46:49', '2015-11-11 08:46:49', 'Журнал о беге всегда с эксклюзивными репортажами, актуальными новостями и мотивирующими историями.', 'Онлайн-', '', 'inherit', 'closed', 'closed', '', '63-autosave-v1', '', '', '2015-11-11 11:46:49', '2015-11-11 08:46:49', '', 63, 'http://giger.local/63-autosave-v1/', 0, 'revision', '', 0),
(249, 1, '2015-11-11 11:48:37', '2015-11-11 08:48:37', '', 'leyka', '', 'inherit', 'closed', 'closed', '', 'leyka', '', '', '2015-11-11 11:48:37', '2015-11-11 08:48:37', '', 63, '//giger.local/wp-content/uploads/2015/09/leyka.png', 0, 'attachment', 'image/png', 0),
(250, 1, '2015-11-11 18:56:06', '2015-11-11 15:56:06', 'Fitoguru — это функциональные напитки,  которые обеспечивают Вас необходимыми биологически активными веществами, полученными из  ягод, фруктов и овощей, экстрактов дикорастущих трав и цветков,  корней и продуктов пчеловодства.', 'Теплица социальных технологий', '', 'inherit', 'closed', 'closed', '', '61-autosave-v1', '', '', '2015-11-11 18:56:06', '2015-11-11 15:56:06', '', 61, 'http://giger.local/61-autosave-v1/', 0, 'revision', '', 0),
(251, 1, '2015-11-11 19:23:47', '2015-11-11 16:23:47', '', 'teplitsa', '', 'inherit', 'closed', 'closed', '', 'teplitsa', '', '', '2015-11-11 19:23:47', '2015-11-11 16:23:47', '', 61, '//giger.local/wp-content/uploads/2015/09/teplitsa.png', 0, 'attachment', 'image/png', 0),
(252, 1, '2015-11-11 20:14:47', '2015-11-11 17:14:47', '', 'asi-logo-blank-sm', '', 'inherit', 'closed', 'closed', '', 'asi-logo-blank-sm', '', '', '2015-11-11 20:14:47', '2015-11-11 17:14:47', '', 59, '//giger.local/wp-content/uploads/2015/09/asi-logo-blank-sm.png', 0, 'attachment', 'image/png', 0),
(253, 0, '2015-04-06 17:18:12', '2015-04-06 17:18:12', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'open', 'open', '', '1_email_1-2', '', '', '2015-04-06 17:18:12', '2015-04-06 17:18:12', '', 0, 'http://giger.local/1_email_1-2/', 1, 'frm_form_actions', '', 0),
(254, 1, '2015-09-18 17:54:08', '2015-09-18 14:54:08', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'closed', 'closed', '', '6_email_83-2', '', '', '2015-09-18 17:54:08', '2015-09-18 14:54:08', '', 0, 'http://giger.local/frm_form_actions/6_email_83-2/', 2, 'frm_form_actions', '', 0),
(255, 1, '2015-11-11 01:18:16', '2015-11-10 22:18:16', '{"email_to":"[admin_email]","cc":"","bcc":"","reply_to":"","from":"[sitename] <[admin_email]>","email_subject":"","email_message":"[default-message]","event":["create"],"conditions":{"send_stop":"send","any_all":"any"}}', 'Email Notification', 'email', 'publish', 'closed', 'closed', '', '7_email_237-2', '', '', '2015-11-11 01:18:16', '2015-11-10 22:18:16', '', 0, 'http://giger.local/frm_form_actions/7_email_237-2/', 3, 'frm_form_actions', '', 0),
(256, 1, '2015-11-13 19:01:18', '2015-11-13 16:01:18', '<strong>8 800 123-45-45</strong> \r\nбесплатный для всех регионов России\r\n\r\n<strong>+7 (985) 123-33-33</strong>\r\nдля партнеров\r\n\r\nЮридический адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nПочтовый адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nE-mail: info@domain.ru\r\n\r\n[pw_map address="Россия, Москва, Лубянский пр-д, 19, стр. 1" width="100%" height="330px"]\r\n\r\n[formidable id=2 title=true description=true]', 'Контакты', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2015-11-13 19:01:18', '2015-11-13 16:01:18', '', 79, 'http://giger.local/79-revision-v1/', 0, 'revision', '', 0),
(260, 1, '2015-11-14 22:47:36', '2015-11-14 19:47:36', 'Работает не покладая рук и без него все давно бы пропало', 'Василий Иванов', '', 'publish', 'closed', 'closed', '', 'vasilij-ivanov', '', '', '2015-11-14 22:47:47', '2015-11-14 19:47:47', '', 0, 'http://giger.local/?post_type=person&#038;p=260', 0, 'person', '', 0),
(261, 1, '2015-11-14 23:57:16', '2015-11-14 20:57:16', 'Работает не покладая рук и без него все давно бы пропало', 'Николай Николаев', '', 'publish', 'closed', 'closed', '', 'nikolaj-nikolaev', '', '', '2015-11-14 23:57:24', '2015-11-14 20:57:24', '', 0, 'http://giger.local/?post_type=person&#038;p=261', 0, 'person', '', 0),
(262, 1, '2015-11-14 22:57:55', '2015-11-14 19:57:55', 'Работает не покладая рук и без него все давно бы пропало', 'Зимникус', 'https://www.google.ru/', 'publish', 'closed', 'closed', '', 'zimnikus', '', '', '2015-11-15 10:24:54', '2015-11-15 07:24:54', '', 0, 'http://giger.local/?post_type=person&#038;p=262', 0, 'person', '', 0),
(263, 1, '2015-11-15 02:07:37', '2015-11-14 23:07:37', 'С Ксюней мы очень любим батут, она буквально затаскивает всех на него. Мы обожаем прыгать, взявшись за руки и напевая любимую мелодию. Только вот волонтеры быстро устают, а ей всё мало и мало.\r\n\r\nОна очень любознательна, ей интересны, казалось бы, вовсе неинтересные вещи и предметы. Она находит что-то прекрасное во всем, что видит. Но если это что-то прекрасное попадет ей в руки, то отобрать у неё не получится. В этом случае она признает только обмен на что-то не менее впечатляющее. Очень сообразительная девочка и безумно красивая.\r\n', 'Ксения Иванова', 'Сколько сил и энергии в этой крохе! Не сидит на месте никогда, постоянно в движении.', 'publish', 'closed', 'closed', '', 'ksenij-ivanova', '', '', '2015-11-15 10:03:30', '2015-11-15 07:03:30', '', 0, 'http://giger.local/?post_type=person&#038;p=263', 0, 'person', '', 0),
(264, 1, '2015-11-15 10:03:17', '2015-11-15 07:03:17', '', 'ch1_b', '', 'inherit', 'closed', 'closed', '', 'ch1_b', '', '', '2015-11-15 10:03:17', '2015-11-15 07:03:17', '', 263, '//giger.local/wp-content/uploads/2015/11/ch1_b.jpg', 0, 'attachment', 'image/jpeg', 0),
(265, 1, '2015-11-15 10:03:19', '2015-11-15 07:03:19', '', 'ch2_b', '', 'inherit', 'closed', 'closed', '', 'ch2_b', '', '', '2015-11-15 10:03:19', '2015-11-15 07:03:19', '', 263, '//giger.local/wp-content/uploads/2015/11/ch2_b.jpg', 0, 'attachment', 'image/jpeg', 0),
(266, 1, '2015-11-15 10:03:20', '2015-11-15 07:03:20', '', 'ch3_o', '', 'inherit', 'closed', 'closed', '', 'ch3_o', '', '', '2015-11-15 10:03:20', '2015-11-15 07:03:20', '', 263, '//giger.local/wp-content/uploads/2015/11/ch3_o.jpg', 0, 'attachment', 'image/jpeg', 0),
(267, 1, '2015-11-15 10:03:21', '2015-11-15 07:03:21', '', 'ch4_k', '', 'inherit', 'closed', 'closed', '', 'ch4_k', '', '', '2015-11-15 10:03:21', '2015-11-15 07:03:21', '', 263, '//giger.local/wp-content/uploads/2015/11/ch4_k.jpg', 0, 'attachment', 'image/jpeg', 0),
(269, 1, '2015-11-15 10:03:25', '2015-11-15 07:03:25', '', 'ch6_k', '', 'inherit', 'closed', 'closed', '', 'ch6_k', '', '', '2015-11-15 10:03:25', '2015-11-15 07:03:25', '', 263, '//giger.local/wp-content/uploads/2015/11/ch6_k.jpg', 0, 'attachment', 'image/jpeg', 0),
(270, 1, '2015-11-15 10:04:29', '2015-11-15 07:04:29', 'Особый интерес у Любы к разным сыпучим веществам, к песку, злакам, крупам, которые мы используем на занятиях.\r\n\r\nЛюбе просто необходимо много двигаться, бегать, так она тратит переполняющую ее энергию. Любе трудно усидеть на месте, поэтому все занятия с ней лучше проводить на открытом воздухе и направлять на спортивные игры.\r\n', 'Люба Иванова', 'Люба – самая активная девочка в группе, она любит бегать, интересуется разными игрушками, рассматривает и знакомится с разными предметами.', 'publish', 'closed', 'closed', '', 'lyuba-ivanova', '', '', '2015-11-15 10:04:38', '2015-11-15 07:04:38', '', 0, 'http://giger.local/?post_type=person&#038;p=270', 0, 'person', '', 0),
(271, 1, '2015-11-15 10:04:24', '2015-11-15 07:04:24', '', 'ch2_b', '', 'inherit', 'closed', 'closed', '', 'ch2_b-2', '', '', '2015-11-15 10:04:24', '2015-11-15 07:04:24', '', 270, '//giger.local/wp-content/uploads/2015/11/ch2_b1.jpg', 0, 'attachment', 'image/jpeg', 0),
(272, 1, '2015-11-15 10:08:09', '2015-11-15 07:08:09', 'Он теперь самостоятельно одевается, кушает и даже иногда сам чистит зубы. Федя, мальчик-разбойник, стоит появиться взрослому человеку в группе и все внимание Федя старается обратить на себя. Он очень любит обниматься и при любом удобном случае хватает так крепко своими ручками человека, что тому только и остается поддаться его объятиям.\r\n\r\nФедя прекрасно рисует, но только если у него есть на это настроение, а также лепит и собирает разные конструкторы. Особенно Федя любит рюкзаки, он собирает в рюкзак свои самые драгоценные вещи и может подолгу складывать их туда и доставать обратно.\r\n', 'Федя Иванов', 'В этом году Федя пошел в третий класс, ему нравится учиться.', 'publish', 'closed', 'closed', '', 'fedya-ivanov', '', '', '2015-11-15 10:08:09', '2015-11-15 07:08:09', '', 0, 'http://giger.local/?post_type=person&#038;p=272', 0, 'person', '', 0),
(274, 1, '2015-11-15 10:10:32', '2015-11-15 07:10:32', 'Наша команда — самая лучшая команда из команд', '', '', 'publish', 'closed', 'closed', '', '274', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://giger.local/?p=274', 8, 'nav_menu_item', '', 0),
(275, 1, '2015-11-15 10:10:45', '2015-11-15 07:10:45', 'Мы благодарим наших партнеров за неизменную поддержку', '', '', 'publish', 'closed', 'closed', '', '275', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://giger.local/?p=275', 10, 'nav_menu_item', '', 0),
(276, 1, '2015-11-15 10:11:18', '2015-11-15 07:11:18', 'Им нужна ваша помощь', '', '', 'publish', 'closed', 'closed', '', '276', '', '', '2015-12-10 14:16:19', '2015-12-10 11:16:19', '', 0, 'http://giger.local/?p=276', 5, 'nav_menu_item', '', 0),
(277, 1, '2015-11-15 10:16:55', '2015-11-15 07:16:55', 'Ей всего семь лет, но она уже многому научилась. Она очень самостоятельна. Сама принимает пищу, ходит в туалет, одевается и помогает одеваться другим девочкам, даже причесывается и делает прически другим детям.\r\n\r\nМаша очень любит заниматься творчеством: рисовать, лепить, делать аппликации, ходить на музыкальные занятия, танцевать и многое другое.\r\n\r\nМаша – очень забавная девочка, с ней невозможно грустить, она настолько радостный ребенок, что готова делиться своей радостью с другими.\r\n', 'Маша Иванова', 'Маша – новая девочка в группе. Она самая маленькая и самая умненькая.', 'publish', 'closed', 'closed', '', 'masha-ivanova', '', '', '2015-11-15 10:16:55', '2015-11-15 07:16:55', '', 0, 'http://giger.local/?post_type=person&#038;p=277', 0, 'person', '', 0),
(278, 1, '2015-11-15 10:18:16', '2015-11-15 07:18:16', 'Его вопросы бесконечны, с ним можно часами болтать о разных вещах, знакомить с окружающим миром, читать сказки и много объяснять про героев сказок. Его любопытство не имеет предела и это очень здорово.\r\n\r\nЕму очень нравится быть на виду у других людей. Из него получился бы великолепный артист.\r\n', 'Ярик Иванов', 'Ярик – самый шустрый в группе, много разговаривает, обо всем расспрашивает, ему интересно абсолютно все!', 'publish', 'closed', 'closed', '', 'yarik-ivanov', '', '', '2015-11-15 10:18:16', '2015-11-15 07:18:16', '', 0, 'http://giger.local/?post_type=person&#038;p=278', 0, 'person', '', 0),
(279, 1, '2015-11-12 10:25:10', '2015-11-12 07:25:10', 'Работает не покладая рук и без него все давно бы пропало', 'Семен Зимний', '', 'publish', 'closed', 'closed', '', 'semen-zimnij', '', '', '2015-11-15 10:25:35', '2015-11-15 07:25:35', '', 0, 'http://giger.local/?post_type=person&#038;p=279', 0, 'person', '', 0),
(280, 1, '2015-11-15 10:27:44', '2015-11-15 07:27:44', 'Мы благодарим наших партнеров за неизменную поддержку', '', '', 'publish', 'closed', 'closed', '', '280', '', '', '2015-11-15 10:27:44', '2015-11-15 07:27:44', '', 0, 'http://giger.local/?p=280', 4, 'nav_menu_item', '', 0);
INSERT INTO `str_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(281, 1, '2015-11-15 10:27:44', '2015-11-15 07:27:44', 'Наша команда — самая лучшая команда из команд', '', '', 'publish', 'closed', 'closed', '', '281', '', '', '2015-11-15 10:27:44', '2015-11-15 07:27:44', '', 0, 'http://giger.local/?p=281', 2, 'nav_menu_item', '', 0),
(282, 1, '2015-11-15 10:28:46', '2015-11-15 07:28:46', 'Мы благодарим наших партнеров за неизменную поддержку', '', '', 'publish', 'closed', 'closed', '', '282', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://giger.local/?p=282', 4, 'nav_menu_item', '', 0),
(283, 1, '2015-11-15 10:28:46', '2015-11-15 07:28:46', 'Наша команда — самая лучшая команда из команд', '', '', 'publish', 'closed', 'closed', '', '283', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://giger.local/?p=283', 2, 'nav_menu_item', '', 0),
(284, 1, '2015-11-15 10:28:46', '2015-11-15 07:28:46', 'Им нужна ваша помощь', '', '', 'publish', 'closed', 'closed', '', '284', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://giger.local/?p=284', 9, 'nav_menu_item', '', 0),
(285, 1, '2015-11-15 10:28:46', '2015-11-15 07:28:46', ' ', '', '', 'publish', 'closed', 'closed', '', '285', '', '', '2015-11-15 10:28:46', '2015-11-15 07:28:46', '', 0, 'http://giger.local/?p=285', 10, 'nav_menu_item', '', 0),
(286, 1, '2015-11-15 10:57:24', '2015-11-15 07:57:24', '<strong>Наш фонд</strong> был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью. ', 'Главная', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-11-15 10:57:24', '2015-11-15 07:57:24', '', 72, 'http://giger.local/72-revision-v1/', 0, 'revision', '', 0),
(287, 1, '2015-11-15 10:57:33', '2015-11-15 07:57:33', 'Наш фонд был создан в 2002 году группой педагогов, которых объединила общая мечта – помочь ребятам из детских домов реализовать свой потенциал и начать жить полноценной жизнью. ', 'Главная', '', 'inherit', 'closed', 'closed', '', '72-revision-v1', '', '', '2015-11-15 10:57:33', '2015-11-15 07:57:33', '', 72, 'http://giger.local/72-revision-v1/', 0, 'revision', '', 0),
(288, 1, '2015-11-12 12:36:28', '2015-11-12 09:36:28', 'Ей всего семь лет, но она уже многому научилась. Она очень самостоятельна. Сама принимает пищу, ходит в туалет, одевается и помогает одеваться другим девочкам, даже причесывается и делает прически другим детям.\r\n\r\nМаша очень любит заниматься творчеством: рисовать, лепить, делать аппликации, ходить на музыкальные занятия, танцевать и многое другое.\r\n\r\nМаша – очень забавная девочка, с ней невозможно грустить, она настолько радостный ребенок, что готова делиться своей радостью с другими.\r\n', 'Маша Смирнова', 'Маша – новая девочка в группе. Она самая маленькая и самая умненькая.', 'publish', 'closed', 'closed', '', 'masha-smirnova', '', '', '2015-11-15 12:36:54', '2015-11-15 09:36:54', '', 0, 'http://giger.local/profile/masha-ivanova-2/', 0, 'person', '', 0),
(289, 1, '2015-11-17 09:53:29', '2015-11-17 06:53:29', 'Профессиональное резюме руководителя проекта \n\n\nОпыт работы – 17 лет\nАктриса, сценарист, режиссёр, ведущая и педагог. \n\nОбразование \n\nсентябрь 1994 - июнь 1998г.г.\nЧелябинский государственный педагогический университет (ЧГПУ). Специальность – педагогика и методика начального обучения\nфакультет "УНК" \nкрасный диплом\nиюль 2007 г.\nкурсы «Менеджмент сервиса и туризма» (НОУ учебный центр «РОКСИ» г. Челябинск)\nапрель 2010 – ноябрь 2012г.г.\nТрехгодичные курсы повышения квалификации «Школа театральной режиссуры» (проводились совместно с СО СТД РФ (ВТО) г. Москва, ГАУК СГОДНТ и Фондом «Перспектива» г. Екатеринбург), руководитель курса –профессор Российской Академии театрального искусства (РАТИ/ГИТИС), вице-президент Российского центра международной ассоциации любительских театров (АИТА), режиссёр М.Н. Чумаченко (г. Москва)\n\nВедущая телевизионных программ «Марусины сказки» и «Марусина мастерская».\n\nС  1996 году в студии – театре «Манекен» ЮУрГУ.\nНаграды:\nФестиваль Весна УПИ - За лучший актёрский ансамбль спектакль «Пена дней» реж. В. Филонов 2000г. Г. Екатеринбург (роль цветка)\nЗа исполнение роли «Новый взгляд - 2005» г.Санкт – Петербург («Клиника» реж. В. Филонов)\nДиплом  за создание спектакля и исполнение роли - ф-ль "Авангард и Традиции" Гатчина 2010\nДипломы лучшая женская роль спектакль «ЛБВЬ» (реж. Н. Широкова):\nфестиваль «Встречное движение - 2009» г. Кемерово\nГран-при  спектакль «Сказки женщин» реж. В. Филонов г. Москва 2011г.\nфестиваль "Театральная революция" 2011 год г. Тюмень\nфестиваль "ТеАрт" г. Челябинск 2011 год\nфестиваль «Живые лица» 2012г. г. Тюмень\nЗа характерный образ¸ спектакль «МамаТатаДедаТеткаиЯ» (реж. Ю.Малышева): фестиваль «Живые лица» 2013г. Г. Тюмень\nфестиваль «Идиллиум» 2014 г. г. Москва ', 'Широкова Наталья Николаевна', '', 'trash', 'closed', 'closed', '', 'shirokova-natalya-nikolaevna', '', '', '2015-11-17 09:54:38', '2015-11-17 06:54:38', '', 0, 'http://giger.local/?post_type=person&#038;p=289', 0, 'person', '', 0),
(290, 1, '2015-12-10 12:55:14', '2015-12-10 09:55:14', 'Мы извиняемся, но по какой-то причине мы не смогли получить ваше пожертвование. Ваши деньги вернутся на ваш счёт. Пожалуйста, попробуйте ещё раз попозже!', 'Пожертвование не выполнено', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2015-12-10 12:55:14', '2015-12-10 09:55:14', '', 7, 'http://giger.local/7-revision-v1/', 0, 'revision', '', 0),
(291, 1, '2015-12-10 12:55:27', '2015-12-10 09:55:27', 'Извините, но по какой-то причине мы не смогли получить ваше пожертвование. Ваши деньги вернутся на ваш счёт. Пожалуйста, попробуйте ещё раз попозже!', 'Пожертвование не выполнено', '', 'inherit', 'closed', 'closed', '', '7-revision-v1', '', '', '2015-12-10 12:55:27', '2015-12-10 09:55:27', '', 7, 'http://giger.local/7-revision-v1/', 0, 'revision', '', 0),
(292, 1, '2015-12-10 12:55:46', '2015-12-10 09:55:46', 'Ура! Ваше пожертвование выполнено. Мы искренне благодарим вас за неравнодушие!', 'Ваше пожертвование выполнено!', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2015-12-10 12:55:46', '2015-12-10 09:55:46', '', 6, 'http://giger.local/6-revision-v1/', 0, 'revision', '', 0),
(293, 1, '2015-12-10 12:57:26', '2015-12-10 09:57:26', 'С помощью платежной квитанции можно сделать пожертвование в любом банке.\r\n\r\n\r\n', 'Спасибо за вашу помощь!', '', 'publish', 'closed', 'closed', '', 'thnak-you-bank', '', '', '2015-12-10 12:57:26', '2015-12-10 09:57:26', '', 0, 'http://giger.local/?page_id=293', 0, 'page', '', 0),
(294, 1, '2015-12-10 12:57:26', '2015-12-10 09:57:26', 'С помощью платежной квитанции можно сделать пожертвование в любом банке.\r\n\r\n\r\n', 'Спасибо за вашу помощь!', '', 'inherit', 'closed', 'closed', '', '293-revision-v1', '', '', '2015-12-10 12:57:26', '2015-12-10 09:57:26', '', 293, 'http://giger.local/293-revision-v1/', 0, 'revision', '', 0),
(295, 1, '2015-12-10 13:48:36', '2015-12-10 10:48:36', '', 'YT', '', 'publish', 'closed', 'closed', '', 'yt', '', '', '2015-12-10 13:48:36', '2015-12-10 10:48:36', '', 0, 'http://giger.local/?p=295', 3, 'nav_menu_item', '', 0),
(296, 1, '2015-12-10 14:17:01', '2015-12-10 11:17:01', ' ', '', '', 'publish', 'closed', 'closed', '', '296', '', '', '2015-12-10 14:17:05', '2015-12-10 11:17:05', '', 0, 'http://giger.local/?p=296', 4, 'nav_menu_item', '', 0),
(297, 1, '2015-12-10 14:17:01', '2015-12-10 11:17:01', ' ', '', '', 'publish', 'closed', 'closed', '', '297', '', '', '2015-12-10 14:17:05', '2015-12-10 11:17:05', '', 0, 'http://giger.local/?p=297', 5, 'nav_menu_item', '', 0),
(298, 1, '2015-12-10 15:32:46', '2015-12-10 12:32:46', '<strong>Интеграция</strong> иллюстрирует конвергентный штраф. Перестрахование защищает целевой сегмент рынка. В данном случае можно согласиться с А.А. Земляковским и с румынским исследователем <a href="http://iskorka.local/children/zhukova-elizaveta/">Альбертом Ковачем</a>, считающими, что бренд <em>прочно отражает сюжетный суд</em>. Корпоративная культура, в первом приближении, начинает конструктивный дискурс. Муниципальная собственность тормозит гарант. Экспансия, безусловно, предоставляет диалектический характер.\r\n\r\n<ul>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ul>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n\r\n<ol>\r\n<li>Палимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n<li>Модальность высказывания выражена наиболее полно.</li>\r\n</ol>\r\n\r\nПалимпсест, если рассматривать процессы в рамках частно-правовой теории, искажает договор. Селекция бренда, вопреки мнению П.Друкера, трансформирует гекзаметр, исключая принцип презумпции невиновности. Метаязык осознаёт ритм. Рекламное сообщество гарантирует пул лояльных изданий. Модальность высказывания выражена наиболее полно. Если рассмотреть все принятые в последнее время нормативные акты, то видно, что перестрахование регулярно запрещает рыночный вексель.\r\n\r\n[tst_quote name="Николай Иванов, волонтер"]<img src="//giger.local/wp-content/uploads/2015/10/testface2-150x150.jpg" alt="testface2" width="150" height="150" class="alignleft size-thumbnail wp-image-155" /> Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.\r\n[/tst_quote]\r\n\r\nЭто просто кусочек предложения, который нужно убрать, но он есть.\r\n\r\n<blockquote>Это пример отзыва, создать который конечно сложно, но мы постараемся, чтобы он был выразительный и со всех точек зрения помогал нам выразить то, что мы хотели бы выразить, если только это возможно. А если невозможно, то лучше сделайте пожертвование и помогите нам всем.</blockquote>\r\n\r\n[su_spoiler title="Стать донором костного мозга"]Давайте напишем небольшой релевантный и понятный текст о том, как же им стать и а подробную информацию можно будет получить по ссылкам.\r\n\r\n<a href="https://www.miloserdie.ru/article/donorstvo-i-transplantaciya-kostnogo-mozga-chasto-zadavaemye-voprosy/">Донорство костного мозга. Часто задаваемые вопросы</a>[/su_spoiler]\r\n\r\nСтратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.\r\n\r\n[tst_tabs]\r\n[tab title="Первое"]Это первое. Стратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.[/tab]\r\n[tab title="Второе"]Это второе. Стратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.[/tab]\r\n[tab title="Третье"]Это третье. Стратегия позиционирования недетерминировано допускает контент, потому что в стихах и в прозе автор рассказывает нам об одном и том же. Наш «сумароковский» классицизм – чисто русское явление, но сервитут семантически специфицирует эмпирический имидж. Медиапланирование слабо детерминирует социометрический амфибрахий. Возможно, что сходство Гугона и Микулы объясняется родством бродячих мотивов, однако Кодекс разрушаем. Маркетинг установлен обычаями делового оборота.[/tab]\r\n[/tst_tabs]', 'Демонстрация элементов текста', 'Это тестовая статья - не удаляте ее пожалуйста до окончания отладки, кроме того, элементы оформления в ней можно использовать как пример элементов оформления.', 'inherit', 'closed', 'closed', '', '234-revision-v1', '', '', '2015-12-10 15:32:46', '2015-12-10 12:32:46', '', 234, 'http://giger.local/234-revision-v1/', 0, 'revision', '', 0),
(299, 1, '2015-12-10 23:57:00', '0000-00-00 00:00:00', 'This is a preview of how this form will appear on your website', 'ninja_forms_preview_page', '', 'draft', 'closed', 'closed', '', '', '', '', '2015-12-10 23:57:00', '0000-00-00 00:00:00', '', 0, 'http://giger.local/?page_id=299', 0, 'page', '', 0),
(300, 1, '2015-12-11 00:07:29', '2015-12-10 21:07:29', '<strong>8 800 123-45-45</strong> \r\nбесплатный для всех регионов России\r\n\r\n<strong>+7 (985) 123-33-33</strong>\r\nдля партнеров\r\n\r\nЮридический адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nПочтовый адрес: \r\n101000, г. Москва, Лубянский пр-д, 19, стр. 1\r\n\r\nE-mail: info@domain.ru\r\n\r\n[pw_map address="Россия, Москва, Лубянский пр-д, 19, стр. 1" width="100%" height="330px"]\r\n\r\n[ninja_forms id=1]', 'Контакты', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2015-12-11 00:07:29', '2015-12-10 21:07:29', '', 79, 'http://giger.local/79-revision-v1/', 0, 'revision', '', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `str_termmeta`
--

DROP TABLE IF EXISTS `str_termmeta`;
CREATE TABLE `str_termmeta` (
`meta_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `str_terms`
--

DROP TABLE IF EXISTS `str_terms`;
CREATE TABLE `str_terms` (
`term_id` bigint(20) unsigned NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `str_terms`
--

INSERT INTO `str_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Экспертиза', 'ekspertiza', 0),
(2, 'Мария Иванова', 'mariya-ivanova', 0),
(3, 'Новости фонда', 'novosti-fonda', 0),
(4, 'Команда фонда', 'komanda-fonda', 0),
(5, 'Главное', 'glavnoe', 0),
(6, 'Карта сайта', 'karta-sajta', 0),
(8, 'О нас', 'o-nas', 0),
(9, 'Деятельность', 'deyatelnost', 0),
(10, 'Социальные кнопки', 'sotsialnye-knopki', 0),
(11, 'Команда', 'team', 0),
(12, 'Партнеры', 'partnery', 0),
(13, 'Наши дети', 'nashi-deti', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `str_term_relationships`
--

DROP TABLE IF EXISTS `str_term_relationships`;
CREATE TABLE `str_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `str_term_relationships`
--

INSERT INTO `str_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 2, 0),
(16, 3, 0),
(16, 4, 0),
(20, 1, 0),
(20, 3, 0),
(20, 4, 0),
(23, 3, 0),
(23, 4, 0),
(25, 3, 0),
(25, 4, 0),
(28, 1, 0),
(28, 2, 0),
(59, 12, 0),
(61, 12, 0),
(63, 12, 0),
(66, 12, 0),
(67, 12, 0),
(68, 12, 0),
(72, 3, 0),
(72, 13, 0),
(85, 5, 0),
(86, 5, 0),
(88, 5, 0),
(94, 5, 0),
(95, 6, 0),
(96, 6, 0),
(97, 6, 0),
(98, 6, 0),
(99, 6, 0),
(101, 6, 0),
(112, 5, 0),
(122, 5, 0),
(153, 5, 0),
(154, 5, 0),
(159, 8, 0),
(161, 8, 0),
(162, 8, 0),
(165, 9, 0),
(166, 9, 0),
(167, 9, 0),
(168, 9, 0),
(182, 10, 0),
(183, 10, 0),
(234, 2, 0),
(234, 3, 0),
(260, 11, 0),
(261, 11, 0),
(262, 11, 0),
(263, 13, 0),
(270, 13, 0),
(272, 13, 0),
(274, 5, 0),
(275, 5, 0),
(276, 5, 0),
(277, 13, 0),
(278, 13, 0),
(279, 11, 0),
(280, 8, 0),
(281, 8, 0),
(282, 6, 0),
(283, 6, 0),
(284, 6, 0),
(285, 6, 0),
(288, 13, 0),
(295, 10, 0),
(296, 9, 0),
(297, 9, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `str_term_taxonomy`
--

DROP TABLE IF EXISTS `str_term_taxonomy`;
CREATE TABLE `str_term_taxonomy` (
`term_taxonomy_id` bigint(20) unsigned NOT NULL,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=14 ;

--
-- Дамп данных таблицы `str_term_taxonomy`
--

INSERT INTO `str_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 3),
(2, 2, 'auctor', 'Автор блога о здоровом образе жизни и долголетии. В течение многих лет Мария серьезно занимается вопросами здорового образа жизни и долголетия. Постоянный эксперт нашей рубрики она охотно делится с нашими читателями полезной информацией', 0, 3),
(3, 3, 'category', '', 0, 5),
(4, 4, 'auctor', 'Мы пишем и работаем для поддержки наших подопечный, присоединяйтесь к нашей работе.', 0, 4),
(5, 5, 'nav_menu', '', 0, 11),
(6, 6, 'nav_menu', '', 0, 10),
(8, 8, 'nav_menu', '', 0, 5),
(9, 9, 'nav_menu', '', 0, 6),
(10, 10, 'nav_menu', '', 0, 3),
(11, 11, 'person_cat', 'Наша команда - самая лучшая команда из команд', 0, 4),
(12, 12, 'org_cat', 'Мы благодарим наших партнеров за неизменную поддержку', 0, 6),
(13, 13, 'person_cat', 'Им нужна ваша помощь', 0, 6);

-- --------------------------------------------------------

--
-- Структура таблицы `str_usermeta`
--

DROP TABLE IF EXISTS `str_usermeta`;
CREATE TABLE `str_usermeta` (
`umeta_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=36 ;

--
-- Дамп данных таблицы `str_usermeta`
--

INSERT INTO `str_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'starter'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'str_capabilities', 'a:7:{s:13:"administrator";b:1;s:14:"frm_view_forms";b:1;s:14:"frm_edit_forms";b:1;s:16:"frm_delete_forms";b:1;s:19:"frm_change_settings";b:1;s:16:"frm_view_entries";b:1;s:18:"frm_delete_entries";b:1;}'),
(11, 1, 'str_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets'),
(13, 1, 'show_welcome_panel', '0'),
(15, 1, 'str_dashboard_quick_press_last_post_id', '217'),
(16, 1, 'str_user-settings', 'editor=html&libraryContent=browse&editor_expand=off&align=left&urlbutton=none&imgsize=thumbnail&ed_size=394&posts_list_mode=list'),
(17, 1, 'str_user-settings-time', '1449780890'),
(18, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:0:"";i:1;s:0:"";i:2;s:0:"";i:3;s:0:"";}'),
(19, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:11:"add-frm_tag";}'),
(20, 1, 'closedpostboxes_nav-menus', 'a:0:{}'),
(21, 1, 'nav_menu_recently_edited', '5'),
(23, 1, 'closedpostboxes_leyka_campaign', 'a:1:{i:0;s:20:"leyka_campaign_embed";}'),
(24, 1, 'metaboxhidden_leyka_campaign', 'a:6:{i:0;s:23:"acf-group_5596e61e0f971";i:1;s:23:"acf-group_5596bb39d7507";i:2;s:23:"acf-group_55fc1d63b8919";i:3;s:23:"acf-group_559a5ecd59220";i:4;s:23:"acf-group_5596f9bb26898";i:5;s:7:"slugdiv";}'),
(26, 1, 'str_media_library_mode', 'list'),
(27, 1, 'closedpostboxes_post', 'a:0:{}'),
(28, 1, 'metaboxhidden_post', 'a:4:{i:0;s:12:"revisionsdiv";i:1;s:10:"postcustom";i:2;s:7:"slugdiv";i:3;s:9:"authordiv";}'),
(33, 1, 'upload_per_page', '50'),
(34, 1, 'manageedit-postcolumnshidden', 'a:0:{}'),
(35, 1, 'session_tokens', 'a:1:{s:64:"2c5443663c1dce9805e3064174fa447ab74582935627120c7e1d61c503e97223";a:4:{s:10:"expiration";i:1449916492;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:96:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:42.0) Gecko/20100101 Firefox/42.0 FirePHP/0.7.4";s:5:"login";i:1449743692;}}');

-- --------------------------------------------------------

--
-- Структура таблицы `str_users`
--

DROP TABLE IF EXISTS `str_users`;
CREATE TABLE `str_users` (
`ID` bigint(20) unsigned NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `str_users`
--

INSERT INTO `str_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'giger', '$P$BI8FGUH1r7JiPl1N427P5wgC3JgeWh1', 'starter', 'support@te-st.ru', '', '2015-09-18 08:25:35', '', 0, 'starter');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `str_commentmeta`
--
ALTER TABLE `str_commentmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `comment_id` (`comment_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `str_comments`
--
ALTER TABLE `str_comments`
 ADD PRIMARY KEY (`comment_ID`), ADD KEY `comment_post_ID` (`comment_post_ID`), ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`), ADD KEY `comment_date_gmt` (`comment_date_gmt`), ADD KEY `comment_parent` (`comment_parent`), ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `str_links`
--
ALTER TABLE `str_links`
 ADD PRIMARY KEY (`link_id`), ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `str_nf_objectmeta`
--
ALTER TABLE `str_nf_objectmeta`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `str_nf_objects`
--
ALTER TABLE `str_nf_objects`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `str_nf_relationships`
--
ALTER TABLE `str_nf_relationships`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `str_ninja_forms_fav_fields`
--
ALTER TABLE `str_ninja_forms_fav_fields`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `str_ninja_forms_fields`
--
ALTER TABLE `str_ninja_forms_fields`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `str_options`
--
ALTER TABLE `str_options`
 ADD PRIMARY KEY (`option_id`), ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `str_postmeta`
--
ALTER TABLE `str_postmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `post_id` (`post_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `str_posts`
--
ALTER TABLE `str_posts`
 ADD PRIMARY KEY (`ID`), ADD KEY `post_name` (`post_name`(191)), ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`), ADD KEY `post_parent` (`post_parent`), ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `str_termmeta`
--
ALTER TABLE `str_termmeta`
 ADD PRIMARY KEY (`meta_id`), ADD KEY `term_id` (`term_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `str_terms`
--
ALTER TABLE `str_terms`
 ADD PRIMARY KEY (`term_id`), ADD KEY `slug` (`slug`(191)), ADD KEY `name` (`name`(191));

--
-- Indexes for table `str_term_relationships`
--
ALTER TABLE `str_term_relationships`
 ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`), ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `str_term_taxonomy`
--
ALTER TABLE `str_term_taxonomy`
 ADD PRIMARY KEY (`term_taxonomy_id`), ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`), ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `str_usermeta`
--
ALTER TABLE `str_usermeta`
 ADD PRIMARY KEY (`umeta_id`), ADD KEY `user_id` (`user_id`), ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `str_users`
--
ALTER TABLE `str_users`
 ADD PRIMARY KEY (`ID`), ADD KEY `user_login_key` (`user_login`), ADD KEY `user_nicename` (`user_nicename`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `str_commentmeta`
--
ALTER TABLE `str_commentmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `str_comments`
--
ALTER TABLE `str_comments`
MODIFY `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `str_links`
--
ALTER TABLE `str_links`
MODIFY `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `str_nf_objectmeta`
--
ALTER TABLE `str_nf_objectmeta`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT for table `str_nf_objects`
--
ALTER TABLE `str_nf_objects`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `str_nf_relationships`
--
ALTER TABLE `str_nf_relationships`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `str_ninja_forms_fav_fields`
--
ALTER TABLE `str_ninja_forms_fav_fields`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=93;
--
-- AUTO_INCREMENT for table `str_ninja_forms_fields`
--
ALTER TABLE `str_ninja_forms_fields`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `str_options`
--
ALTER TABLE `str_options`
MODIFY `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1123;
--
-- AUTO_INCREMENT for table `str_postmeta`
--
ALTER TABLE `str_postmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=1362;
--
-- AUTO_INCREMENT for table `str_posts`
--
ALTER TABLE `str_posts`
MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=301;
--
-- AUTO_INCREMENT for table `str_termmeta`
--
ALTER TABLE `str_termmeta`
MODIFY `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `str_terms`
--
ALTER TABLE `str_terms`
MODIFY `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `str_term_taxonomy`
--
ALTER TABLE `str_term_taxonomy`
MODIFY `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `str_usermeta`
--
ALTER TABLE `str_usermeta`
MODIFY `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT for table `str_users`
--
ALTER TABLE `str_users`
MODIFY `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
