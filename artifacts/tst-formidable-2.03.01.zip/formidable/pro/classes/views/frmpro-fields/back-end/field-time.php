<?php
_deprecated_file( basename(__FILE__), '2.03', null, __( 'Use FrmProTimeField::show_time_field', 'formidable' ) );
