<?php
/**
 * Part Name: Posts
 * Description: the post loop
 */

?>

<p>this is page builder part loaded from a SPB plugin / templates</p>