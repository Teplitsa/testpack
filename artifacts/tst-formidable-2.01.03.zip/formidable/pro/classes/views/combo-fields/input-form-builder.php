<div class="frm_multi_fields_container">
	<?php include( FrmAppHelper::plugin_path() .'/pro/classes/views/combo-fields/input.php' ); ?>
</div>